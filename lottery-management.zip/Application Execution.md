1. Backend Server (Express API & Database)
Runs the backend API service on Port 5001:

> npm run server


2. Frontend Application (Web / Admin / Display)
Runs the Vite development server on Port 3005 (bound to 0.0.0.0 for local network access):

> npm run dev


3. Tablet Application (Android / Capacitor)
Depending on how you run your tablet application:

Option A: Run directly on connected Android tablet / emulator
Make sure your tablet is connected via USB (with USB Debugging enabled) or an emulator is running:

> npm run android:run

Option B: Open in Android Studio
To inspect, build or deploy to your tablet via Android Studio:

> npm run android:open

Option C: Build the Debug APK (to copy and install on tablet)
Builds the web bundle, syncs assets into the Android native project and compiles the .apk:

> npm run android:build

Option D: Quick Sync & APK Build after frontend changes
1. To sync UI changes to the Android assets:
> npm run android:sync

2. To compile the new standalone APK for direct tablet installation:
> npm run android:build

========================

APK DOWNLOAD

Direct APK Download Route: The backend API on port 5001 serves the compiled Android APK directly at:

Download Link: http://localhost:5001/download/apk
Build Info & Size: http://localhost:5001/download/info
Local Wi-Fi Network Access: http://192.168.1.58:5001/download/apk (devices on your local network can download immediately without an external tunnel)