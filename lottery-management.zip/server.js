// src/server/index.ts
import express2 from "express";
import cors from "cors";
import dotenv from "dotenv";

// src/server/routes/employees.ts
import { Router } from "express";

// src/server/db.ts
import { PrismaClient } from "@prisma/client";

// src/utils/istGameId.ts
function getISTDateTime(date = /* @__PURE__ */ new Date()) {
  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });
  const parts = formatter.formatToParts(date);
  const partMap = {};
  for (const part of parts) {
    partMap[part.type] = part.value;
  }
  const year = parseInt(partMap.year, 10);
  const month = parseInt(partMap.month, 10);
  const day = parseInt(partMap.day, 10);
  let hour = parseInt(partMap.hour, 10);
  if (hour === 24) hour = 0;
  const minute = parseInt(partMap.minute, 10);
  const second = parseInt(partMap.second, 10);
  const YYYY = String(year).padStart(4, "0");
  const MM = String(month).padStart(2, "0");
  const DD = String(day).padStart(2, "0");
  const HH = String(hour).padStart(2, "0");
  const gameIdStr = `${YYYY}${MM}${DD}${HH}`;
  const gameIdNum = parseInt(gameIdStr, 10);
  return {
    year,
    month,
    day,
    hour,
    minute,
    second,
    gameIdStr,
    gameIdNum
  };
}
function getCurrentISTGameId(date = /* @__PURE__ */ new Date()) {
  return getISTDateTime(date).gameIdNum;
}
function getISTDateString(date = /* @__PURE__ */ new Date()) {
  const ist = getISTDateTime(date);
  const yy = String(ist.year).slice(-2);
  const mm = String(ist.month).padStart(2, "0");
  const dd = String(ist.day).padStart(2, "0");
  return `${yy}${mm}${dd}`;
}
function generateISTTicketId(date = /* @__PURE__ */ new Date(), terminalId) {
  const dateStr = getISTDateString(date);
  let termPrefix = "";
  if (terminalId) {
    const cleanTerm = terminalId.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
    if (cleanTerm.length > 0) {
      const suffix = cleanTerm.slice(-2);
      termPrefix = `T${suffix}-`;
    }
  }
  const randNum = Math.floor(1e5 + Math.random() * 9e5);
  return `TK-${dateStr}-${termPrefix}${randNum}`;
}
function getISTDayRange(date = /* @__PURE__ */ new Date()) {
  const ist = getISTDateTime(date);
  const start = new Date(Date.UTC(ist.year, ist.month - 1, ist.day, 0, 0, 0, 0) - 5.5 * 3600 * 1e3);
  const end = new Date(Date.UTC(ist.year, ist.month - 1, ist.day, 23, 59, 59, 999) - 5.5 * 3600 * 1e3);
  const mm = String(ist.month).padStart(2, "0");
  const dd = String(ist.day).padStart(2, "0");
  const dateStr = `${ist.year}-${mm}-${dd}`;
  const datePrefix = `${ist.year}${mm}${dd}`;
  return { start, end, dateStr, datePrefix };
}
function getNowIST() {
  return /* @__PURE__ */ new Date();
}
function formatISTTime(dateOrStr, options) {
  if (!dateOrStr) return "--:-- IST";
  const d = typeof dateOrStr === "string" ? new Date(dateOrStr) : dateOrStr;
  if (isNaN(d.getTime())) return "--:-- IST";
  const ist = getISTDateTime(d);
  const hh = ist.hour;
  const mm = String(ist.minute).padStart(2, "0");
  const ss = String(ist.second).padStart(2, "0");
  if (options?.hour12 !== false) {
    const ampm = hh >= 12 ? "PM" : "AM";
    const h12 = hh % 12 || 12;
    const hStr2 = String(h12).padStart(2, "0");
    return options?.seconds !== false ? `${hStr2}:${mm}:${ss} ${ampm} IST` : `${hStr2}:${mm} ${ampm} IST`;
  }
  const hStr = String(hh).padStart(2, "0");
  return options?.seconds !== false ? `${hStr}:${mm}:${ss} IST` : `${hStr}:${mm} IST`;
}
function getISTHourlyWindow(date = /* @__PURE__ */ new Date()) {
  const ist = getISTDateTime(date);
  const secondsElapsedInHour = ist.minute * 60 + ist.second;
  const cutoffSecondsLeft = Math.max(0, 3600 - secondsElapsedInHour);
  const nextHour = (ist.hour + 1) % 24;
  const cutoffFormatted = `${String(nextHour).padStart(2, "0")}:00 IST`;
  return {
    gameId: ist.gameIdNum,
    gameIdStr: ist.gameIdStr,
    currentHour: ist.hour,
    nextHour,
    cutoffFormatted,
    cutoffSecondsLeft
  };
}

// src/server/db.ts
var globalForPrisma = global;
var basePrisma = globalForPrisma.basePrisma || new PrismaClient({
  log: process.env.NODE_ENV === "development" ? ["query", "error", "warn"] : ["error"]
});
var MODELS_WITH_CREATED_AT = /* @__PURE__ */ new Set([
  "Employee",
  "Ticket",
  "Bet",
  "Game",
  "Transaction",
  "Payout",
  "Cage",
  "Tablet",
  "DowntimeIncident"
]);
var prisma = globalForPrisma.prisma || basePrisma.$extends({
  query: {
    $allModels: {
      async create({ model, args, query }) {
        args.data = args.data || {};
        const nowIST = getNowIST();
        if (MODELS_WITH_CREATED_AT.has(model) && !args.data.createdAt) {
          args.data.createdAt = nowIST;
        }
        if (model === "Result" && !args.data.declaredAt) {
          args.data.declaredAt = nowIST;
        }
        if (model === "ShiftAudit" && !args.data.openedAt) {
          args.data.openedAt = nowIST;
        }
        if (model === "Cage" && !args.data.openedAt) {
          args.data.openedAt = nowIST;
        }
        if (model === "LoginActivity" && !args.data.loginTime) {
          args.data.loginTime = nowIST;
        }
        return query(args);
      },
      async update({ args, query }) {
        args.data = args.data || {};
        if ("updatedAt" in args.data) {
          args.data.updatedAt = getNowIST();
        }
        return query(args);
      }
    }
  }
});
if (process.env.NODE_ENV !== "production") {
  globalForPrisma.basePrisma = basePrisma;
  globalForPrisma.prisma = prisma;
}

// src/server/routes/employees.ts
import { Role } from "@prisma/client";

// src/utils/rfidCrypto.ts
var DEFAULT_SECRET = "GXPRO_LOTTERY_SECURE_RFID_KEY_v2026";
function getSecretKey() {
  if (typeof process !== "undefined" && process.env?.RFID_SECRET_KEY) {
    return process.env.RFID_SECRET_KEY;
  }
  return DEFAULT_SECRET;
}
function stringToBytes(str) {
  const bytes = new Uint8Array(str.length);
  for (let i = 0; i < str.length; i++) {
    bytes[i] = str.charCodeAt(i) & 255;
  }
  return bytes;
}
function base64UrlToBytes(base64url) {
  let base64 = base64url.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4) {
    base64 += "=";
  }
  const binary = typeof atob === "function" ? atob(base64) : Buffer.from(base64, "base64").toString("binary");
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}
function deriveKeyStream(secret, salt, length) {
  const stream = new Uint8Array(length);
  const secretBytes = stringToBytes(secret);
  let h = 2166136261;
  for (let i = 0; i < salt.length; i++) {
    h ^= salt[i];
    h = Math.imul(h, 16777619);
  }
  for (let i = 0; i < length; i++) {
    const secByte = secretBytes[(i + salt[i % salt.length]) % secretBytes.length];
    h ^= secByte ^ i * 31;
    h = Math.imul(h, 16777619);
    stream[i] = h >>> 8 * (i % 4) & 255;
  }
  return stream;
}
function decodeRfidToken(token, maxAgeMs = 5 * 60 * 1e3) {
  if (!token || typeof token !== "string") {
    throw new Error("Invalid token");
  }
  if (!token.startsWith("rfid_v1_")) {
    return token.trim();
  }
  const rawPayload = token.substring("rfid_v1_".length);
  const combined = base64UrlToBytes(rawPayload);
  if (combined.length <= 8) {
    throw new Error("Corrupt or truncated RFID token");
  }
  const salt = combined.slice(0, 8);
  const encrypted = combined.slice(8);
  const keyStream = deriveKeyStream(getSecretKey(), salt, encrypted.length);
  const decryptedBytes = new Uint8Array(encrypted.length);
  let prev = salt[0];
  for (let i = 0; i < encrypted.length; i++) {
    const enc = encrypted[i];
    decryptedBytes[i] = enc ^ keyStream[i] ^ prev;
    prev = enc;
  }
  const payloadStr = new TextDecoder().decode(decryptedBytes);
  const parsed = JSON.parse(payloadStr);
  if (!parsed || !parsed.rfid) {
    throw new Error("Invalid RFID payload structure");
  }
  if (parsed.ts && maxAgeMs > 0) {
    const age = Math.abs(Date.now() - parsed.ts);
    if (age > maxAgeMs) {
      throw new Error("Expired RFID authentication token. Please rescan badge.");
    }
  }
  return parsed.rfid.trim();
}

// src/utils/credentialCrypto.ts
var DEFAULT_CREDENTIAL_SECRET = "GXPRO_LOTTERY_SECURE_CREDENTIAL_KEY_v2026";
function getSecretKey2() {
  if (typeof process !== "undefined" && process.env?.CREDENTIAL_SECRET_KEY) {
    return process.env.CREDENTIAL_SECRET_KEY;
  }
  return DEFAULT_CREDENTIAL_SECRET;
}
function stringToBytes2(str) {
  const bytes = new Uint8Array(str.length);
  for (let i = 0; i < str.length; i++) {
    bytes[i] = str.charCodeAt(i) & 255;
  }
  return bytes;
}
function base64UrlToBytes2(base64url) {
  let base64 = base64url.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4) {
    base64 += "=";
  }
  const binary = typeof atob === "function" ? atob(base64) : Buffer.from(base64, "base64").toString("binary");
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}
function deriveKeyStream2(secret, salt, length) {
  const stream = new Uint8Array(length);
  const secretBytes = stringToBytes2(secret);
  let h = 2166136261;
  for (let i = 0; i < salt.length; i++) {
    h ^= salt[i];
    h = Math.imul(h, 16777619);
  }
  for (let i = 0; i < length; i++) {
    const secByte = secretBytes[(i + salt[i % salt.length]) % secretBytes.length];
    h ^= secByte ^ i * 31;
    h = Math.imul(h, 16777619);
    stream[i] = h >>> 8 * (i % 4) & 255;
  }
  return stream;
}
function decodeCredential(token, maxAgeMs = 5 * 60 * 1e3) {
  if (!token || typeof token !== "string") {
    throw new Error("Invalid credential token");
  }
  if (!token.startsWith("gx_cred_v1_")) {
    return token.trim();
  }
  const rawPayload = token.substring("gx_cred_v1_".length);
  const combined = base64UrlToBytes2(rawPayload);
  if (combined.length <= 8) {
    throw new Error("Corrupt or truncated credential token");
  }
  const salt = combined.slice(0, 8);
  const encrypted = combined.slice(8);
  const keyStream = deriveKeyStream2(getSecretKey2(), salt, encrypted.length);
  const decryptedBytes = new Uint8Array(encrypted.length);
  let prev = salt[0];
  for (let i = 0; i < encrypted.length; i++) {
    const enc = encrypted[i];
    decryptedBytes[i] = enc ^ keyStream[i] ^ prev;
    prev = enc;
  }
  const payloadStr = new TextDecoder().decode(decryptedBytes);
  const parsed = JSON.parse(payloadStr);
  if (!parsed || typeof parsed.cred === "undefined") {
    throw new Error("Invalid credential payload structure");
  }
  if (parsed.ts && maxAgeMs > 0) {
    const age = Math.abs(Date.now() - parsed.ts);
    if (age > maxAgeMs) {
      throw new Error("Expired authentication token. Please re-enter credentials.");
    }
  }
  return String(parsed.cred).trim();
}

// src/server/routes/employees.ts
var router = Router();
router.get("/", async (req, res) => {
  try {
    const { role, status, search } = req.query;
    const where = {};
    if (role && Object.values(Role).includes(role)) {
      where.role = role;
    }
    if (status !== void 0) {
      where.status = status === "true";
    }
    if (search && typeof search === "string") {
      where.OR = [
        { name: { contains: search } },
        { phone: { contains: search } },
        { badgeId: { contains: search } },
        { rfid: { contains: search } }
      ];
    }
    const employees = await prisma.employee.findMany({
      where,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        name: true,
        username: true,
        badgeId: true,
        rfid: true,
        pin: true,
        phone: true,
        role: true,
        status: true,
        createdAt: true,
        updatedAt: true,
        _count: {
          select: {
            tickets: true,
            payouts: true,
            shiftAudits: true
          }
        }
      }
    });
    res.json({ success: true, count: employees.length, data: employees });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
async function generateUniqueBadgeId(role) {
  const prefixMap = {
    [Role.OPERATOR]: "OP",
    [Role.ADMIN]: "ADM",
    [Role.CAGE_OPERATOR]: "CAGE"
  };
  const prefix = prefixMap[role] || "EMP";
  const employees = await prisma.employee.findMany({
    where: {
      badgeId: {
        startsWith: `${prefix}-`
      }
    },
    select: { badgeId: true }
  });
  let maxNum = 0;
  for (const emp of employees) {
    if (emp.badgeId) {
      const match = emp.badgeId.match(new RegExp(`^${prefix}-+(\\d+)`));
      if (match) {
        const num = parseInt(match[1], 10);
        if (!isNaN(num) && num > maxNum) {
          maxNum = num;
        }
      }
    }
  }
  let nextNum = maxNum > 0 ? maxNum + 1 : 1001;
  let candidate = `${prefix}-${nextNum}`;
  while (await prisma.employee.findUnique({ where: { badgeId: candidate } })) {
    nextNum++;
    candidate = `${prefix}-${nextNum}`;
  }
  return candidate;
}
async function generateUniqueUsername(role, name) {
  if (role === Role.OPERATOR) {
    return null;
  }
  const prefix = role === Role.ADMIN ? "admin" : "cage";
  let slug = "";
  if (name && typeof name === "string") {
    const firstName = name.trim().split(/\s+/)[0] || "";
    slug = firstName.toLowerCase().replace(/[^a-z0-9]/g, "");
  }
  const base = slug ? `${prefix}.${slug}` : prefix;
  let candidate = base;
  let counter = 1;
  while (await prisma.employee.findUnique({ where: { username: candidate } })) {
    candidate = `${base}${counter}`;
    counter++;
  }
  return candidate;
}
router.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid employee ID" });
    }
    const employee = await prisma.employee.findUnique({
      where: { id },
      include: {
        tickets: {
          take: 10,
          orderBy: { createdAt: "desc" },
          include: { bets: true }
        },
        payouts: {
          take: 10,
          orderBy: { paidAt: "desc" }
        },
        shiftAudits: {
          take: 5,
          orderBy: { openedAt: "desc" }
        }
      }
    });
    if (!employee) {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router.post("/", async (req, res) => {
  try {
    const { name, phone, role, badgeId, rfid, pin, status, username, password, encodedPassword } = req.body;
    let rawPassword = password;
    if (encodedPassword) {
      try {
        rawPassword = decodeCredential(encodedPassword);
      } catch (err) {
        return res.status(400).json({ success: false, message: `Invalid encrypted password: ${err.message}` });
      }
    }
    if (!name || !role) {
      return res.status(400).json({ success: false, message: "Name and role are required" });
    }
    if (!rfid || !String(rfid).trim()) {
      return res.status(400).json({ success: false, message: "RFID number is mandatory for all staff members" });
    }
    if (!Object.values(Role).includes(role)) {
      return res.status(400).json({
        success: false,
        message: `Invalid role. Allowed: ${Object.values(Role).join(", ")}`
      });
    }
    const cleanRfid = String(rfid).trim();
    const existingRfid = await prisma.employee.findUnique({
      where: { rfid: cleanRfid }
    });
    if (existingRfid) {
      return res.status(409).json({
        success: false,
        message: `RFID "${cleanRfid}" is already assigned to ${existingRfid.name} (${existingRfid.role})`
      });
    }
    const cleanBadgeId = badgeId && String(badgeId).trim() ? String(badgeId).trim() : await generateUniqueBadgeId(role);
    const cleanPin = pin && String(pin).trim() ? String(pin).trim() : "2626";
    let finalUsername = null;
    let finalPassword = null;
    if (role === Role.ADMIN || role === Role.CAGE_OPERATOR) {
      if (username && String(username).trim()) {
        const cleanUser = String(username).trim().toLowerCase().replace(/[^a-z0-9._-]/g, "");
        const duplicateUser = await prisma.employee.findUnique({ where: { username: cleanUser } });
        if (duplicateUser) {
          return res.status(409).json({
            success: false,
            message: `Username "${cleanUser}" is already taken. Please choose another username.`
          });
        }
        finalUsername = cleanUser;
      } else {
        finalUsername = await generateUniqueUsername(role, name);
      }
      if (rawPassword && String(rawPassword).trim()) {
        finalPassword = String(rawPassword).trim();
      } else {
        finalPassword = "Lottery@123";
      }
    }
    const employee = await prisma.employee.create({
      data: {
        name: String(name).trim(),
        username: finalUsername,
        password: finalPassword,
        phone: phone ? String(phone).trim() : null,
        role,
        badgeId: cleanBadgeId,
        rfid: cleanRfid,
        pin: cleanPin,
        status: status !== void 0 ? Boolean(status) : true
      }
    });
    res.status(201).json({ success: true, message: "Employee created successfully", data: employee });
  } catch (error) {
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Phone, Badge ID, Username or RFID already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid employee ID" });
    }
    const existingEmp = await prisma.employee.findUnique({ where: { id } });
    if (!existingEmp) {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    const { name, phone, role, badgeId, rfid, pin, status } = req.body;
    if (rfid !== void 0 && (!rfid || !String(rfid).trim())) {
      return res.status(400).json({ success: false, message: "RFID number is mandatory and cannot be empty" });
    }
    const cleanRfid = rfid !== void 0 ? String(rfid).trim() : void 0;
    if (cleanRfid) {
      const duplicateRfid = await prisma.employee.findFirst({
        where: { rfid: cleanRfid, NOT: { id } }
      });
      if (duplicateRfid) {
        return res.status(409).json({
          success: false,
          message: `RFID "${cleanRfid}" is already assigned to ${duplicateRfid.name} (${duplicateRfid.role})`
        });
      }
    }
    let finalBadgeId = existingEmp.badgeId;
    if (badgeId !== void 0) {
      if (badgeId && String(badgeId).trim()) {
        finalBadgeId = String(badgeId).trim();
      } else if (!existingEmp.badgeId) {
        finalBadgeId = await generateUniqueBadgeId(role || existingEmp.role);
      } else {
        finalBadgeId = null;
      }
    } else if (!finalBadgeId) {
      finalBadgeId = await generateUniqueBadgeId(role || existingEmp.role);
    }
    let finalPin = existingEmp.pin;
    if (pin !== void 0) {
      if (pin && String(pin).trim()) {
        finalPin = String(pin).trim();
      } else if (!existingEmp.pin) {
        finalPin = "2626";
      }
    } else if (!finalPin) {
      finalPin = "2626";
    }
    const targetRole = role || existingEmp.role;
    let finalUsername = existingEmp.username;
    let finalPassword = existingEmp.password;
    if (targetRole === Role.OPERATOR) {
      finalUsername = null;
      finalPassword = null;
    } else {
      if (req.body.username !== void 0) {
        if (req.body.username && String(req.body.username).trim()) {
          const cleanUser = String(req.body.username).trim().toLowerCase().replace(/[^a-z0-9._-]/g, "");
          const dupUser = await prisma.employee.findFirst({
            where: { username: cleanUser, NOT: { id } }
          });
          if (dupUser) {
            return res.status(409).json({
              success: false,
              message: `Username "${cleanUser}" is already assigned to another staff member.`
            });
          }
          finalUsername = cleanUser;
        } else if (!existingEmp.username) {
          finalUsername = await generateUniqueUsername(targetRole, name || existingEmp.name);
        }
      } else if (!finalUsername) {
        finalUsername = await generateUniqueUsername(targetRole, name || existingEmp.name);
      }
      let resolvedUpdatePass = req.body.password;
      if (req.body.encodedPassword) {
        try {
          resolvedUpdatePass = decodeCredential(req.body.encodedPassword);
        } catch (err) {
          return res.status(400).json({ success: false, message: `Invalid encrypted password: ${err.message}` });
        }
      }
      if (resolvedUpdatePass !== void 0 && resolvedUpdatePass && String(resolvedUpdatePass).trim()) {
        finalPassword = String(resolvedUpdatePass).trim();
      } else if (!finalPassword) {
        finalPassword = "Lottery@123";
      }
    }
    const employee = await prisma.employee.update({
      where: { id },
      data: {
        name: name !== void 0 ? String(name).trim() : void 0,
        username: finalUsername,
        password: finalPassword,
        phone: phone !== void 0 ? phone ? String(phone).trim() : null : void 0,
        role: role !== void 0 ? role : void 0,
        badgeId: finalBadgeId,
        rfid: cleanRfid,
        pin: finalPin,
        status: status !== void 0 ? Boolean(status) : void 0
      }
    });
    res.json({ success: true, message: "Employee updated successfully", data: employee });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Phone, Badge ID or RFID already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid employee ID" });
    }
    const dataToUpdate = { ...req.body };
    if (dataToUpdate.encodedPassword !== void 0 || dataToUpdate.password !== void 0) {
      const raw = dataToUpdate.encodedPassword !== void 0 ? dataToUpdate.encodedPassword : dataToUpdate.password;
      dataToUpdate.password = decodeCredential(raw);
      delete dataToUpdate.encodedPassword;
    }
    if (dataToUpdate.rfid !== void 0) {
      const cleanRfid = String(dataToUpdate.rfid).trim();
      if (!cleanRfid) {
        return res.status(400).json({ success: false, message: "RFID number is mandatory and cannot be empty" });
      }
      const existingRfid = await prisma.employee.findFirst({
        where: { rfid: cleanRfid, NOT: { id } }
      });
      if (existingRfid) {
        return res.status(409).json({
          success: false,
          message: `RFID "${cleanRfid}" is already assigned to ${existingRfid.name} (${existingRfid.role})`
        });
      }
      dataToUpdate.rfid = cleanRfid;
    }
    const employee = await prisma.employee.update({
      where: { id },
      data: dataToUpdate
    });
    res.json({ success: true, message: "Employee patched successfully", data: employee });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Phone, Badge ID or RFID already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid employee ID" });
    }
    const counts = await prisma.employee.findUnique({
      where: { id },
      select: {
        _count: {
          select: {
            tickets: true,
            transactions: true,
            payouts: true,
            shiftAudits: true,
            results: true
          }
        }
      }
    });
    if (!counts) {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    const totalRecords = counts._count.tickets + counts._count.transactions + counts._count.payouts + counts._count.shiftAudits + counts._count.results;
    if (totalRecords > 0) {
      return res.status(409).json({
        success: false,
        message: `Cannot delete employee: ${totalRecords} linked historical records exist (${counts._count.tickets} tickets, ${counts._count.transactions} transactions, ${counts._count.payouts} payouts, ${counts._count.shiftAudits} shifts). Please deactivate the employee instead to maintain audit integrity.`
      });
    }
    await prisma.employee.delete({
      where: { id }
    });
    res.json({ success: true, message: "Employee deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    if (error.code === "P2003") {
      return res.status(409).json({
        success: false,
        message: "Cannot delete employee due to linked historical records. Deactivate the employee instead to preserve the financial audit trail."
      });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router.post("/change-password", async (req, res) => {
  try {
    const { employeeId, username, currentPassword, newPassword, encodedCurrentPassword, encodedNewPassword } = req.body;
    let rawCurrentPassword = currentPassword;
    let rawNewPassword = newPassword;
    if (encodedCurrentPassword) {
      try {
        rawCurrentPassword = decodeCredential(encodedCurrentPassword);
      } catch (err) {
        return res.status(400).json({ success: false, message: `Invalid encrypted current password: ${err.message}` });
      }
    }
    if (encodedNewPassword) {
      try {
        rawNewPassword = decodeCredential(encodedNewPassword);
      } catch (err) {
        return res.status(400).json({ success: false, message: `Invalid encrypted new password: ${err.message}` });
      }
    }
    if (!rawCurrentPassword || !rawNewPassword) {
      return res.status(400).json({ success: false, message: "Current password and new password are required" });
    }
    if (String(rawNewPassword).length < 6) {
      return res.status(400).json({ success: false, message: "New password must be at least 6 characters long" });
    }
    let employee = null;
    if (employeeId) {
      employee = await prisma.employee.findUnique({ where: { id: parseInt(employeeId) } });
    } else if (username) {
      employee = await prisma.employee.findUnique({ where: { username: String(username).trim().toLowerCase() } });
    }
    if (!employee) {
      return res.status(404).json({ success: false, message: "Staff member account not found" });
    }
    if (employee.role === Role.OPERATOR) {
      return res.status(400).json({ success: false, message: "Password change is not applicable for POS Operator accounts" });
    }
    const curP = String(rawCurrentPassword).trim();
    const isCorrect = employee.password && employee.password === curP || employee.pin && employee.pin === curP;
    if (!isCorrect) {
      return res.status(401).json({ success: false, message: "Current password is incorrect" });
    }
    const updated = await prisma.employee.update({
      where: { id: employee.id },
      data: {
        password: String(rawNewPassword).trim()
      }
    });
    res.json({
      success: true,
      message: "Password changed successfully",
      data: {
        id: updated.id,
        name: updated.name,
        username: updated.username,
        role: updated.role
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router.post("/auth", async (req, res) => {
  try {
    const { username, password, encodedPassword, encodedRfid, rfid, badgeId, pin, encodedPin, phone, deviceInfo, ipAddress, tabletId } = req.body;
    const resolvedTabletId = tabletId || req.headers["x-tablet-id"] || null;
    let employee = null;
    const rawPass = encodedPassword !== void 0 ? decodeCredential(encodedPassword) : password ? String(password).trim() : "";
    const rawPin = encodedPin !== void 0 ? decodeCredential(encodedPin) : pin ? String(pin).trim() : "";
    const cleanSecret = rawPass || rawPin;
    if ((username || badgeId && cleanSecret) && cleanSecret) {
      const identifier = String(username || badgeId).trim();
      employee = await prisma.employee.findFirst({
        where: {
          OR: [
            { username: identifier.toLowerCase() },
            { badgeId: identifier },
            { badgeId: identifier.toUpperCase() },
            { name: identifier }
          ]
        }
      });
      if (employee) {
        const passMatch = employee.password && employee.password === cleanSecret || employee.pin && employee.pin === cleanSecret;
        if (!passMatch) {
          employee = null;
        }
      }
    } else if (encodedRfid || rfid) {
      const rawToken = encodedRfid || rfid;
      let decodedTag;
      try {
        decodedTag = decodeRfidToken(rawToken);
      } catch (decodeErr) {
        return res.status(400).json({ success: false, message: `RFID decode error: ${decodeErr.message}` });
      }
      const cleanUpper = decodedTag.toUpperCase();
      const stripped = decodedTag.replace(/[:-]/g, "").toUpperCase();
      employee = await prisma.employee.findFirst({
        where: {
          OR: [
            { rfid: decodedTag },
            { rfid: cleanUpper },
            { rfid: stripped },
            { badgeId: decodedTag },
            { badgeId: cleanUpper }
          ]
        }
      });
    } else if (badgeId) {
      const cleanBadge = String(badgeId).trim();
      employee = await prisma.employee.findFirst({
        where: {
          OR: [
            { badgeId: cleanBadge },
            { badgeId: cleanBadge.toUpperCase() },
            { rfid: cleanBadge },
            { rfid: cleanBadge.toUpperCase() }
          ]
        }
      });
    } else if (phone && (pin || encodedPin)) {
      const targetPin = cleanSecret || (pin ? String(pin).trim() : "");
      employee = await prisma.employee.findFirst({
        where: { phone: String(phone).trim(), pin: targetPin }
      });
    }
    if (!employee) {
      return res.status(401).json({ success: false, message: "ACCESS DENIED" });
    }
    if (employee.status === false) {
      return res.status(403).json({
        success: false,
        message: "ACCESS DENIED"
      });
    }
    const isAndroidDevice = req.body.isAndroid === true || req.body.platform === "android" || /Android/i.test(req.headers["user-agent"] || "") || typeof deviceInfo === "string" && /Android/i.test(deviceInfo);
    if (isAndroidDevice && employee.role === "CAGE_OPERATOR") {
      return res.status(403).json({
        success: false,
        message: "ACCESS DENIED"
      });
    }
    let tabletRecord = null;
    if (resolvedTabletId && String(resolvedTabletId).trim()) {
      const cleanTabId = String(resolvedTabletId).trim();
      tabletRecord = await prisma.tablet.findUnique({
        where: { tabletId: cleanTabId }
      });
      if (tabletRecord && tabletRecord.status === false) {
        return res.status(403).json({
          success: false,
          message: `ACCESS DENIED: Tablet "${tabletRecord.tabletId}" has been disabled by Administrator. Login is prohibited from this device.`
        });
      }
      const now = /* @__PURE__ */ new Date();
      if (!tabletRecord) {
        tabletRecord = await prisma.tablet.create({
          data: {
            tabletId: cleanTabId,
            name: `Tablet (${cleanTabId})`,
            status: true,
            ownerId: employee.id,
            lastUsed: now,
            ipAddress: ipAddress || req.ip || null
          }
        });
      } else {
        tabletRecord = await prisma.tablet.update({
          where: { id: tabletRecord.id },
          data: {
            lastUsed: now,
            ipAddress: ipAddress || req.ip || tabletRecord.ipAddress,
            ownerId: tabletRecord.ownerId || employee.id
          }
        });
      }
    }
    const loginAct = await prisma.loginActivity.create({
      data: {
        employeeId: employee.id,
        deviceInfo: resolvedTabletId ? `Tablet (${resolvedTabletId}) - ${deviceInfo || "Terminal Client"}` : deviceInfo || "Terminal Station Client (RFID Reader)",
        ipAddress: ipAddress || req.ip
      }
    });
    res.json({
      success: true,
      message: "ACCESS GRANTED",
      data: {
        id: employee.id,
        name: employee.name,
        username: employee.username,
        badgeId: employee.badgeId,
        rfid: employee.rfid,
        phone: employee.phone,
        role: employee.role,
        loginActivityId: loginAct.id,
        tablet: tabletRecord ? {
          tabletId: tabletRecord.tabletId,
          name: tabletRecord.name,
          status: tabletRecord.status
        } : null
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var employees_default = router;

// src/server/routes/games.ts
import { Router as Router2 } from "express";

// src/server/services/thirdPartyDrawService.ts
import crypto2 from "crypto";
import { PayoutStatus } from "@prisma/client";
async function ensureHourlyGameExists(targetGameId, tx = prisma) {
  const currentIstId = targetGameId || getCurrentISTGameId();
  let game = await tx.game.findUnique({
    where: { id: currentIstId },
    include: {
      results: {
        take: 1,
        orderBy: { declaredAt: "desc" }
      },
      _count: {
        select: { bets: true, results: true }
      }
    }
  });
  if (!game) {
    const idStr = String(currentIstId);
    let name = `Hourly Draw #${idStr}`;
    let openTime = /* @__PURE__ */ new Date();
    let closeTime = new Date(openTime.getTime() + 36e5);
    let openResultTime = new Date(openTime.getTime() + 18e5);
    let closeResultTime = closeTime;
    let resultTime = closeTime;
    if (idStr.length === 10) {
      const year = parseInt(idStr.substring(0, 4), 10);
      const month = parseInt(idStr.substring(4, 6), 10);
      const day = parseInt(idStr.substring(6, 8), 10);
      const hour = parseInt(idStr.substring(8, 10), 10);
      const YYYY = String(year).padStart(4, "0");
      const MM = String(month).padStart(2, "0");
      const DD = String(day).padStart(2, "0");
      const HH = String(hour).padStart(2, "0");
      const openUtcMs = Date.UTC(year, month - 1, day, hour, 0, 0) - 5.5 * 3600 * 1e3;
      openTime = new Date(openUtcMs);
      openResultTime = new Date(openUtcMs + 30 * 60 * 1e3);
      closeTime = new Date(openUtcMs + 60 * 60 * 1e3);
      closeResultTime = closeTime;
      resultTime = closeTime;
      name = `Hourly Draw (${HH}:00 IST)`;
    }
    const overlapping = await tx.game.findFirst({
      where: {
        id: { not: currentIstId },
        status: true,
        openTime: { lt: closeTime },
        closeTime: { gt: openTime }
      },
      include: {
        results: {
          take: 1,
          orderBy: { declaredAt: "desc" }
        },
        _count: {
          select: { bets: true, results: true }
        }
      }
    });
    if (overlapping && overlapping.closeTime > openTime) {
      await tx.game.update({
        where: { id: overlapping.id },
        data: {
          closeTime: openTime,
          closeResultTime: openTime,
          resultTime: openTime
        }
      });
    }
    game = await tx.game.create({
      data: {
        id: currentIstId,
        name,
        code: idStr,
        openTime,
        openResultTime,
        closeResultTime,
        closeTime,
        resultTime,
        baseMultiplier: 70,
        status: true,
        isLocked: false
      },
      include: {
        results: {
          take: 1,
          orderBy: { declaredAt: "desc" }
        },
        _count: {
          select: { bets: true, results: true }
        }
      }
    });
  } else {
    if (!game.openResultTime || !game.closeResultTime) {
      const openResultTime = game.openResultTime || new Date(new Date(game.openTime).getTime() + 30 * 60 * 1e3);
      const closeResultTime = game.closeResultTime || game.closeTime;
      game = await tx.game.update({
        where: { id: game.id },
        data: { openResultTime, closeResultTime },
        include: {
          results: {
            take: 1,
            orderBy: { declaredAt: "desc" }
          },
          _count: {
            select: { bets: true, results: true }
          }
        }
      });
    }
  }
  return game;
}
async function ensureUpcomingHourlyGames(hoursAhead = 12, tx = prisma) {
  const now = /* @__PURE__ */ new Date();
  const createdGames = [];
  for (let i = 0; i <= hoursAhead; i++) {
    const futureDate = new Date(now.getTime() + i * 3600 * 1e3);
    const targetId = getCurrentISTGameId(futureDate);
    const g = await ensureHourlyGameExists(targetId, tx);
    createdGames.push(g);
  }
  await ensureNoOverlappingGames(tx);
  return createdGames;
}
async function ensureNoOverlappingGames(tx = prisma) {
  const now = /* @__PURE__ */ new Date();
  const games = await tx.game.findMany({
    where: {
      status: true,
      closeTime: { gt: now }
    },
    orderBy: { openTime: "asc" }
  });
  let shiftedCount = 0;
  for (let i = 1; i < games.length; i++) {
    const prev = games[i - 1];
    const curr = games[i];
    const prevClose = new Date(prev.closeTime);
    const currOpen = new Date(curr.openTime);
    if (currOpen.getTime() < prevClose.getTime()) {
      const currIdStr = String(curr.id);
      if (currIdStr.length === 10) {
        await tx.game.update({
          where: { id: prev.id },
          data: {
            closeTime: currOpen,
            closeResultTime: currOpen,
            resultTime: currOpen
          }
        });
        prev.closeTime = currOpen;
        prev.closeResultTime = currOpen;
        shiftedCount++;
        continue;
      }
      const currClose = new Date(curr.closeTime);
      const durationMs = Math.max(30 * 60 * 1e3, currClose.getTime() - currOpen.getTime());
      const currOpenRes = curr.openResultTime ? new Date(curr.openResultTime) : null;
      const openResOffsetMs = currOpenRes ? Math.max(5 * 60 * 1e3, currOpenRes.getTime() - currOpen.getTime()) : Math.floor(durationMs / 2);
      const shiftedOpen = new Date(prevClose.getTime());
      const shiftedClose = new Date(shiftedOpen.getTime() + durationMs);
      const shiftedOpenRes = new Date(shiftedOpen.getTime() + openResOffsetMs);
      const istTime = getISTDateTime(shiftedOpen);
      const hh = String(istTime.hour).padStart(2, "0");
      const mm = String(istTime.minute).padStart(2, "0");
      let newName = curr.name;
      if (/Hourly Draw/i.test(curr.name)) {
        newName = `Hourly Draw (${hh}:${mm} IST)`;
      }
      await tx.game.update({
        where: { id: curr.id },
        data: {
          name: newName,
          openTime: shiftedOpen,
          openResultTime: shiftedOpenRes,
          closeResultTime: shiftedClose,
          closeTime: shiftedClose,
          resultTime: shiftedClose
        }
      });
      curr.name = newName;
      curr.openTime = shiftedOpen;
      curr.closeTime = shiftedClose;
      curr.openResultTime = shiftedOpenRes;
      curr.closeResultTime = shiftedClose;
      shiftedCount++;
    }
  }
  return shiftedCount;
}
async function rippleShiftSubsequentGames(fromCloseTime, excludeGameId, tx = prisma) {
  const now = /* @__PURE__ */ new Date();
  const excluded = await tx.game.findUnique({ where: { id: excludeGameId } });
  const minOpenTime = excluded ? new Date(excluded.openTime) : now;
  const upcomingGames = await tx.game.findMany({
    where: {
      id: { not: excludeGameId },
      status: true,
      openTime: { gte: minOpenTime }
    },
    orderBy: { openTime: "asc" }
  });
  let currentSlotEnd = new Date(fromCloseTime);
  let shiftedCount = 0;
  for (const nextGame of upcomingGames) {
    const nextOpen = new Date(nextGame.openTime);
    const nextClose = new Date(nextGame.closeTime);
    if (nextOpen.getTime() >= currentSlotEnd.getTime()) {
      break;
    }
    const durationMs = Math.max(30 * 60 * 1e3, nextClose.getTime() - nextOpen.getTime());
    const nextOpenRes = nextGame.openResultTime ? new Date(nextGame.openResultTime) : null;
    const openResOffsetMs = nextOpenRes ? Math.max(5 * 60 * 1e3, nextOpenRes.getTime() - nextOpen.getTime()) : Math.floor(durationMs / 2);
    const shiftedOpen = new Date(currentSlotEnd.getTime());
    const shiftedClose = new Date(shiftedOpen.getTime() + durationMs);
    const shiftedOpenRes = new Date(shiftedOpen.getTime() + openResOffsetMs);
    const istTime = getISTDateTime(shiftedOpen);
    const hh = String(istTime.hour).padStart(2, "0");
    const mm = String(istTime.minute).padStart(2, "0");
    let newName = nextGame.name;
    if (/Hourly Draw/i.test(nextGame.name)) {
      newName = `Hourly Draw (${hh}:${mm} IST)`;
    }
    await tx.game.update({
      where: { id: nextGame.id },
      data: {
        name: newName,
        openTime: shiftedOpen,
        openResultTime: shiftedOpenRes,
        closeResultTime: shiftedClose,
        closeTime: shiftedClose,
        resultTime: shiftedClose
      }
    });
    currentSlotEnd = shiftedClose;
    shiftedCount++;
  }
  await ensureNoOverlappingGames(tx);
  return shiftedCount;
}
function getGameCutoffs(game) {
  const openTime = new Date(game.openTime);
  const closeTime = new Date(game.closeTime);
  const openResultTime = game.openResultTime ? new Date(game.openResultTime) : new Date(openTime.getTime() + 30 * 60 * 1e3);
  const closeResultTime = game.closeResultTime ? new Date(game.closeResultTime) : closeTime;
  const openBetCutoff = new Date(openResultTime.getTime() - 5 * 60 * 1e3);
  const closeBetCutoff = new Date(closeResultTime.getTime() - 5 * 60 * 1e3);
  const now = /* @__PURE__ */ new Date();
  const isUpcoming = now.getTime() < openTime.getTime();
  const secondsUntilOpen = isUpcoming ? Math.max(0, Math.floor((openTime.getTime() - now.getTime()) / 1e3)) : 0;
  const isOpenLocked = Boolean(game.isLocked) || isUpcoming || now >= openBetCutoff;
  const isCloseLocked = Boolean(game.isLocked) || isUpcoming || now >= closeBetCutoff;
  const openSecondsLeft = isUpcoming ? 0 : Math.max(0, Math.floor((openBetCutoff.getTime() - now.getTime()) / 1e3));
  const closeSecondsLeft = isUpcoming ? 0 : Math.max(0, Math.floor((closeBetCutoff.getTime() - now.getTime()) / 1e3));
  return {
    openTime,
    openResultTime,
    closeResultTime,
    closeTime,
    openBetCutoff,
    closeBetCutoff,
    isUpcoming,
    secondsUntilOpen,
    isOpenLocked,
    isCloseLocked,
    openSecondsLeft,
    closeSecondsLeft
  };
}
function generatePana() {
  const d1 = Math.floor(Math.random() * 10);
  const d2 = Math.floor(Math.random() * 10);
  const d3 = Math.floor(Math.random() * 10);
  const sorted = [d1, d2, d3].sort((a, b) => {
    const valA = a === 0 ? 10 : a;
    const valB = b === 0 ? 10 : b;
    return valA - valB;
  });
  const pana = `${sorted[0]}${sorted[1]}${sorted[2]}`;
  const sum = (d1 + d2 + d3) % 10;
  return { pana, digit: String(sum) };
}
async function simulateThirdPartyDraw(options) {
  const {
    gameId,
    gameCode = "LOTTO",
    forceOutcome,
    provider = "MOCK_THIRD_PARTY_RNG_GATEWAY",
    simulateLatencyMs = 350
  } = options;
  if (simulateLatencyMs > 0) {
    await new Promise((resolve) => setTimeout(resolve, Math.min(simulateLatencyMs, 2e3)));
  }
  const now = /* @__PURE__ */ new Date();
  const externalDrawId = `EXT-DRAW-${gameId}-${Date.now().toString(36).toUpperCase()}-${Math.floor(1e3 + Math.random() * 9e3)}`;
  const randomEntropy = crypto2.randomBytes(32).toString("hex");
  const seedHash = crypto2.createHash("sha256").update(`${externalDrawId}:${gameCode}:${randomEntropy}:${now.toISOString()}`).digest("hex");
  let openLine;
  let openDigit;
  let closeLine;
  let closeDigit;
  let pair;
  let fullDraw;
  let winningNumber;
  if (forceOutcome && forceOutcome.trim()) {
    const raw = forceOutcome.trim();
    if (raw.includes("-")) {
      const parts = raw.split("-");
      if (parts.length === 3) {
        openLine = parts[0];
        pair = parts[1];
        closeLine = parts[2];
        openDigit = pair.length >= 1 ? pair[0] : "0";
        closeDigit = pair.length >= 2 ? pair[1] : "0";
      } else if (parts.length === 2) {
        if (parts[1].length === 1) {
          openLine = parts[0];
          closeDigit = parts[1];
          const sum = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
          openDigit = String(sum);
          pair = `${openDigit}${closeDigit}`;
          closeLine = "123";
        } else {
          openLine = parts[0];
          closeLine = parts[1];
          const s1 = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
          const s2 = closeLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
          openDigit = String(s1);
          closeDigit = String(s2);
          pair = `${openDigit}${closeDigit}`;
        }
      } else {
        openLine = "248";
        openDigit = "4";
        closeLine = "369";
        closeDigit = "8";
        pair = "48";
      }
      fullDraw = raw;
      winningNumber = raw;
    } else if (raw.length === 1) {
      openDigit = raw;
      closeDigit = raw;
      pair = `${raw}${raw}`;
      openLine = "124";
      closeLine = "248";
      fullDraw = raw;
      winningNumber = raw;
    } else if (raw.length === 2) {
      openDigit = raw[0];
      closeDigit = raw[1];
      pair = raw;
      openLine = "123";
      closeLine = "456";
      fullDraw = raw;
      winningNumber = raw;
    } else if (raw.length === 3) {
      openLine = raw;
      const sum = raw.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
      openDigit = String(sum);
      closeDigit = "0";
      closeLine = "123";
      pair = `${openDigit}${closeDigit}`;
      fullDraw = raw;
      winningNumber = raw;
    } else {
      openLine = "248";
      openDigit = "4";
      closeLine = "369";
      closeDigit = "8";
      pair = "48";
      fullDraw = raw;
      winningNumber = raw;
    }
  } else {
    const openRes = generatePana();
    const closeRes = generatePana();
    openLine = openRes.pana;
    openDigit = openRes.digit;
    closeLine = closeRes.pana;
    closeDigit = closeRes.digit;
    pair = `${openDigit}${closeDigit}`;
    fullDraw = `${openLine}-${pair}-${closeLine}`;
    winningNumber = fullDraw;
  }
  return {
    externalDrawId,
    provider,
    timestamp: now.toISOString(),
    seedHash,
    winningNumber,
    openLine,
    openDigit,
    closeLine,
    closeDigit,
    pair,
    fullDraw,
    status: "SUCCESS",
    simulated: true,
    note: "Temporary simulated outcome. Will be replaced by actual third-party endpoint once integrated."
  };
}
function splitSelectedNumber(selectedNumber, betType, providedOpen, providedClose, session) {
  const normSession = String(session || "").toUpperCase();
  if (providedOpen !== void 0 && providedClose !== void 0 && (providedOpen !== null || providedClose !== null)) {
    return {
      open: providedOpen ? String(providedOpen).trim() : null,
      close: providedClose ? String(providedClose).trim() : null
    };
  }
  const raw = String(selectedNumber || "").trim();
  const digits = raw.replace(/\D/g, "");
  const bType = String(betType || "").toLowerCase();
  if (normSession === "OPEN") {
    return {
      open: digits || (providedOpen ? String(providedOpen).trim() : null),
      close: null
    };
  }
  if (normSession === "CLOSE") {
    return {
      open: null,
      close: digits || (providedClose ? String(providedClose).trim() : null)
    };
  }
  if (raw.includes("-")) {
    const parts = raw.split("-");
    if (parts.length >= 2) {
      return {
        open: parts[0].trim() || null,
        close: parts[1].trim() || null
      };
    }
  }
  if (digits.length === 6) {
    return {
      open: digits.slice(0, 3),
      close: digits.slice(3, 6)
    };
  }
  if (digits.length === 4) {
    return {
      open: digits.slice(0, 3),
      close: digits.slice(3, 4)
    };
  }
  if (digits.length === 2) {
    return {
      open: digits[0],
      close: digits[1]
    };
  }
  if (digits.length === 3) {
    if (bType.includes("close")) {
      return { open: null, close: digits };
    }
    return {
      open: digits,
      close: null
    };
  }
  if (digits.length === 1) {
    if (bType.includes("close")) {
      return { open: null, close: digits };
    }
    return { open: digits, close: null };
  }
  return {
    open: providedOpen ? String(providedOpen).trim() : null,
    close: providedClose ? String(providedClose).trim() : null
  };
}
function categorizeBetSession(bet) {
  if (bet.session === "OPEN") return "OPEN";
  if (bet.session === "CLOSE") return "CLOSE";
  if (bet.session === "BOTH") return "BOTH";
  const bType = String(bet.betType || "").toLowerCase();
  if (bType.includes("jodi") || bType.includes("pair") || bType.includes("sangam") || bType.includes("half") || bType.includes("full")) {
    return "BOTH";
  }
  if (bet.open && bet.close) {
    return "BOTH";
  }
  if (bet.open && !bet.close) {
    return "OPEN";
  }
  if (!bet.open && bet.close) {
    return "CLOSE";
  }
  if (bType.includes("open") && !bType.includes("close")) {
    return "OPEN";
  }
  if (bType.includes("close") && !bType.includes("open")) {
    return "CLOSE";
  }
  return "BOTH";
}
function computeFullWinningNumberFrom6Digits(input) {
  const digits = String(input || "").replace(/\D/g, "");
  if (digits.length !== 6) return String(input || "").trim();
  const openLine = digits.slice(0, 3);
  const closeLine = digits.slice(3, 6);
  const s1 = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
  const s2 = closeLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
  const pair = `${s1}${s2}`;
  return `${openLine}-${pair}-${closeLine}`;
}
function parseWinningComponents(rawWin) {
  const raw = String(rawWin || "").trim();
  let openLine = "";
  let openDigit = "";
  let closeLine = "";
  let closeDigit = "";
  let pair = "";
  if (raw.includes("-")) {
    const parts = raw.split("-");
    if (parts.length === 3) {
      openLine = parts[0];
      pair = parts[1];
      closeLine = parts[2];
      openDigit = pair.length >= 1 ? pair[0] : openLine ? String(openLine.split("").reduce((a, c) => a + parseInt(c || "0", 10), 0) % 10) : "0";
      closeDigit = pair.length >= 2 ? pair[1] : closeLine ? String(closeLine.split("").reduce((a, c) => a + parseInt(c || "0", 10), 0) % 10) : "0";
    } else if (parts.length === 2) {
      if (parts[1].includes("*")) {
        openLine = parts[0];
        const cleanDigit = parts[1].replace(/\D/g, "");
        openDigit = cleanDigit.length > 0 ? cleanDigit[0] : openLine ? String(openLine.split("").reduce((a, c) => a + parseInt(c || "0", 10), 0) % 10) : "0";
        closeLine = "";
        closeDigit = "";
        pair = openDigit;
      } else if (parts[1].length === 1) {
        openLine = parts[0];
        closeDigit = parts[1];
        const sum = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
        openDigit = String(sum);
        pair = `${openDigit}${closeDigit}`;
        closeLine = "";
      } else {
        openLine = parts[0];
        closeLine = parts[1];
        const s1 = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
        const s2 = closeLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
        openDigit = String(s1);
        closeDigit = String(s2);
        pair = `${openDigit}${closeDigit}`;
      }
    } else {
      openLine = "248";
      openDigit = "4";
      closeLine = "369";
      closeDigit = "8";
      pair = "48";
    }
  } else if (raw.length === 6 && /^\d{6}$/.test(raw)) {
    openLine = raw.slice(0, 3);
    closeLine = raw.slice(3, 6);
    const s1 = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
    const s2 = closeLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
    openDigit = String(s1);
    closeDigit = String(s2);
    pair = `${openDigit}${closeDigit}`;
  } else if (raw.length === 1) {
    openDigit = raw;
    closeDigit = raw;
    pair = `${raw}${raw}`;
  } else if (raw.length === 2) {
    openDigit = raw[0];
    closeDigit = raw[1];
    pair = raw;
  } else if (raw.length === 3) {
    openLine = raw;
    const sum = raw.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
    openDigit = String(sum);
    pair = `${openDigit}0`;
  }
  const computedFullDraw = openLine && closeLine && pair ? `${openLine}-${pair}-${closeLine}` : raw;
  return {
    openLine,
    closeLine,
    openDigit,
    closeDigit,
    pair,
    fullDraw: computedFullDraw,
    winningNumber: computedFullDraw
  };
}
function evaluateBetWin(selectedNumber, betType, outcome, betOpen, betClose) {
  const sel = String(selectedNumber).trim();
  const bType = String(betType || "").toLowerCase();
  const win = String(outcome.winningNumber || outcome.fullDraw || "").trim();
  const resolved = splitSelectedNumber(sel, betType, betOpen, betClose);
  const openVal = resolved.open;
  const closeVal = resolved.close;
  if (sel === win || outcome.fullDraw && sel === outcome.fullDraw) {
    return true;
  }
  let openLine = outcome.openLine || outcome.openPana || "";
  let closeLine = outcome.closeLine || outcome.closePana || "";
  let openDigit = outcome.openDigit || "";
  let closeDigit = outcome.closeDigit || "";
  let pair = outcome.pair || "";
  if ((!pair || !openLine || !closeLine) && win.includes("-")) {
    const parsed = parseWinningComponents(win);
    openLine = openLine || parsed.openLine;
    closeLine = closeLine || parsed.closeLine;
    openDigit = openDigit || parsed.openDigit;
    closeDigit = closeDigit || parsed.closeDigit;
    pair = pair || parsed.pair;
  }
  if (bType.includes("full")) {
    if (openVal && closeVal && openLine && closeLine) {
      return openVal === openLine && closeVal === closeLine;
    }
    const expected = `${openLine}-${closeLine}`;
    return Boolean(openLine && closeLine && sel === expected);
  }
  if (bType.includes("half")) {
    if (openVal && closeVal) {
      if (openVal.length === 3 && closeVal.length === 1) {
        return openVal === openLine && closeVal === closeDigit;
      }
      if (openVal.length === 1 && closeVal.length === 3) {
        return openVal === openDigit && closeVal === closeLine;
      }
    }
    const expected1 = `${openLine}-${closeDigit}`;
    const expected2 = `${closeLine}-${openDigit}`;
    return Boolean(openLine && closeDigit && sel === expected1 || closeLine && openDigit && sel === expected2);
  }
  if (bType.includes("pair") || bType.includes("double") || bType.includes("jodi")) {
    if (openVal && closeVal && openDigit && closeDigit) {
      if (bType.includes("box")) {
        const selSorted = `${openVal}${closeVal}`.split("").sort().join("");
        const pairSorted = `${openDigit}${closeDigit}`.split("").sort().join("");
        if (selSorted === pairSorted) return true;
      } else {
        if (openVal === openDigit && closeVal === closeDigit) return true;
      }
    }
    if (pair && sel === pair) {
      return true;
    }
    if (win.includes("-")) {
      const parts = win.split("-");
      if (parts.length === 3 && sel === parts[1]) {
        return true;
      }
    }
    if (bType.includes("box") && pair) {
      const selSorted = sel.split("").sort().join("");
      const pairSorted = pair.split("").sort().join("");
      if (selSorted === pairSorted) return true;
    }
    return false;
  }
  if (bType.includes("line") || bType.includes("triple") || bType.includes("pana") || sel.length === 3 && !bType.includes("digit")) {
    const targetPana = openVal || sel;
    if (bType.includes("box")) {
      const selSorted = targetPana.split("").sort().join("");
      const openSorted = openLine.split("").sort().join("");
      const closeSorted = closeLine.split("").sort().join("");
      return openSorted && selSorted === openSorted || closeSorted && selSorted === closeSorted;
    }
    if (closeVal && !openVal) {
      return Boolean(closeLine && closeVal === closeLine);
    }
    return Boolean(openLine && targetPana === openLine || closeLine && targetPana === closeLine);
  }
  if ((bType.includes("digit") || bType.includes("single") || bType.includes("ank")) && !bType.includes("line")) {
    const targetDigit = openVal || closeVal || sel;
    if (openVal && !closeVal) {
      return targetDigit === openDigit;
    }
    if (closeVal && !openVal) {
      return targetDigit === closeDigit;
    }
    return targetDigit === openDigit || targetDigit === closeDigit || targetDigit === win;
  }
  if (bType.includes("box")) {
    const selSorted = sel.split("").sort().join("");
    const winDigits = win.replace(/\D/g, "");
    const winSorted = winDigits.split("").sort().join("");
    return selSorted === winSorted;
  }
  if (sel.length === 3) {
    return Boolean(openLine && sel === openLine || closeLine && sel === closeLine);
  }
  if (sel.length === 2 && pair) {
    return sel === pair;
  }
  if (sel.length === 1) {
    return sel === openDigit || sel === closeDigit;
  }
  return false;
}
function evaluateBetWinFromString(selectedNumber, betType, winningNumberStr, betOpen, betClose) {
  const components = parseWinningComponents(winningNumberStr);
  return evaluateBetWin(selectedNumber, betType, components, betOpen, betClose);
}
function isFullFortuneBet(bet) {
  return String(bet.betType || "").toLowerCase().includes("full");
}
function isHalfFortuneBet(bet) {
  return String(bet.betType || "").toLowerCase().includes("half");
}
function evaluateTieredBetWin(bet, winningNumber, openPanaDeclared, closePanaDeclared, payoutRules) {
  const isFullFortune = isFullFortuneBet(bet);
  const isHalfFortune = isHalfFortuneBet(bet);
  const isMultiStage = isFullFortune || isHalfFortune;
  const win = String(winningNumber || "").trim();
  const hasResult = Boolean(win && win.toLowerCase() !== "pending");
  const isGameCompleted = Boolean(
    hasResult && !win.includes("*") && (win.includes("-") || openPanaDeclared && closePanaDeclared)
  );
  const isOpenDeclaredOnly = Boolean(
    hasResult && !isGameCompleted && (win.includes("*") || openPanaDeclared && !closePanaDeclared)
  );
  const resolved = splitSelectedNumber(bet.selectedNumber, bet.betType, bet.open, bet.close);
  const openVal = resolved.open;
  const closeVal = resolved.close;
  const parsed = win.includes("-") ? parseWinningComponents(win) : null;
  const openLine = openPanaDeclared || parsed?.openLine || "";
  const closeLine = closePanaDeclared || parsed?.closeLine || "";
  const openDigit = parsed?.openDigit || "";
  const closeDigit = parsed?.closeDigit || "";
  let openPanaMultiplier = 100;
  let singleDigitMultiplier = 7;
  if (payoutRules && Array.isArray(payoutRules)) {
    const pRule = payoutRules.find((r) => r.betType.toLowerCase().includes("line") || r.betType.toLowerCase().includes("triple"));
    if (pRule && pRule.multiplier > 0) openPanaMultiplier = pRule.multiplier;
    const dRule = payoutRules.find((r) => r.betType.toLowerCase().includes("digit") && !r.betType.toLowerCase().includes("close"));
    if (dRule && dRule.multiplier > 0) singleDigitMultiplier = dRule.multiplier;
  }
  const alreadyRedeemed = Number(
    bet.redeemedAmount !== void 0 && bet.redeemedAmount !== null ? bet.redeemedAmount : bet.hasRedeemed || bet.payout?.status === "PAID" ? bet.payout?.winningAmount || bet.potentialPayout : 0
  ) || 0;
  if (!isMultiStage) {
    const isMatched = hasResult ? evaluateBetWinFromString(bet.selectedNumber, bet.betType || "", win, bet.open, bet.close) : false;
    const grossPrize = isMatched ? bet.potentialPayout : 0;
    const claimable = Math.max(0, grossPrize - alreadyRedeemed);
    let status = "AWAITING_DRAW";
    if (!hasResult) {
      status = "AWAITING_DRAW";
    } else if (isOpenDeclaredOnly && categorizeBetSession(bet) !== "OPEN") {
      status = "AWAITING_CLOSE";
    } else if (isMatched) {
      status = claimable > 0 ? "WINNER_UNCLAIMED" : "ALREADY_PAID";
    } else {
      status = "NON_WINNING";
    }
    return {
      isMultiStage: false,
      isOpenMatched: false,
      isCloseMatched: false,
      isFullJackpotWon: isMatched,
      openLegPrize: 0,
      fullJackpotPrize: bet.potentialPayout,
      grossWinningAmount: grossPrize,
      alreadyRedeemed,
      claimableAmount: claimable,
      canRedeemOpenNow: false,
      isAwaitingClose: isOpenDeclaredOnly && categorizeBetSession(bet) !== "OPEN",
      isFullySettled: !isMatched || claimable === 0,
      status,
      description: isMatched ? claimable > 0 ? `Winner! Claimable: INR ${claimable.toFixed(2)}` : "Winner \u2014 Already Redeemed in full" : hasResult ? "Did not match draw result" : "Awaiting draw result"
    };
  }
  let isOpenMatched = false;
  let openLegMultiplier = openPanaMultiplier;
  if (isFullFortune) {
    openLegMultiplier = openPanaMultiplier;
    isOpenMatched = Boolean(openVal && openLine && openVal === openLine);
  } else if (isHalfFortune) {
    if (openVal && openVal.length === 3) {
      openLegMultiplier = openPanaMultiplier;
      isOpenMatched = Boolean(openLine && openVal === openLine);
    } else if (openVal && openVal.length === 1) {
      openLegMultiplier = singleDigitMultiplier;
      isOpenMatched = Boolean(openDigit && openVal === openDigit);
    }
  }
  const openLegPrize = isOpenMatched ? bet.amount * openLegMultiplier : 0;
  const fullJackpotPrize = bet.potentialPayout;
  let isCloseMatched = false;
  if (isGameCompleted) {
    if (isFullFortune) {
      isCloseMatched = Boolean(closeVal && closeLine && closeVal === closeLine);
    } else if (isHalfFortune) {
      if (closeVal && closeVal.length === 3) {
        isCloseMatched = Boolean(closeLine && closeVal === closeLine);
      } else if (closeVal && closeVal.length === 1) {
        isCloseMatched = Boolean(closeDigit && closeVal === closeDigit);
      }
    }
  }
  const isFullJackpotWon = isOpenMatched && isCloseMatched;
  if (!hasResult) {
    return {
      isMultiStage: true,
      isOpenMatched: false,
      isCloseMatched: false,
      isFullJackpotWon: false,
      openLegPrize: 0,
      fullJackpotPrize,
      grossWinningAmount: 0,
      alreadyRedeemed,
      claimableAmount: 0,
      canRedeemOpenNow: false,
      isAwaitingClose: false,
      isFullySettled: false,
      status: "AWAITING_DRAW",
      description: "Awaiting draw result"
    };
  }
  if (isOpenDeclaredOnly) {
    if (isOpenMatched) {
      const grossWinningAmount = openLegPrize;
      const claimable = Math.max(0, openLegPrize - alreadyRedeemed);
      const canRedeemOpenNow = claimable > 0;
      const status = canRedeemOpenNow ? "PARTIAL_WINNER_UNCLAIMED" : "PARTIAL_PAID_AWAITING_CLOSE";
      const description = canRedeemOpenNow ? `Open Pana (${openVal}) matched! Eligible for INR ${claimable.toFixed(2)} partial redemption now. Close leg (INR ${fullJackpotPrize.toFixed(2)} Full Fortune Jackpot) awaiting Close draw.` : `Open Pana (${openVal}) matched and INR ${alreadyRedeemed.toFixed(2)} was redeemed. Close leg (INR ${fullJackpotPrize.toFixed(2)} Full Fortune Jackpot) awaiting Close draw.`;
      return {
        isMultiStage: true,
        isOpenMatched: true,
        isCloseMatched: false,
        isFullJackpotWon: false,
        openLegPrize,
        fullJackpotPrize,
        grossWinningAmount,
        alreadyRedeemed,
        claimableAmount: claimable,
        canRedeemOpenNow,
        isAwaitingClose: true,
        isFullySettled: false,
        status,
        description
      };
    } else {
      return {
        isMultiStage: true,
        isOpenMatched: false,
        isCloseMatched: false,
        isFullJackpotWon: false,
        openLegPrize: 0,
        fullJackpotPrize,
        grossWinningAmount: 0,
        alreadyRedeemed,
        claimableAmount: 0,
        canRedeemOpenNow: false,
        isAwaitingClose: false,
        isFullySettled: true,
        status: "NON_WINNING",
        description: `Open Pana (${openVal || "---"}) did not match Open outcome (${openLine || "---"}).`
      };
    }
  }
  if (isGameCompleted) {
    if (isFullJackpotWon) {
      const grossWinningAmount = fullJackpotPrize;
      const claimable = Math.max(0, fullJackpotPrize - alreadyRedeemed);
      const isFullySettled = claimable === 0;
      const status = isFullySettled ? "ALREADY_PAID" : "WINNER_UNCLAIMED";
      const description = isFullySettled ? `Full Fortune Jackpot (INR ${fullJackpotPrize.toFixed(2)}) fully settled and paid out.` : `FULL FORTUNE JACKPOT WINNER! Gross: INR ${fullJackpotPrize.toFixed(2)}${alreadyRedeemed > 0 ? `, Already Paid at Open: -INR ${alreadyRedeemed.toFixed(2)}` : ""}, Net Balance Payable: INR ${claimable.toFixed(2)}.`;
      return {
        isMultiStage: true,
        isOpenMatched: true,
        isCloseMatched: true,
        isFullJackpotWon: true,
        openLegPrize,
        fullJackpotPrize,
        grossWinningAmount,
        alreadyRedeemed,
        claimableAmount: claimable,
        canRedeemOpenNow: false,
        isAwaitingClose: false,
        isFullySettled,
        status,
        description
      };
    } else if (isOpenMatched) {
      const grossWinningAmount = openLegPrize;
      const claimable = Math.max(0, openLegPrize - alreadyRedeemed);
      const isFullySettled = claimable === 0;
      const status = isFullySettled ? "ALREADY_PAID" : "WINNER_UNCLAIMED";
      const description = isFullySettled ? `Open Pana (${openVal}) matched and INR ${alreadyRedeemed.toFixed(2)} was paid out. Close leg did not match.` : `Open Pana (${openVal}) matched! Eligible for INR ${claimable.toFixed(2)} Open consolation prize. Close leg did not match.`;
      return {
        isMultiStage: true,
        isOpenMatched: true,
        isCloseMatched: false,
        isFullJackpotWon: false,
        openLegPrize,
        fullJackpotPrize,
        grossWinningAmount,
        alreadyRedeemed,
        claimableAmount: claimable,
        canRedeemOpenNow: false,
        isAwaitingClose: false,
        isFullySettled,
        status,
        description
      };
    } else {
      return {
        isMultiStage: true,
        isOpenMatched: false,
        isCloseMatched: false,
        isFullJackpotWon: false,
        openLegPrize: 0,
        fullJackpotPrize,
        grossWinningAmount: 0,
        alreadyRedeemed,
        claimableAmount: 0,
        canRedeemOpenNow: false,
        isAwaitingClose: false,
        isFullySettled: true,
        status: "NON_WINNING",
        description: "Did not match winning combination"
      };
    }
  }
  return {
    isMultiStage: true,
    isOpenMatched: false,
    isCloseMatched: false,
    isFullJackpotWon: false,
    openLegPrize: 0,
    fullJackpotPrize,
    grossWinningAmount: 0,
    alreadyRedeemed,
    claimableAmount: 0,
    canRedeemOpenNow: false,
    isAwaitingClose: false,
    isFullySettled: true,
    status: "NON_WINNING",
    description: "Not a winning combination"
  };
}
async function executeGameDraw(options) {
  const { gameId, declaredById, forceOutcome, provider, simulateLatencyMs } = options;
  let game = await prisma.game.findUnique({
    where: { id: gameId }
  });
  if (!game) {
    game = await ensureHourlyGameExists(gameId);
  }
  if (!game.status) {
    throw new Error(`Cannot execute draw for Game #${gameId}. This game has been disabled by Admin.`);
  }
  const existingResult = await prisma.result.findUnique({
    where: { gameId }
  });
  if (existingResult) {
    if (existingResult.status === "OPEN_DECLARED") {
      return executeCloseDraw(options);
    }
    throw new Error(`Result already declared for Game #${gameId} (Winning Number: ${existingResult.winningNumber}). Existing results cannot be overridden.`);
  }
  const cutoffs = getGameCutoffs(game);
  const now = /* @__PURE__ */ new Date();
  if (now < cutoffs.closeBetCutoff) {
    throw new Error(
      `Cannot execute Full draw for Game #${gameId}. Wagering is active until ${formatISTTime(cutoffs.closeBetCutoff)} (5 minutes prior to close at ${formatISTTime(cutoffs.closeResultTime)}). If Open cutoff has passed, declare Open result first.`
    );
  }
  const drawOutcome = await simulateThirdPartyDraw({
    gameId,
    gameCode: game.code,
    forceOutcome,
    provider,
    simulateLatencyMs
  });
  const settlementResult = await prisma.$transaction(async (tx) => {
    const txExisting = await tx.result.findUnique({
      where: { gameId }
    });
    if (txExisting) {
      throw new Error(`Result already declared for Game #${gameId} (Winning Number: ${txExisting.winningNumber}). Existing results cannot be overridden.`);
    }
    const createdResult = await tx.result.create({
      data: {
        gameId,
        winningNumber: drawOutcome.winningNumber,
        status: "COMPLETED",
        openPana: drawOutcome.openLine,
        openDigit: drawOutcome.openDigit,
        closePana: drawOutcome.closeLine,
        closeDigit: drawOutcome.closeDigit,
        openDeclaredAt: new Date(drawOutcome.timestamp),
        closeDeclaredAt: new Date(drawOutcome.timestamp),
        declaredById: declaredById || null,
        declaredAt: new Date(drawOutcome.timestamp)
      },
      include: {
        game: { select: { id: true, name: true, code: true } },
        declaredBy: { select: { id: true, name: true, badgeId: true } }
      }
    });
    await tx.game.update({
      where: { id: gameId },
      data: {
        isLocked: true,
        resultTime: new Date(drawOutcome.timestamp)
      }
    });
    const activeBets = await tx.bet.findMany({
      where: {
        gameId,
        ticket: { status: "ACTIVE" }
      },
      include: {
        ticket: { select: { id: true, ticketNumber: true, status: true } }
      }
    });
    const winners = [];
    let totalWinningLiability = 0;
    for (const bet of activeBets) {
      const isMatched = evaluateBetWin(bet.selectedNumber, bet.betType, drawOutcome, bet.open, bet.close);
      if (isMatched) {
        const payout = await tx.payout.upsert({
          where: { betId: bet.id },
          create: {
            betId: bet.id,
            winningAmount: bet.potentialPayout,
            status: PayoutStatus.PENDING
          },
          update: {
            winningAmount: bet.potentialPayout
          }
        });
        winners.push({
          betId: bet.id,
          ticketNumber: bet.ticket.ticketNumber,
          selectedNumber: bet.selectedNumber,
          betType: bet.betType,
          stakeAmount: bet.amount,
          payoutAmount: bet.potentialPayout,
          payoutId: payout.id
        });
        totalWinningLiability += bet.potentialPayout;
      }
    }
    return {
      result: createdResult,
      totalCheckedBets: activeBets.length,
      winnersCount: winners.length,
      totalWinningLiability,
      winners
    };
  });
  return {
    game: {
      id: game.id,
      name: game.name,
      code: game.code,
      isLocked: true
    },
    result: settlementResult.result,
    drawOutcome,
    thirdPartySimulation: {
      provider: drawOutcome.provider,
      externalDrawReference: drawOutcome.externalDrawId,
      rngSeedHash: drawOutcome.seedHash,
      timestamp: drawOutcome.timestamp,
      simulated: true,
      note: drawOutcome.note
    },
    settlement: {
      totalCheckedBets: settlementResult.totalCheckedBets,
      winnersCount: settlementResult.winnersCount,
      totalWinningLiability: settlementResult.totalWinningLiability,
      winners: settlementResult.winners
    }
  };
}
async function executeOpenDraw(options) {
  const { gameId, declaredById, forceOutcome, provider = "CENTRAL_ADMIN_PROVABLY_FAIR_RNG", simulateLatencyMs = 0 } = options;
  if (simulateLatencyMs > 0) {
    await new Promise((r) => setTimeout(r, simulateLatencyMs));
  }
  const game = await prisma.game.findUnique({ where: { id: gameId } });
  if (!game) {
    throw new Error(`Game #${gameId} not found`);
  }
  if (!game.status) {
    throw new Error(`Cannot execute Open draw for Game #${gameId}. This game has been disabled by Admin.`);
  }
  const existingResult = await prisma.result.findUnique({ where: { gameId } });
  if (existingResult) {
    if (existingResult.status === "COMPLETED") {
      throw new Error(`Result already fully completed for Game #${gameId} (Winning Number: ${existingResult.winningNumber}).`);
    }
    if (existingResult.status === "OPEN_DECLARED") {
      throw new Error(`Open result is already declared for Game #${gameId} (Open: ${existingResult.openPana}-${existingResult.openDigit}).`);
    }
  }
  const cutoffs = getGameCutoffs(game);
  const now = /* @__PURE__ */ new Date();
  if (now < cutoffs.openBetCutoff) {
    throw new Error(
      `Cannot execute Open draw for Game #${gameId}. Open betting is currently active until ${formatISTTime(cutoffs.openBetCutoff)} (5 minutes prior to Open result at ${formatISTTime(cutoffs.openResultTime)}).`
    );
  }
  let openPanaStr;
  let openDigitStr;
  if (forceOutcome) {
    const rawDigits = String(forceOutcome).replace(/\D/g, "");
    if (rawDigits.length >= 3) {
      openPanaStr = rawDigits.slice(0, 3);
      const sum = openPanaStr.split("").reduce((acc, c) => acc + parseInt(c, 10), 0) % 10;
      openDigitStr = String(sum);
    } else {
      const p = generatePana();
      openPanaStr = p.pana;
      openDigitStr = p.digit;
    }
  } else {
    const p = generatePana();
    openPanaStr = p.pana;
    openDigitStr = p.digit;
  }
  const winningPreview = `${openPanaStr}-${openDigitStr}***`;
  const settlementResult = await prisma.$transaction(async (tx) => {
    const createdResult = await tx.result.upsert({
      where: { gameId },
      create: {
        gameId,
        winningNumber: winningPreview,
        status: "OPEN_DECLARED",
        openPana: openPanaStr,
        openDigit: openDigitStr,
        openDeclaredAt: now,
        declaredById: declaredById || null,
        declaredAt: now
      },
      update: {
        winningNumber: winningPreview,
        status: "OPEN_DECLARED",
        openPana: openPanaStr,
        openDigit: openDigitStr,
        openDeclaredAt: now,
        declaredById: declaredById || null
      },
      include: {
        game: { select: { id: true, name: true, code: true } },
        declaredBy: { select: { id: true, name: true, badgeId: true } }
      }
    });
    const activeBets = await tx.bet.findMany({
      where: {
        gameId,
        ticket: { status: "ACTIVE" }
      },
      include: {
        ticket: { select: { id: true, ticketNumber: true, status: true } }
      }
    });
    const openWinners = [];
    let totalWinningLiability = 0;
    for (const bet of activeBets) {
      if (categorizeBetSession(bet) === "OPEN") {
        if (evaluateBetWinFromString(bet.selectedNumber, bet.betType, winningPreview, bet.open, null)) {
          const payout = await tx.payout.upsert({
            where: { betId: bet.id },
            create: {
              betId: bet.id,
              winningAmount: bet.potentialPayout,
              status: PayoutStatus.PENDING
            },
            update: {
              winningAmount: bet.potentialPayout
            }
          });
          openWinners.push({
            betId: bet.id,
            ticketNumber: bet.ticket.ticketNumber,
            selectedNumber: bet.selectedNumber,
            betType: bet.betType,
            stakeAmount: bet.amount,
            payoutAmount: bet.potentialPayout,
            payoutId: payout.id
          });
          totalWinningLiability += bet.potentialPayout;
        }
      }
    }
    return {
      result: createdResult,
      totalCheckedBets: activeBets.length,
      winnersCount: openWinners.length,
      totalWinningLiability,
      winners: openWinners
    };
  });
  return {
    game: {
      id: game.id,
      name: game.name,
      code: game.code,
      isLocked: false
    },
    result: settlementResult.result,
    drawOutcome: {
      externalDrawId: `RNG-OPEN-${gameId}-${Date.now()}`,
      provider,
      timestamp: now.toISOString(),
      winningNumber: winningPreview,
      openLine: openPanaStr,
      openDigit: openDigitStr,
      closeLine: "",
      closeDigit: "",
      pair: "",
      fullDraw: winningPreview,
      status: "OPEN_DECLARED"
    },
    settlement: {
      totalCheckedBets: settlementResult.totalCheckedBets,
      winnersCount: settlementResult.winnersCount,
      totalWinningLiability: settlementResult.totalWinningLiability,
      winners: settlementResult.winners
    }
  };
}
async function executeCloseDraw(options) {
  const { gameId, declaredById, forceOutcome, provider = "CENTRAL_ADMIN_PROVABLY_FAIR_RNG", simulateLatencyMs = 0 } = options;
  if (simulateLatencyMs > 0) {
    await new Promise((r) => setTimeout(r, simulateLatencyMs));
  }
  const game = await prisma.game.findUnique({ where: { id: gameId } });
  if (!game) {
    throw new Error(`Game #${gameId} not found`);
  }
  if (!game.status) {
    throw new Error(`Cannot execute Close draw for Game #${gameId}. This game has been disabled by Admin.`);
  }
  const existingResult = await prisma.result.findUnique({ where: { gameId } });
  if (!existingResult || !existingResult.openPana) {
    throw new Error(`Cannot execute Close draw for Game #${gameId} because Open has not been declared yet. Please declare Open first.`);
  }
  if (existingResult.status === "COMPLETED" && existingResult.closePana) {
    throw new Error(`Game #${gameId} is already fully COMPLETED with winning number ${existingResult.winningNumber}.`);
  }
  const cutoffs = getGameCutoffs(game);
  const now = /* @__PURE__ */ new Date();
  if (now < cutoffs.closeBetCutoff) {
    throw new Error(
      `Cannot execute Close draw for Game #${gameId}. Close betting is currently active until ${formatISTTime(cutoffs.closeBetCutoff)} (5 minutes prior to Close result at ${formatISTTime(cutoffs.closeResultTime)}).`
    );
  }
  let closePanaStr;
  let closeDigitStr;
  if (forceOutcome) {
    const rawDigits = String(forceOutcome).replace(/\D/g, "");
    const sliceDigits = rawDigits.length >= 6 ? rawDigits.slice(3, 6) : rawDigits.slice(0, 3);
    if (sliceDigits.length === 3) {
      closePanaStr = sliceDigits;
      const sum = closePanaStr.split("").reduce((acc, c) => acc + parseInt(c, 10), 0) % 10;
      closeDigitStr = String(sum);
    } else {
      const p = generatePana();
      closePanaStr = p.pana;
      closeDigitStr = p.digit;
    }
  } else {
    const p = generatePana();
    closePanaStr = p.pana;
    closeDigitStr = p.digit;
  }
  const openPana = existingResult.openPana || "---";
  const openDigit = existingResult.openDigit || "0";
  const pair = `${openDigit}${closeDigitStr}`;
  const fullWinningNumber = `${openPana}-${pair}-${closePanaStr}`;
  const settlementResult = await prisma.$transaction(async (tx) => {
    const updatedResult = await tx.result.update({
      where: { gameId },
      data: {
        winningNumber: fullWinningNumber,
        status: "COMPLETED",
        closePana: closePanaStr,
        closeDigit: closeDigitStr,
        closeDeclaredAt: now,
        declaredAt: now,
        declaredById: declaredById || existingResult.declaredById
      },
      include: {
        game: { select: { id: true, name: true, code: true } },
        declaredBy: { select: { id: true, name: true, badgeId: true } }
      }
    });
    await tx.game.update({
      where: { id: gameId },
      data: {
        isLocked: true,
        resultTime: now
      }
    });
    const activeBets = await tx.bet.findMany({
      where: {
        gameId,
        ticket: { status: "ACTIVE" }
      },
      include: {
        ticket: { select: { id: true, ticketNumber: true, status: true } }
      }
    });
    const winners = [];
    let totalWinningLiability = 0;
    for (const bet of activeBets) {
      if (evaluateBetWinFromString(bet.selectedNumber, bet.betType, fullWinningNumber, bet.open, bet.close)) {
        if (bet.hasRedeemed) {
          continue;
        }
        const payout = await tx.payout.upsert({
          where: { betId: bet.id },
          create: {
            betId: bet.id,
            winningAmount: bet.potentialPayout,
            status: PayoutStatus.PENDING
          },
          update: {
            winningAmount: bet.potentialPayout
          }
        });
        winners.push({
          betId: bet.id,
          ticketNumber: bet.ticket.ticketNumber,
          selectedNumber: bet.selectedNumber,
          betType: bet.betType,
          stakeAmount: bet.amount,
          payoutAmount: bet.potentialPayout,
          payoutId: payout.id
        });
        totalWinningLiability += bet.potentialPayout;
      }
    }
    return {
      result: updatedResult,
      totalCheckedBets: activeBets.length,
      winnersCount: winners.length,
      totalWinningLiability,
      winners
    };
  });
  return {
    game: {
      id: game.id,
      name: game.name,
      code: game.code,
      isLocked: true
    },
    result: settlementResult.result,
    drawOutcome: {
      externalDrawId: `RNG-CLOSE-${gameId}-${Date.now()}`,
      provider,
      timestamp: now.toISOString(),
      winningNumber: fullWinningNumber,
      openLine: openPana,
      openDigit,
      closeLine: closePanaStr,
      closeDigit: closeDigitStr,
      pair,
      fullDraw: fullWinningNumber,
      status: "COMPLETED"
    },
    settlement: {
      totalCheckedBets: settlementResult.totalCheckedBets,
      winnersCount: settlementResult.winnersCount,
      totalWinningLiability: settlementResult.totalWinningLiability,
      winners: settlementResult.winners
    }
  };
}

// src/server/routes/games.ts
var router2 = Router2();
router2.get("/current", async (_req, res) => {
  try {
    const now = /* @__PURE__ */ new Date();
    const candidateGames = await prisma.game.findMany({
      where: {
        status: true,
        isLocked: false,
        results: { none: {} }
      },
      orderBy: { openTime: "asc" },
      include: {
        results: { take: 1 },
        _count: { select: { bets: true, results: true } }
      }
    });
    let activeLiveGame = candidateGames.find((g) => {
      const cutoffs2 = getGameCutoffs(g);
      const openTime = new Date(g.openTime);
      return openTime <= now && now < cutoffs2.closeBetCutoff;
    });
    if (!activeLiveGame) {
      activeLiveGame = candidateGames.find((g) => {
        const cutoffs2 = getGameCutoffs(g);
        return now < cutoffs2.closeBetCutoff;
      });
    }
    await ensureUpcomingHourlyGames(2);
    const game = activeLiveGame || await ensureHourlyGameExists();
    const windowInfo = getISTHourlyWindow();
    const cutoffs = getGameCutoffs(game);
    res.json({
      success: true,
      data: {
        ...game,
        drawNumber: `#${game.id}`,
        openBetCutoff: cutoffs.openBetCutoff,
        closeBetCutoff: cutoffs.closeBetCutoff,
        openCutoffFormatted: formatISTTime(cutoffs.openBetCutoff, { seconds: false, hour12: false }),
        closeCutoffFormatted: formatISTTime(cutoffs.closeBetCutoff, { seconds: false, hour12: false }),
        isOpenLocked: cutoffs.isOpenLocked,
        isCloseLocked: cutoffs.isCloseLocked,
        isUpcoming: cutoffs.isUpcoming,
        secondsUntilOpen: cutoffs.secondsUntilOpen,
        openSecondsLeft: cutoffs.openSecondsLeft,
        closeSecondsLeft: cutoffs.closeSecondsLeft,
        cutoffFormatted: formatISTTime(cutoffs.closeBetCutoff, { seconds: false, hour12: false }) || windowInfo.cutoffFormatted,
        cutoffSecondsLeft: cutoffs.closeSecondsLeft
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.get("/", async (req, res) => {
  try {
    const { status, isLocked, search } = req.query;
    await ensureUpcomingHourlyGames(12);
    await ensureNoOverlappingGames();
    const where = {};
    if (status !== void 0) {
      where.status = status === "true";
    }
    if (isLocked !== void 0) {
      where.isLocked = isLocked === "true";
    }
    if (search && typeof search === "string") {
      where.OR = [
        { name: { contains: search } },
        { code: { contains: search } }
      ];
    }
    const games = await prisma.game.findMany({
      where,
      orderBy: { openTime: "desc" },
      include: {
        results: {
          take: 1,
          orderBy: { declaredAt: "desc" }
        },
        _count: {
          select: {
            bets: true,
            results: true
          }
        }
      }
    });
    const enrichedGames = games.map((g) => {
      const cutoffs = getGameCutoffs(g);
      return {
        ...g,
        openBetCutoff: cutoffs.openBetCutoff,
        closeBetCutoff: cutoffs.closeBetCutoff,
        openCutoffFormatted: formatISTTime(cutoffs.openBetCutoff, { seconds: false, hour12: false }),
        closeCutoffFormatted: formatISTTime(cutoffs.closeBetCutoff, { seconds: false, hour12: false }),
        isOpenLocked: cutoffs.isOpenLocked,
        isCloseLocked: cutoffs.isCloseLocked,
        isUpcoming: cutoffs.isUpcoming,
        secondsUntilOpen: cutoffs.secondsUntilOpen,
        openSecondsLeft: cutoffs.openSecondsLeft,
        closeSecondsLeft: cutoffs.closeSecondsLeft,
        results: g.results.map((r) => {
          const components = parseWinningComponents(r.winningNumber);
          return {
            ...r,
            openLine: components.openLine,
            closeLine: components.closeLine,
            openDigit: components.openDigit,
            closeDigit: components.closeDigit,
            pair: components.pair,
            fullDraw: components.fullDraw,
            components
          };
        })
      };
    });
    res.json({ success: true, count: enrichedGames.length, data: enrichedGames });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.get("/lock-status", async (req, res) => {
  try {
    const rawId = req.query.gameId || req.query.id;
    if (!rawId) {
      return res.status(400).json({
        success: false,
        message: "gameId query parameter is required (e.g. /api/games/lock-status?gameId=2026101122)",
        GameStatus: "INVALID_ID"
      });
    }
    const id = parseInt(String(rawId));
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID", GameStatus: "INVALID_ID" });
    }
    let game = await prisma.game.findUnique({
      where: { id },
      select: { id: true, name: true, code: true, status: true, isLocked: true }
    });
    if (!game) {
      game = await ensureHourlyGameExists(id);
    }
    if (!game) {
      return res.status(404).json({ success: false, message: "Game not found", GameStatus: "NOT_FOUND" });
    }
    const GameStatus = game.isLocked ? "GAME_LOCKED" : "LIVE";
    res.json({
      success: true,
      gameId: game.id,
      isLocked: game.isLocked,
      GameStatus
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.get(["/lock-status/:id", "/:id/lock-status", "/:id/status"], async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID", GameStatus: "INVALID_ID" });
    }
    let game = await prisma.game.findUnique({
      where: { id },
      select: { id: true, name: true, code: true, status: true, isLocked: true }
    });
    if (!game) {
      game = await ensureHourlyGameExists(id);
    }
    if (!game) {
      return res.status(404).json({ success: false, message: "Game not found", GameStatus: "NOT_FOUND" });
    }
    const GameStatus = game.isLocked ? "GAME_LOCKED" : "LIVE";
    res.json({
      success: true,
      gameId: game.id,
      isLocked: game.isLocked,
      GameStatus
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID" });
    }
    let game = await prisma.game.findUnique({
      where: { id },
      include: {
        results: {
          orderBy: { declaredAt: "desc" },
          take: 5
        },
        _count: {
          select: { bets: true }
        }
      }
    });
    if (!game) {
      game = await ensureHourlyGameExists(id);
    }
    if (!game) {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    const enrichedGame = {
      ...game,
      results: game.results.map((r) => {
        const components = parseWinningComponents(r.winningNumber);
        return {
          ...r,
          openLine: components.openLine,
          closeLine: components.closeLine,
          openDigit: components.openDigit,
          closeDigit: components.closeDigit,
          pair: components.pair,
          fullDraw: components.fullDraw,
          components
        };
      })
    };
    res.json({ success: true, data: enrichedGame });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.post("/:id/trigger-draw", async (req, res) => {
  try {
    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ error: "Invalid game ID" });
    }
    const { declaredById, forceOutcome, provider, simulateLatencyMs, dryRun, targetPhase } = req.body || {};
    const game = await ensureHourlyGameExists(gameId);
    if (!game.status) {
      return res.status(400).json({
        error: `Cannot trigger draw for Game #${gameId}. This game has been disabled by Admin.`
      });
    }
    const phase = String(targetPhase || "FULL").toUpperCase();
    if (phase === "OPEN") {
      const drawResult2 = await executeOpenDraw({
        gameId,
        declaredById: declaredById ? parseInt(declaredById) : void 0,
        forceOutcome,
        provider,
        simulateLatencyMs
      });
      return res.json({
        gameId,
        gameid: gameId,
        drawDetails: {
          drawId: drawResult2.drawOutcome.externalDrawId,
          winningNumber: drawResult2.drawOutcome.winningNumber,
          openLine: drawResult2.drawOutcome.openLine,
          openDigit: drawResult2.drawOutcome.openDigit,
          pair: "",
          closeLine: "",
          closeDigit: "",
          fullDraw: drawResult2.drawOutcome.winningNumber,
          status: "OPEN_DECLARED",
          timestamp: drawResult2.drawOutcome.timestamp
        }
      });
    }
    if (phase === "CLOSE") {
      const drawResult2 = await executeCloseDraw({
        gameId,
        declaredById: declaredById ? parseInt(declaredById) : void 0,
        forceOutcome,
        provider,
        simulateLatencyMs
      });
      return res.json({
        gameId,
        gameid: gameId,
        drawDetails: {
          drawId: drawResult2.drawOutcome.externalDrawId,
          winningNumber: drawResult2.drawOutcome.winningNumber,
          openLine: drawResult2.drawOutcome.openLine,
          openDigit: drawResult2.drawOutcome.openDigit,
          pair: drawResult2.drawOutcome.pair,
          closeLine: drawResult2.drawOutcome.closeLine,
          closeDigit: drawResult2.drawOutcome.closeDigit,
          fullDraw: drawResult2.drawOutcome.fullDraw,
          status: "COMPLETED",
          timestamp: drawResult2.drawOutcome.timestamp
        }
      });
    }
    const drawResult = await executeGameDraw({
      gameId,
      declaredById: declaredById ? parseInt(declaredById) : void 0,
      forceOutcome,
      provider,
      simulateLatencyMs
    });
    res.json({
      gameId,
      gameid: gameId,
      drawDetails: {
        drawId: drawResult.drawOutcome.externalDrawId,
        winningNumber: drawResult.drawOutcome.winningNumber,
        openLine: drawResult.drawOutcome.openLine,
        openDigit: drawResult.drawOutcome.openDigit,
        pair: drawResult.drawOutcome.pair,
        closeLine: drawResult.drawOutcome.closeLine,
        closeDigit: drawResult.drawOutcome.closeDigit,
        fullDraw: drawResult.drawOutcome.fullDraw,
        status: drawResult.drawOutcome.status || "COMPLETED",
        timestamp: drawResult.drawOutcome.timestamp
      }
    });
  } catch (error) {
    console.error("Trigger game draw error:", error);
    res.status(500).json({ error: error.message });
  }
});
router2.post("/trigger-draw", async (req, res) => {
  try {
    const { gameId, gameid, declaredById, forceOutcome, provider, simulateLatencyMs, dryRun, targetPhase } = req.body || {};
    const rawId = gameId !== void 0 ? gameId : gameid;
    const parsedGameId = rawId !== void 0 && !isNaN(parseInt(rawId)) ? parseInt(rawId) : getCurrentISTGameId();
    const game = await ensureHourlyGameExists(parsedGameId);
    if (!game) {
      return res.status(404).json({ error: "Game not found" });
    }
    if (!game.status) {
      return res.status(400).json({
        error: `Cannot trigger draw for Game #${parsedGameId}. This game has been disabled by Admin.`
      });
    }
    const phase = String(targetPhase || "FULL").toUpperCase();
    if (phase === "OPEN") {
      const drawResult2 = await executeOpenDraw({
        gameId: parsedGameId,
        declaredById: declaredById ? parseInt(declaredById) : void 0,
        forceOutcome,
        provider,
        simulateLatencyMs
      });
      return res.json({
        gameId: parsedGameId,
        gameid: parsedGameId,
        drawDetails: {
          drawId: drawResult2.drawOutcome.externalDrawId,
          winningNumber: drawResult2.drawOutcome.winningNumber,
          openLine: drawResult2.drawOutcome.openLine,
          openDigit: drawResult2.drawOutcome.openDigit,
          pair: "",
          closeLine: "",
          closeDigit: "",
          fullDraw: drawResult2.drawOutcome.winningNumber,
          status: "OPEN_DECLARED",
          timestamp: drawResult2.drawOutcome.timestamp
        }
      });
    }
    if (phase === "CLOSE") {
      const drawResult2 = await executeCloseDraw({
        gameId: parsedGameId,
        declaredById: declaredById ? parseInt(declaredById) : void 0,
        forceOutcome,
        provider,
        simulateLatencyMs
      });
      return res.json({
        gameId: parsedGameId,
        gameid: parsedGameId,
        drawDetails: {
          drawId: drawResult2.drawOutcome.externalDrawId,
          winningNumber: drawResult2.drawOutcome.winningNumber,
          openLine: drawResult2.drawOutcome.openLine,
          openDigit: drawResult2.drawOutcome.openDigit,
          pair: drawResult2.drawOutcome.pair,
          closeLine: drawResult2.drawOutcome.closeLine,
          closeDigit: drawResult2.drawOutcome.closeDigit,
          fullDraw: drawResult2.drawOutcome.fullDraw,
          status: "COMPLETED",
          timestamp: drawResult2.drawOutcome.timestamp
        }
      });
    }
    const drawResult = await executeGameDraw({
      gameId: parsedGameId,
      declaredById: declaredById ? parseInt(declaredById) : void 0,
      forceOutcome,
      provider,
      simulateLatencyMs
    });
    res.json({
      gameId: parsedGameId,
      gameid: parsedGameId,
      drawDetails: {
        drawId: drawResult.drawOutcome.externalDrawId,
        winningNumber: drawResult.drawOutcome.winningNumber,
        openLine: drawResult.drawOutcome.openLine,
        openDigit: drawResult.drawOutcome.openDigit,
        pair: drawResult.drawOutcome.pair,
        closeLine: drawResult.drawOutcome.closeLine,
        closeDigit: drawResult.drawOutcome.closeDigit,
        fullDraw: drawResult.drawOutcome.fullDraw,
        status: drawResult.drawOutcome.status || "COMPLETED",
        timestamp: drawResult.drawOutcome.timestamp
      }
    });
  } catch (error) {
    console.error("Trigger game draw error:", error);
    res.status(500).json({ error: error.message });
  }
});
router2.post("/", async (req, res) => {
  try {
    const {
      name,
      code,
      openTime,
      openResultTime,
      closeResultTime,
      closeTime,
      resultTime,
      baseMultiplier,
      status,
      isLocked
    } = req.body;
    if (!name || !openTime) {
      return res.status(400).json({
        success: false,
        message: "Name and openTime are required"
      });
    }
    const now = /* @__PURE__ */ new Date();
    const parsedOpenTime = new Date(openTime);
    if (parsedOpenTime <= now) {
      return res.status(400).json({
        success: false,
        message: "Draw start time must be in the future."
      });
    }
    const parsedOpenResultTime = openResultTime ? new Date(openResultTime) : new Date(parsedOpenTime.getTime() + 30 * 60 * 1e3);
    const parsedCloseResultTime = closeResultTime ? new Date(closeResultTime) : closeTime ? new Date(closeTime) : resultTime ? new Date(resultTime) : new Date(parsedOpenTime.getTime() + 60 * 60 * 1e3);
    const parsedCloseTime = closeTime ? new Date(closeTime) : parsedCloseResultTime;
    const parsedResultTime = resultTime ? new Date(resultTime) : parsedCloseResultTime;
    if (parsedOpenResultTime <= parsedOpenTime) {
      return res.status(400).json({
        success: false,
        message: "Open Result time must be after Game Start time."
      });
    }
    if (parsedCloseResultTime <= parsedOpenResultTime) {
      return res.status(400).json({
        success: false,
        message: "Close Result time must be after Open Result time."
      });
    }
    const conflictingLiveGame = await prisma.game.findFirst({
      where: {
        status: true,
        openTime: { lte: now },
        closeTime: { gt: parsedOpenTime }
      }
    });
    if (conflictingLiveGame) {
      return res.status(400).json({
        success: false,
        message: `Cannot start draw at ${formatISTTime(parsedOpenTime)} because live draw #${conflictingLiveGame.id} (${conflictingLiveGame.name}) is active until ${formatISTTime(conflictingLiveGame.closeTime)}. Games cannot overlap.`
      });
    }
    const game = await prisma.game.create({
      data: {
        name,
        code: code || null,
        openTime: parsedOpenTime,
        openResultTime: parsedOpenResultTime,
        closeResultTime: parsedCloseResultTime,
        closeTime: parsedCloseTime,
        resultTime: parsedResultTime,
        baseMultiplier: baseMultiplier ? parseFloat(baseMultiplier) : 90,
        status: status !== void 0 ? Boolean(status) : true,
        isLocked: isLocked !== void 0 ? Boolean(isLocked) : false
      }
    });
    const shiftedCount = await rippleShiftSubsequentGames(parsedCloseTime, game.id);
    res.status(201).json({
      success: true,
      message: shiftedCount > 0 ? `Game created successfully! ${shiftedCount} subsequent draw(s) automatically shifted forward to prevent overlaps.` : "Game created successfully!",
      data: game,
      shiftedCount
    });
  } catch (error) {
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Game code already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID" });
    }
    const existingGame = await prisma.game.findUnique({
      where: { id },
      include: {
        _count: { select: { bets: true, results: true } }
      }
    });
    if (!existingGame) {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    const now = /* @__PURE__ */ new Date();
    if (new Date(existingGame.openTime) <= now) {
      return res.status(400).json({
        success: false,
        message: "Cannot edit a live or past draw. Only upcoming draws that have not started wagering yet can be modified."
      });
    }
    if (existingGame._count.bets > 0) {
      return res.status(400).json({
        success: false,
        message: "Cannot edit this draw because bets have already been placed on it."
      });
    }
    if (existingGame._count.results > 0) {
      return res.status(400).json({
        success: false,
        message: "Cannot modify draw: Result has already been declared."
      });
    }
    const {
      name,
      code,
      openTime,
      openResultTime,
      closeResultTime,
      closeTime,
      resultTime,
      baseMultiplier,
      status,
      isLocked
    } = req.body;
    const parsedOpenTime = openTime ? new Date(openTime) : new Date(existingGame.openTime);
    const parsedOpenResultTime = openResultTime ? new Date(openResultTime) : existingGame.openResultTime ? new Date(existingGame.openResultTime) : new Date(parsedOpenTime.getTime() + 30 * 60 * 1e3);
    const parsedCloseResultTime = closeResultTime ? new Date(closeResultTime) : closeTime ? new Date(closeTime) : existingGame.closeResultTime ? new Date(existingGame.closeResultTime) : new Date(parsedOpenTime.getTime() + 60 * 60 * 1e3);
    const parsedCloseTime = closeTime ? new Date(closeTime) : parsedCloseResultTime;
    const parsedResultTime = resultTime ? new Date(resultTime) : parsedCloseResultTime;
    if (parsedOpenTime <= now) {
      return res.status(400).json({
        success: false,
        message: "Draw start time must be in the future."
      });
    }
    if (parsedOpenResultTime <= parsedOpenTime) {
      return res.status(400).json({
        success: false,
        message: "Open Result time must be after Game Start time."
      });
    }
    if (parsedCloseResultTime <= parsedOpenResultTime) {
      return res.status(400).json({
        success: false,
        message: "Close Result time must be after Open Result time."
      });
    }
    const conflictingLiveGame = await prisma.game.findFirst({
      where: {
        id: { not: id },
        status: true,
        openTime: { lte: now },
        closeTime: { gt: parsedOpenTime }
      }
    });
    if (conflictingLiveGame) {
      return res.status(400).json({
        success: false,
        message: `Cannot start draw at ${formatISTTime(parsedOpenTime)} because live draw #${conflictingLiveGame.id} (${conflictingLiveGame.name}) is active until ${formatISTTime(conflictingLiveGame.closeTime)}. Games cannot overlap.`
      });
    }
    const game = await prisma.game.update({
      where: { id },
      data: {
        name,
        code: code || null,
        openTime: parsedOpenTime,
        openResultTime: parsedOpenResultTime,
        closeResultTime: parsedCloseResultTime,
        closeTime: parsedCloseTime,
        resultTime: parsedResultTime,
        baseMultiplier: baseMultiplier !== void 0 ? parseFloat(baseMultiplier) : void 0,
        status: status !== void 0 ? Boolean(status) : void 0,
        isLocked: isLocked !== void 0 ? Boolean(isLocked) : void 0
      }
    });
    const shiftedCount = await rippleShiftSubsequentGames(parsedCloseTime, id);
    res.json({
      success: true,
      message: shiftedCount > 0 ? `Draw #${id} updated! ${shiftedCount} subsequent draw(s) automatically shifted forward to maintain zero overlap.` : `Draw #${id} schedule updated successfully!`,
      data: game,
      shiftedCount
    });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID" });
    }
    if (req.body.status !== void 0 || req.body.isLocked !== void 0) {
      const existingGame = await prisma.game.findUnique({
        where: { id },
        include: { results: true }
      });
      if (existingGame) {
        const now = /* @__PURE__ */ new Date();
        const isTimeOver = existingGame.closeTime && new Date(existingGame.closeTime) <= now || existingGame.results.length > 0;
        if (isTimeOver) {
          return res.status(400).json({
            success: false,
            message: "Cannot modify game status or cutoff lock: Game time is over or result is already declared."
          });
        }
      }
    }
    const data = { ...req.body };
    if (data.openTime) data.openTime = new Date(data.openTime);
    if (data.openResultTime) data.openResultTime = new Date(data.openResultTime);
    if (data.closeResultTime) data.closeResultTime = new Date(data.closeResultTime);
    if (data.closeTime) data.closeTime = new Date(data.closeTime);
    if (data.resultTime) data.resultTime = new Date(data.resultTime);
    if (data.baseMultiplier !== void 0) data.baseMultiplier = parseFloat(data.baseMultiplier);
    const game = await prisma.game.update({
      where: { id },
      data
    });
    if (data.closeTime || data.closeResultTime || data.openTime) {
      const closeT = data.closeTime || data.closeResultTime || game.closeTime;
      await rippleShiftSubsequentGames(closeT, id);
    }
    res.json({ success: true, message: "Game updated successfully", data: game });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID" });
    }
    await prisma.game.delete({
      where: { id }
    });
    res.json({ success: true, message: "Game deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var games_default = router2;

// src/server/routes/tickets.ts
import { Router as Router3 } from "express";
import { TicketStatus, TransactionType, PaymentMode } from "@prisma/client";
var router3 = Router3();
async function generateUniqueTicketNumber(terminalId) {
  for (let attempt = 0; attempt < 10; attempt++) {
    const candidate = generateISTTicketId(/* @__PURE__ */ new Date(), terminalId);
    const existing = await prisma.ticket.findUnique({
      where: { ticketNumber: candidate },
      select: { id: true }
    });
    if (!existing) {
      return candidate;
    }
  }
  const dateStr = getISTDateString();
  const hex = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `TK-${dateStr}-${hex}`;
}
async function generateUniqueBarcode() {
  for (let attempt = 0; attempt < 10; attempt++) {
    const candidate = `${Date.now().toString().slice(-8)}${Math.floor(1e3 + Math.random() * 9e3)}`;
    const existing = await prisma.ticket.findUnique({
      where: { barcode: candidate },
      select: { id: true }
    });
    if (!existing) {
      return candidate;
    }
  }
  return `${Date.now()}${Math.floor(10 + Math.random() * 90)}`;
}
function generateSecurityCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}
router3.get("/", async (req, res) => {
  try {
    const { status, employeeId, gameId, tabletId, search, contact, startDate, endDate, date, limit = "50", offset = "0" } = req.query;
    const searchQuery = search || req.query.q;
    const where = {};
    if (status && Object.values(TicketStatus).includes(status)) {
      where.status = status;
    }
    if (employeeId) {
      where.employeeId = parseInt(employeeId);
    }
    if (gameId) {
      where.bets = {
        some: { gameId: parseInt(gameId) }
      };
    }
    if (tabletId && typeof tabletId === "string" && tabletId.trim()) {
      where.tabletId = tabletId.trim().toUpperCase();
    }
    if (contact && typeof contact === "string" && contact.trim()) {
      where.contact = { contains: contact.trim() };
    }
    if (searchQuery && typeof searchQuery === "string" && searchQuery.trim()) {
      const q = searchQuery.trim();
      where.OR = [
        { ticketNumber: { contains: q } },
        { barcode: { contains: q } },
        { securityCode: { contains: q } },
        { contact: { contains: q } },
        { tabletId: { contains: q } }
      ];
    }
    const targetStartDate = startDate || date;
    const targetEndDate = endDate || date;
    if (targetStartDate || targetEndDate) {
      where.createdAt = {};
      if (targetStartDate) {
        const [y, m, d] = targetStartDate.split("-").map(Number);
        const startUtc = new Date(Date.UTC(y, m - 1, d, 0, 0, 0, 0) - 5.5 * 3600 * 1e3);
        where.createdAt.gte = startUtc;
      }
      if (targetEndDate) {
        const [y, m, d] = targetEndDate.split("-").map(Number);
        const endUtc = new Date(Date.UTC(y, m - 1, d, 23, 59, 59, 999) - 5.5 * 3600 * 1e3);
        where.createdAt.lte = endUtc;
      }
    }
    const take = parseInt(limit) || 50;
    const skip = parseInt(offset) || 0;
    const [total, tickets] = await Promise.all([
      prisma.ticket.count({ where }),
      prisma.ticket.findMany({
        where,
        take,
        skip,
        orderBy: { createdAt: "desc" },
        include: {
          employee: {
            select: { id: true, name: true, badgeId: true }
          },
          bets: {
            include: {
              game: {
                select: {
                  id: true,
                  name: true,
                  code: true,
                  status: true,
                  isLocked: true,
                  openTime: true,
                  openResultTime: true,
                  closeResultTime: true,
                  closeTime: true,
                  results: true
                }
              },
              payout: true
            }
          },
          transactions: true
        }
      })
    ]);
    res.json({
      success: true,
      total,
      count: tickets.length,
      limit: take,
      offset: skip,
      data: tickets
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.get("/tablet-summary", async (req, res) => {
  try {
    const { gameId, startDate, endDate, date } = req.query;
    const where = {};
    if (gameId && gameId !== "ALL") {
      const gid = parseInt(gameId, 10);
      if (!isNaN(gid)) {
        where.bets = {
          some: { gameId: gid }
        };
      }
    }
    const targetStartDate = startDate || date;
    const targetEndDate = endDate || date;
    if (targetStartDate || targetEndDate) {
      where.createdAt = {};
      if (targetStartDate) {
        const [y, m, d] = targetStartDate.split("-").map(Number);
        const startUtc = new Date(Date.UTC(y, m - 1, d, 0, 0, 0, 0) - 5.5 * 3600 * 1e3);
        where.createdAt.gte = startUtc;
      }
      if (targetEndDate) {
        const [y, m, d] = targetEndDate.split("-").map(Number);
        const endUtc = new Date(Date.UTC(y, m - 1, d, 23, 59, 59, 999) - 5.5 * 3600 * 1e3);
        where.createdAt.lte = endUtc;
      }
    }
    const tickets = await prisma.ticket.findMany({
      where,
      select: {
        id: true,
        tabletId: true,
        employeeId: true,
        totalAmount: true,
        status: true,
        createdAt: true,
        employee: {
          select: {
            id: true,
            name: true,
            badgeId: true,
            role: true
          }
        }
      }
    });
    const tablets = await prisma.tablet.findMany({
      select: { tabletId: true, name: true, ownerId: true }
    });
    const tabletNameMap = /* @__PURE__ */ new Map();
    for (const t of tablets) {
      if (t.tabletId) {
        tabletNameMap.set(t.tabletId.toUpperCase(), t.name || t.tabletId);
      }
    }
    const groups = /* @__PURE__ */ new Map();
    for (const t of tickets) {
      const cleanTabId = t.tabletId ? t.tabletId.trim().toUpperCase() : "CAGE / DESK";
      const empId = t.employeeId || 0;
      const groupKey = `${cleanTabId}:::${empId}`;
      let acc = groups.get(groupKey);
      if (!acc) {
        const friendlyTabletName = cleanTabId === "CAGE / DESK" ? "Cage Terminal / Central Desk" : tabletNameMap.get(cleanTabId) || `Tablet (${cleanTabId})`;
        acc = {
          tabletId: cleanTabId,
          tabletName: friendlyTabletName,
          employeeId: empId,
          operatorName: t.employee?.name || `Operator #${empId}`,
          operatorBadge: t.employee?.badgeId || `EMP-${empId}`,
          soldCount: 0,
          soldAmount: 0,
          voidCount: 0,
          voidAmount: 0,
          totalCount: 0,
          netAmount: 0
        };
        groups.set(groupKey, acc);
      }
      const amount = typeof t.totalAmount === "number" ? t.totalAmount : parseFloat(t.totalAmount || 0);
      acc.totalCount += 1;
      if (t.status === TicketStatus.CANCELLED || t.status === "VOID") {
        acc.voidCount += 1;
        acc.voidAmount += amount;
      } else {
        acc.soldCount += 1;
        acc.soldAmount += amount;
      }
      acc.netAmount = acc.soldAmount - acc.voidAmount;
    }
    const summaryData = Array.from(groups.values()).sort((a, b) => {
      if (a.tabletId === "CAGE / DESK") return 1;
      if (b.tabletId === "CAGE / DESK") return -1;
      const tabComp = a.tabletId.localeCompare(b.tabletId);
      if (tabComp !== 0) return tabComp;
      return a.operatorName.localeCompare(b.operatorName);
    });
    const uniqueTablets = new Set(summaryData.map((d) => d.tabletId));
    const uniqueOperators = new Set(summaryData.map((d) => d.employeeId));
    const totals = summaryData.reduce(
      (sum, item) => ({
        totalTabletsCount: uniqueTablets.size,
        totalOperatorsCount: uniqueOperators.size,
        totalTicketsSold: sum.totalTicketsSold + item.soldCount,
        totalSoldAmount: sum.totalSoldAmount + item.soldAmount,
        totalVoidTickets: sum.totalVoidTickets + item.voidCount,
        totalVoidAmount: sum.totalVoidAmount + item.voidAmount,
        totalTicketsCount: sum.totalTicketsCount + item.totalCount,
        totalNetSales: sum.totalNetSales + item.netAmount
      }),
      {
        totalTabletsCount: uniqueTablets.size,
        totalOperatorsCount: uniqueOperators.size,
        totalTicketsSold: 0,
        totalSoldAmount: 0,
        totalVoidTickets: 0,
        totalVoidAmount: 0,
        totalTicketsCount: 0,
        totalNetSales: 0
      }
    );
    res.json({
      success: true,
      filters: {
        gameId: gameId ? String(gameId) : "ALL",
        startDate: targetStartDate || null,
        endDate: targetEndDate || null,
        date: date ? String(date) : null
      },
      totals,
      data: summaryData
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.get("/:id", async (req, res) => {
  try {
    const param = req.params.id;
    const isNum = !isNaN(parseInt(param));
    const ticket = await prisma.ticket.findFirst({
      where: isNum ? { OR: [{ id: parseInt(param) }, { ticketNumber: param }, { barcode: param }, { contact: param }] } : { OR: [{ ticketNumber: param }, { barcode: param }, { contact: param }] },
      include: {
        employee: {
          select: { id: true, name: true, badgeId: true, role: true }
        },
        bets: {
          include: {
            game: true,
            payout: true
          }
        },
        transactions: {
          orderBy: { createdAt: "desc" }
        }
      }
    });
    if (!ticket) {
      return res.status(404).json({ success: false, message: "Ticket not found" });
    }
    res.json({ success: true, data: ticket });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.post("/", async (req, res) => {
  try {
    const { employeeId, bets, paymentMode = "CASH", totalAmount, terminalId, contact, customerPhone } = req.body;
    const rawIdempotencyKey = req.headers["x-idempotency-key"] || req.headers["idempotency-key"] || req.body.idempotencyKey;
    const idempotencyKey = rawIdempotencyKey ? String(rawIdempotencyKey).trim() : void 0;
    if (!employeeId || !Array.isArray(bets) || bets.length === 0) {
      return res.status(400).json({
        success: false,
        message: "employeeId and a non-empty array of bets are required"
      });
    }
    if (idempotencyKey) {
      const existingTicket = await prisma.ticket.findUnique({
        where: { idempotencyKey },
        include: {
          employee: { select: { id: true, name: true, badgeId: true } },
          bets: { include: { game: true } },
          transactions: true
        }
      });
      if (existingTicket) {
        return res.status(200).json({
          success: true,
          isDuplicate: true,
          message: "Ticket already issued (idempotent replay)",
          data: existingTicket
        });
      }
    }
    let employee = null;
    const parsedId = parseInt(employeeId);
    if (!isNaN(parsedId)) {
      employee = await prisma.employee.findUnique({
        where: { id: parsedId }
      });
    }
    if (!employee || !employee.status) {
      employee = await prisma.employee.findFirst({
        where: {
          OR: [
            { badgeId: String(employeeId) },
            { name: String(employeeId) },
            { role: "OPERATOR", status: true }
          ]
        }
      });
    }
    if (!employee || !employee.status) {
      return res.status(400).json({ success: false, message: "Invalid or inactive employee" });
    }
    const effectiveTabletId = req.body.tabletId || req.headers["x-tablet-id"] || terminalId;
    if (effectiveTabletId) {
      const cleanTabletId = effectiveTabletId.trim().toUpperCase();
      const tabletRecord = await prisma.tablet.findUnique({
        where: { tabletId: cleanTabletId }
      });
      if (tabletRecord && tabletRecord.status === false) {
        return res.status(403).json({
          success: false,
          isBlocked: true,
          message: `ACCESS DENIED: Tablet "${tabletRecord.tabletId}" has been disabled by Administrator. Ticket issuance is strictly prohibited from this device.`
        });
      }
    }
    const calculatedTotal = bets.reduce((sum, b) => sum + (parseFloat(b.amount) || 0), 0);
    const finalTotal = totalAmount !== void 0 ? parseFloat(totalAmount) : calculatedTotal;
    let contactValue = null;
    if (contact || customerPhone) {
      const sanitized = String(contact || customerPhone).replace(/\D/g, "").slice(0, 10);
      if (sanitized) {
        if (/^0+$/.test(sanitized)) {
          return res.status(400).json({ success: false, message: "Contact number cannot consist solely of zeros" });
        }
        if (sanitized.length !== 10) {
          return res.status(400).json({ success: false, message: "Contact number must be exactly 10 digits" });
        }
        contactValue = sanitized;
      }
    }
    let newTicket = null;
    for (let attempt = 0; attempt < 5; attempt++) {
      try {
        const ticketNum = await generateUniqueTicketNumber(terminalId);
        const barcode = await generateUniqueBarcode();
        const secCode = generateSecurityCode();
        newTicket = await prisma.$transaction(async (tx) => {
          const createdTicket = await tx.ticket.create({
            data: {
              ticketNumber: ticketNum,
              barcode,
              securityCode: secCode,
              contact: contactValue,
              employeeId: employee.id,
              tabletId: effectiveTabletId ? effectiveTabletId.trim().toUpperCase() : null,
              totalAmount: finalTotal,
              status: TicketStatus.ACTIVE,
              idempotencyKey: idempotencyKey || null
            }
          });
          if (effectiveTabletId) {
            try {
              const clientIp = req.headers["x-forwarded-for"] || req.socket.remoteAddress || null;
              await tx.tablet.updateMany({
                where: { tabletId: effectiveTabletId.trim().toUpperCase() },
                data: {
                  lastUsed: /* @__PURE__ */ new Date(),
                  ...clientIp ? { ipAddress: clientIp.split(",")[0].trim() } : {}
                }
              });
            } catch {
            }
          }
          const currentHourlyGameId = getCurrentISTGameId();
          await ensureHourlyGameExists(currentHourlyGameId, tx);
          for (const b of bets) {
            const betAmount = parseFloat(b.amount) || 10;
            const multiplier = parseFloat(b.multiplier) || 90;
            const potentialPayout = parseFloat(b.potentialPayout) || betAmount * multiplier;
            const rawGameId = parseInt(b.gameId);
            const resolvedGameId = !isNaN(rawGameId) && rawGameId > 0 ? rawGameId : currentHourlyGameId;
            const targetGame = await ensureHourlyGameExists(resolvedGameId, tx);
            if (!targetGame) {
              const err = new Error(`Game #${resolvedGameId} not found`);
              err.statusCode = 404;
              throw err;
            }
            if (!targetGame.status) {
              const err = new Error(`Game #${resolvedGameId} (${targetGame.name}) is disabled by Admin. Wagering is suspended for this draw.`);
              err.statusCode = 400;
              throw err;
            }
            if (targetGame.isLocked) {
              const err = new Error(`Game #${resolvedGameId} (${targetGame.name}) is locked. Wagering has closed for this draw.`);
              err.statusCode = 400;
              throw err;
            }
            const cutoffs = getGameCutoffs(targetGame);
            const now = /* @__PURE__ */ new Date();
            if (targetGame.openTime && now < new Date(targetGame.openTime)) {
              const err = new Error(
                `Wagering for Game #${resolvedGameId} (${targetGame.name}) has not started yet. Opens at ${formatISTTime(new Date(targetGame.openTime))}.`
              );
              err.statusCode = 400;
              throw err;
            }
            if (now >= cutoffs.closeBetCutoff) {
              const err = new Error(
                `Wagering for Game #${resolvedGameId} (${targetGame.name}) closed at ${formatISTTime(cutoffs.closeBetCutoff)} (5 minutes prior to Close result at ${formatISTTime(cutoffs.closeResultTime)}).`
              );
              err.statusCode = 400;
              throw err;
            }
            let betSession = "BOTH";
            if (b.session) {
              betSession = String(b.session).toUpperCase();
            } else if (b.open && !b.close) {
              betSession = "OPEN";
            } else if (!b.open && b.close) {
              betSession = "CLOSE";
            } else {
              const bType = String(b.betType || "").toLowerCase();
              if (bType.includes("open") && !bType.includes("close")) {
                betSession = "OPEN";
              } else if (bType.includes("close") && !bType.includes("open")) {
                betSession = "CLOSE";
              } else {
                betSession = "BOTH";
              }
            }
            if (betSession === "OPEN" || betSession === "BOTH") {
              if (now >= cutoffs.openBetCutoff) {
                const err = new Error(
                  `Open betting on Game #${resolvedGameId} (${targetGame.name}) closed at ${formatISTTime(cutoffs.openBetCutoff)} (5 minutes prior to Open result at ${formatISTTime(cutoffs.openResultTime)}). Only Close bets are accepted until ${formatISTTime(cutoffs.closeBetCutoff)}.`
                );
                err.statusCode = 400;
                throw err;
              }
            }
            if (betSession === "CLOSE") {
              if (now >= cutoffs.closeBetCutoff) {
                const err = new Error(
                  `Close betting on Game #${resolvedGameId} (${targetGame.name}) closed at ${formatISTTime(cutoffs.closeBetCutoff)} (5 minutes prior to Close result at ${formatISTTime(cutoffs.closeResultTime)}).`
                );
                err.statusCode = 400;
                throw err;
              }
            }
            const { open: resolvedOpen, close: resolvedClose } = splitSelectedNumber(
              String(b.selectedNumber),
              b.betType,
              b.open,
              b.close,
              betSession
            );
            await tx.bet.create({
              data: {
                ticketId: createdTicket.id,
                gameId: resolvedGameId,
                selectedNumber: String(b.selectedNumber),
                open: resolvedOpen,
                close: resolvedClose,
                session: betSession,
                betType: b.betType || "Single",
                amount: betAmount,
                multiplier,
                potentialPayout
              }
            });
          }
          const validPaymentMode = Object.values(PaymentMode).includes(paymentMode) ? paymentMode : PaymentMode.CASH;
          await tx.transaction.create({
            data: {
              ticketId: createdTicket.id,
              employeeId: employee.id,
              type: TransactionType.SALE,
              amount: finalTotal,
              paymentMode: validPaymentMode,
              referenceNote: `Ticket sale: ${ticketNum}`,
              idempotencyKey: idempotencyKey ? `sale-${idempotencyKey}` : null
            }
          });
          return await tx.ticket.findUnique({
            where: { id: createdTicket.id },
            include: {
              employee: { select: { id: true, name: true, badgeId: true } },
              bets: { include: { game: true } },
              transactions: true
            }
          });
        });
        break;
      } catch (txErr) {
        if (txErr.code === "P2002") {
          if (idempotencyKey) {
            const existing = await prisma.ticket.findUnique({
              where: { idempotencyKey },
              include: {
                employee: { select: { id: true, name: true, badgeId: true } },
                bets: { include: { game: true } },
                transactions: true
              }
            });
            if (existing) {
              return res.status(200).json({
                success: true,
                isDuplicate: true,
                message: "Ticket already issued (idempotent replay)",
                data: existing
              });
            }
          }
          if (attempt < 4) {
            console.warn(`[Tickets] Concurrent collision detected on attempt ${attempt + 1}, retrying with new ticket number...`);
            continue;
          }
        }
        throw txErr;
      }
    }
    res.status(201).json({
      success: true,
      message: "Ticket issued successfully",
      data: newTicket
    });
  } catch (error) {
    const status = error.statusCode || 500;
    res.status(status).json({ success: false, message: error.message });
  }
});
router3.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid ticket ID" });
    }
    const { status, totalAmount, contact } = req.body;
    const updateData = {};
    if (status && Object.values(TicketStatus).includes(status)) {
      updateData.status = status;
    }
    if (totalAmount !== void 0) {
      updateData.totalAmount = parseFloat(totalAmount);
    }
    if (contact !== void 0) {
      updateData.contact = contact ? String(contact).trim() : null;
    }
    const ticket = await prisma.ticket.update({
      where: { id },
      data: updateData,
      include: { bets: true, transactions: true }
    });
    res.json({ success: true, message: "Ticket updated successfully", data: ticket });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Ticket not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid ticket ID" });
    }
    const patchData = { ...req.body };
    if (patchData.contact !== void 0) {
      patchData.contact = patchData.contact ? String(patchData.contact).trim() : null;
    }
    const ticket = await prisma.ticket.update({
      where: { id },
      data: patchData
    });
    res.json({ success: true, message: "Ticket patched successfully", data: ticket });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Ticket not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid ticket ID" });
    }
    await prisma.ticket.delete({
      where: { id }
    });
    res.json({ success: true, message: "Ticket deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Ticket not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.post(["/:id/cancel", "/:id/void"], async (req, res) => {
  try {
    const param = req.params.id;
    const isNum = !isNaN(parseInt(param));
    const { employeeId, reason } = req.body;
    const rawIdempotencyKey = req.headers["x-idempotency-key"] || req.headers["idempotency-key"] || req.body.idempotencyKey;
    const idempotencyKey = rawIdempotencyKey ? String(rawIdempotencyKey).trim() : void 0;
    if (idempotencyKey) {
      const existingRefundTx = await prisma.transaction.findUnique({
        where: { idempotencyKey: `refund-${idempotencyKey}` },
        include: { ticket: true }
      });
      if (existingRefundTx) {
        return res.json({
          success: true,
          isDuplicate: true,
          message: "Ticket void and refund already processed (idempotent replay)",
          data: existingRefundTx.ticket
        });
      }
    }
    const result = await prisma.$transaction(async (tx) => {
      const ticket = await tx.ticket.findFirst({
        where: isNum ? { OR: [{ id: parseInt(param) }, { ticketNumber: param }, { barcode: param }] } : { OR: [{ ticketNumber: param }, { barcode: param }] },
        include: { bets: true }
      });
      if (!ticket) {
        throw new Error("Ticket not found");
      }
      if (ticket.status === TicketStatus.VOID || ticket.status === TicketStatus.CANCELLED) {
        return { ticket, alreadyVoided: true };
      }
      if (ticket.status !== TicketStatus.ACTIVE) {
        throw new Error(`Cannot void ticket with status: ${ticket.status}`);
      }
      const updatedTicket = await tx.ticket.update({
        where: { id: ticket.id },
        data: { status: TicketStatus.VOID }
      });
      const refundIdempotencyKey = idempotencyKey ? `refund-${idempotencyKey}` : `refund-ticket-${ticket.id}`;
      await tx.transaction.create({
        data: {
          ticketId: ticket.id,
          employeeId: employeeId ? parseInt(employeeId) : ticket.employeeId,
          type: TransactionType.REFUND,
          amount: ticket.totalAmount,
          paymentMode: PaymentMode.CASH,
          referenceNote: reason || "Operator void ticket cancellation",
          idempotencyKey: refundIdempotencyKey
        }
      });
      await tx.transaction.updateMany({
        where: { ticketId: ticket.id, type: TransactionType.SALE },
        data: {
          referenceNote: "SALE (Voided & Refunded)"
        }
      });
      if (employeeId) {
        const emp = await tx.employee.findUnique({ where: { id: parseInt(employeeId) } });
        if (emp && emp.role === "CAGE_OPERATOR") {
          const activeCage = await tx.cage.findFirst({
            where: { OR: [{ operatorId: emp.id }, { status: "OPEN" }] },
            orderBy: { id: "asc" }
          });
          if (activeCage) {
            await tx.cage.update({
              where: { id: activeCage.id },
              data: {
                currentBalance: Math.max(0, activeCage.currentBalance - ticket.totalAmount)
              }
            });
          }
        }
      }
      return { ticket: updatedTicket, alreadyVoided: false };
    });
    res.json({
      success: true,
      isDuplicate: result.alreadyVoided,
      message: result.alreadyVoided ? "Ticket was already voided (idempotent replay)" : "Ticket voided and refunded successfully",
      data: result.ticket
    });
  } catch (error) {
    if (error.code === "P2002") {
      return res.json({
        success: true,
        isDuplicate: true,
        message: "Ticket void already processed concurrently (idempotent replay)"
      });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.patch("/:id/bets/:betId/amount", async (req, res) => {
  try {
    const ticketParam = req.params.id;
    const isNum = !isNaN(parseInt(ticketParam));
    const betId = parseInt(req.params.betId);
    const newAmount = parseFloat(req.body.amount);
    if (isNaN(betId) || isNaN(newAmount) || newAmount <= 0) {
      return res.status(400).json({ success: false, message: "Valid betId and a positive amount are required" });
    }
    const updated = await prisma.$transaction(async (tx) => {
      const ticket = await tx.ticket.findFirst({
        where: isNum ? { OR: [{ id: parseInt(ticketParam) }, { ticketNumber: ticketParam }, { barcode: ticketParam }] } : { OR: [{ ticketNumber: ticketParam }, { barcode: ticketParam }] },
        include: {
          bets: {
            include: {
              game: {
                include: { results: true }
              }
            }
          },
          transactions: true
        }
      });
      if (!ticket) {
        throw new Error("Ticket not found");
      }
      if (ticket.status !== TicketStatus.ACTIVE) {
        throw new Error(`Cannot change bet amount on ticket with status: ${ticket.status}`);
      }
      const targetBet = ticket.bets.find((b) => b.id === betId);
      if (!targetBet) {
        throw new Error(`Bet #${betId} not found on ticket ${ticket.ticketNumber}`);
      }
      const game = targetBet.game;
      if (game) {
        const latestResult = game.results && game.results.length > 0 ? game.results[0] : null;
        const isGameCompleted = Boolean(
          latestResult && (latestResult.status === "COMPLETED" || !latestResult.winningNumber.includes("*") && latestResult.winningNumber.includes("-"))
        );
        const isOpenDeclared = Boolean(
          latestResult && (latestResult.status === "OPEN_DECLARED" || latestResult.winningNumber.includes("*") || latestResult.openPana && !latestResult.closePana || isGameCompleted)
        );
        if (isGameCompleted) {
          throw new Error(
            `Cannot change bet amount: Both Open and Close results for Game #${game.id} (${game.name}) have already been declared.`
          );
        }
        const betSession = categorizeBetSession(targetBet);
        if (isOpenDeclared) {
          if (betSession === "OPEN") {
            throw new Error(
              `Cannot change bet amount: Open result has already been declared for Game #${game.id} (${game.name}). Open bets cannot be edited.`
            );
          }
          if (betSession === "BOTH") {
            throw new Error(
              `Cannot change bet amount: Open result has already been declared for Game #${game.id} (${game.name}). Jodi / Sangam bets cannot be edited.`
            );
          }
        }
        if (game.isLocked) {
          throw new Error(`Cannot change bet amount: Game #${game.id} (${game.name}) is locked.`);
        }
        const now = /* @__PURE__ */ new Date();
        if (game.closeTime && now > new Date(game.closeTime)) {
          throw new Error(`Cannot change bet amount: Wagering for Game #${game.id} has closed.`);
        }
      }
      const newPotentialPayout = newAmount * targetBet.multiplier;
      await tx.bet.update({
        where: { id: betId },
        data: {
          amount: newAmount,
          potentialPayout: newPotentialPayout
        }
      });
      const otherBetsTotal = ticket.bets.filter((b) => b.id !== betId).reduce((sum, b) => sum + b.amount, 0);
      const newTotalAmount = otherBetsTotal + newAmount;
      const updatedTicket = await tx.ticket.update({
        where: { id: ticket.id },
        data: { totalAmount: newTotalAmount },
        include: {
          employee: { select: { id: true, name: true, badgeId: true } },
          bets: { include: { game: true } },
          transactions: true
        }
      });
      const saleTx = ticket.transactions.find((t) => t.type === TransactionType.SALE);
      if (saleTx) {
        await tx.transaction.update({
          where: { id: saleTx.id },
          data: {
            amount: newTotalAmount,
            referenceNote: `Ticket sale: ${ticket.ticketNumber} (Bet #${betId} updated to INR ${newAmount})`
          }
        });
      }
      return updatedTicket;
    });
    res.json({
      success: true,
      message: `Bet amount updated to INR ${newAmount} successfully`,
      data: updated
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});
var tickets_default = router3;

// src/server/routes/bets.ts
import { Router as Router4 } from "express";
var router4 = Router4();
router4.get("/", async (req, res) => {
  try {
    const { ticketId, gameId, tabletId, hasRedeemed, betType, limit = "100", offset = "0" } = req.query;
    const where = {};
    if (ticketId) where.ticketId = parseInt(ticketId);
    if (gameId) where.gameId = parseInt(gameId);
    if (hasRedeemed !== void 0) where.hasRedeemed = hasRedeemed === "true";
    if (betType) where.betType = String(betType);
    if (tabletId && typeof tabletId === "string" && tabletId.trim()) {
      where.ticket = { tabletId: tabletId.trim().toUpperCase() };
    }
    const take = parseInt(limit) || 100;
    const skip = parseInt(offset) || 0;
    const [total, bets] = await Promise.all([
      prisma.bet.count({ where }),
      prisma.bet.findMany({
        where,
        take,
        skip,
        orderBy: { createdAt: "desc" },
        include: {
          game: { select: { id: true, name: true, code: true } },
          ticket: { select: { id: true, ticketNumber: true, status: true, tabletId: true } },
          payout: true
        }
      })
    ]);
    res.json({ success: true, total, count: bets.length, data: bets });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid bet ID" });
    }
    const bet = await prisma.bet.findUnique({
      where: { id },
      include: {
        game: true,
        ticket: true,
        payout: true
      }
    });
    if (!bet) {
      return res.status(404).json({ success: false, message: "Bet not found" });
    }
    res.json({ success: true, data: bet });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.post("/", async (req, res) => {
  try {
    const { ticketId, gameId, selectedNumber, betType = "Single", amount, multiplier = 90 } = req.body;
    if (!ticketId || !gameId || selectedNumber === void 0 || !amount) {
      return res.status(400).json({
        success: false,
        message: "ticketId, gameId, selectedNumber and amount are required"
      });
    }
    const parsedAmount = parseFloat(amount);
    const parsedMultiplier = parseFloat(multiplier);
    const potentialPayout = parsedAmount * parsedMultiplier;
    const resolvedGameId = parseInt(gameId) || getCurrentISTGameId();
    await ensureHourlyGameExists(resolvedGameId);
    const bet = await prisma.bet.create({
      data: {
        ticketId: parseInt(ticketId),
        gameId: resolvedGameId,
        selectedNumber: String(selectedNumber),
        betType,
        amount: parsedAmount,
        multiplier: parsedMultiplier,
        potentialPayout
      },
      include: { game: true, ticket: true }
    });
    res.status(201).json({ success: true, message: "Bet created successfully", data: bet });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid bet ID" });
    }
    const { selectedNumber, betType, amount, multiplier, hasRedeemed } = req.body;
    const parsedAmount = amount !== void 0 ? parseFloat(amount) : void 0;
    const parsedMultiplier = multiplier !== void 0 ? parseFloat(multiplier) : void 0;
    const potentialPayout = parsedAmount !== void 0 && parsedMultiplier !== void 0 ? parsedAmount * parsedMultiplier : void 0;
    const bet = await prisma.bet.update({
      where: { id },
      data: {
        selectedNumber: selectedNumber !== void 0 ? String(selectedNumber) : void 0,
        betType,
        amount: parsedAmount,
        multiplier: parsedMultiplier,
        potentialPayout,
        hasRedeemed: hasRedeemed !== void 0 ? Boolean(hasRedeemed) : void 0
      }
    });
    res.json({ success: true, message: "Bet updated successfully", data: bet });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Bet not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid bet ID" });
    }
    const bet = await prisma.bet.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Bet patched successfully", data: bet });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Bet not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid bet ID" });
    }
    await prisma.bet.delete({
      where: { id }
    });
    res.json({ success: true, message: "Bet deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Bet not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var bets_default = router4;

// src/server/routes/results.ts
import { Router as Router5 } from "express";
import { PayoutStatus as PayoutStatus2 } from "@prisma/client";
var router5 = Router5();
function isWinningBet(selectedNumber, winningNumber, betType, open, close) {
  return evaluateBetWinFromString(selectedNumber, betType, winningNumber, open, close);
}
router5.get(["/", "/paginated", "/check", "/check/all"], async (req, res) => {
  try {
    const {
      gameId,
      page: rawPage,
      limit: rawLimit,
      pageSize: rawPageSize,
      offset: rawOffset,
      startDate,
      endDate,
      date,
      hour,
      search,
      compact,
      limited,
      fields,
      format
    } = req.query;
    const isCompact = req.path === "/check" || req.path === "/check/" || req.path === "/check/all" || req.path === "/check/all/" || compact === "true" || limited === "true" || fields === "limited" || fields === "check" || fields === "compact" || format === "compact";
    const where = {};
    if (gameId) where.gameId = parseInt(gameId);
    if (search && typeof search === "string" && search.trim()) {
      const q = search.trim();
      const qNum = parseInt(q, 10);
      where.OR = [
        { winningNumber: { contains: q } },
        { game: { name: { contains: q } } },
        { game: { code: { contains: q } } },
        ...!isNaN(qNum) ? [{ gameId: qNum }] : []
      ];
    }
    const filterStartDate = date || startDate;
    const filterEndDate = date || endDate;
    if (filterStartDate || filterEndDate) {
      where.declaredAt = {};
      if (filterStartDate) {
        const s = String(filterStartDate).trim();
        if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
          const [sy, sm, sd] = s.split("-").map(Number);
          where.declaredAt.gte = new Date(Date.UTC(sy, sm - 1, sd, 0, 0, 0, 0) - 5.5 * 3600 * 1e3);
        } else {
          where.declaredAt.gte = new Date(s);
        }
      }
      if (filterEndDate) {
        const e = String(filterEndDate).trim();
        if (/^\d{4}-\d{2}-\d{2}$/.test(e)) {
          const [ey, em, ed] = e.split("-").map(Number);
          where.declaredAt.lte = new Date(Date.UTC(ey, em - 1, ed, 23, 59, 59, 999) - 5.5 * 3600 * 1e3);
        } else {
          where.declaredAt.lte = new Date(e);
        }
      }
    }
    const limitNum = parseInt(String(rawLimit || rawPageSize || "20"), 10);
    const take = isNaN(limitNum) || limitNum <= 0 ? 20 : Math.min(limitNum, 500);
    let skip = 0;
    let page = 1;
    if (rawOffset !== void 0) {
      const offsetNum = parseInt(String(rawOffset), 10);
      skip = isNaN(offsetNum) || offsetNum < 0 ? 0 : offsetNum;
      page = Math.floor(skip / take) + 1;
    } else if (rawPage !== void 0) {
      const pageNum = parseInt(String(rawPage), 10);
      page = isNaN(pageNum) || pageNum < 1 ? 1 : pageNum;
      skip = (page - 1) * take;
    }
    const [total, results] = await Promise.all([
      prisma.result.count({ where }),
      prisma.result.findMany({
        where,
        take,
        skip,
        orderBy: { declaredAt: "desc" },
        include: {
          game: { select: { id: true, name: true, code: true, openTime: true, closeTime: true, resultTime: true } },
          declaredBy: { select: { id: true, name: true, badgeId: true } }
        }
      })
    ]);
    let filteredResults = results;
    if (hour !== void 0 && hour !== "all" && hour !== "") {
      const targetHour = parseInt(hour);
      if (!isNaN(targetHour)) {
        filteredResults = filteredResults.filter((r) => {
          const gIdStr = String(r.gameId);
          if (gIdStr.length === 10 && /^\d{10}$/.test(gIdStr)) {
            const h = parseInt(gIdStr.substring(8, 10), 10);
            return h === targetHour;
          }
          const d = new Date(r.declaredAt);
          const istHour = (d.getUTCHours() + 5 + Math.floor((d.getUTCMinutes() + 30) / 60)) % 24;
          return istHour === targetHour;
        });
      }
    }
    let enrichedResults;
    if (isCompact) {
      enrichedResults = filteredResults.map((r) => {
        const components = parseWinningComponents(r.winningNumber);
        return {
          id: r.id,
          gameId: r.gameId,
          status: r.status,
          openPana: r.openPana || components.openLine,
          closePana: r.closePana || components.closeLine,
          openLine: r.openPana || components.openLine,
          closeLine: r.closePana || components.closeLine,
          openDigit: r.openDigit || components.openDigit,
          closeDigit: r.closeDigit || components.closeDigit,
          openDeclaredAt: r.openDeclaredAt,
          closeDeclaredAt: r.closeDeclaredAt,
          pair: components.pair,
          fullDraw: components.fullDraw
        };
      });
    } else {
      const gameIds = Array.from(new Set(filteredResults.map((r) => r.gameId)));
      const payouts = gameIds.length > 0 ? await prisma.payout.findMany({
        where: {
          bet: {
            gameId: { in: gameIds }
          }
        },
        select: {
          winningAmount: true,
          status: true,
          bet: { select: { gameId: true } }
        }
      }) : [];
      const payoutMap = /* @__PURE__ */ new Map();
      for (const p of payouts) {
        const gId = p.bet.gameId;
        const prev = payoutMap.get(gId) || { totalPayout: 0, paidCount: 0, pendingCount: 0 };
        prev.totalPayout += p.winningAmount || 0;
        if (p.status === "PAID") prev.paidCount++;
        else prev.pendingCount++;
        payoutMap.set(gId, prev);
      }
      enrichedResults = filteredResults.map((r) => {
        const components = parseWinningComponents(r.winningNumber);
        const pInfo = payoutMap.get(r.gameId) || { totalPayout: 0, paidCount: 0, pendingCount: 0 };
        return {
          ...r,
          status: r.status,
          openPana: r.openPana || components.openLine,
          closePana: r.closePana || components.closeLine,
          openLine: r.openPana || components.openLine,
          closeLine: r.closePana || components.closeLine,
          openDigit: r.openDigit || components.openDigit,
          closeDigit: r.closeDigit || components.closeDigit,
          openDeclaredAt: r.openDeclaredAt,
          closeDeclaredAt: r.closeDeclaredAt,
          pair: components.pair,
          fullDraw: components.fullDraw,
          components,
          totalPayoutAmount: pInfo.totalPayout,
          payoutsCount: pInfo.paidCount + pInfo.pendingCount
        };
      });
    }
    const totalPages = Math.max(1, Math.ceil(total / take));
    const hasNext = skip + take < total;
    const hasPrev = page > 1;
    res.json({
      success: true,
      pagination: {
        total,
        page,
        limit: take,
        totalPages,
        hasNext,
        hasPrev
      },
      total,
      page,
      limit: take,
      totalPages,
      count: enrichedResults.length,
      data: enrichedResults
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.get(["/check/game/:gameId", "/check/:gameId"], async (req, res) => {
  try {
    const gameId = parseInt(req.params.gameId);
    if (isNaN(gameId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid game ID",
        data: null
      });
    }
    const result = await prisma.result.findUnique({
      where: { gameId }
    });
    const isDeclared = Boolean(
      result && result.winningNumber && result.winningNumber.trim() && result.winningNumber.trim().toLowerCase() !== "pending"
    );
    if (!isDeclared) {
      return res.json({
        success: true,
        message: `Result not declared for game #${gameId}`,
        data: {
          id: result ? result.id : null,
          gameId
        }
      });
    }
    const components = parseWinningComponents(result.winningNumber);
    res.json({
      success: true,
      data: {
        id: result.id,
        gameId,
        status: result.status,
        openPana: result.openPana || components.openLine,
        closePana: result.closePana || components.closeLine,
        openLine: result.openPana || components.openLine,
        closeLine: result.closePana || components.closeLine,
        openDigit: result.openDigit || components.openDigit,
        closeDigit: result.closeDigit || components.closeDigit,
        openDeclaredAt: result.openDeclaredAt,
        closeDeclaredAt: result.closeDeclaredAt,
        pair: components.pair,
        fullDraw: components.fullDraw
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.get("/game/:gameId", async (req, res) => {
  try {
    const gameId = parseInt(req.params.gameId);
    if (isNaN(gameId)) {
      return res.status(400).json({ success: false, message: "Invalid game ID" });
    }
    const result = await prisma.result.findUnique({
      where: { gameId },
      include: {
        game: true,
        declaredBy: { select: { id: true, name: true, badgeId: true } }
      }
    });
    if (!result) {
      return res.status(404).json({ success: false, message: `Result not declared for game #${gameId}` });
    }
    const components = parseWinningComponents(result.winningNumber);
    res.json({
      success: true,
      data: {
        ...result,
        openLine: components.openLine,
        closeLine: components.closeLine,
        openDigit: components.openDigit,
        closeDigit: components.closeDigit,
        pair: components.pair,
        fullDraw: components.fullDraw,
        components
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid result ID" });
    }
    const result = await prisma.result.findUnique({
      where: { id },
      include: {
        game: true,
        declaredBy: { select: { id: true, name: true, badgeId: true } }
      }
    });
    if (!result) {
      return res.status(404).json({ success: false, message: "Result not found" });
    }
    const components = parseWinningComponents(result.winningNumber);
    res.json({
      success: true,
      data: {
        ...result,
        openLine: components.openLine,
        closeLine: components.closeLine,
        openDigit: components.openDigit,
        closeDigit: components.closeDigit,
        pair: components.pair,
        fullDraw: components.fullDraw,
        components
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.post("/trigger-draw", async (req, res) => {
  try {
    const { gameId, gameid, declaredById, forceOutcome, provider, simulateLatencyMs, dryRun, targetPhase } = req.body || {};
    const rawId = gameId !== void 0 ? gameId : gameid;
    if (!rawId) {
      return res.status(400).json({ error: "gameId reference is required" });
    }
    const parsedGameId = parseInt(rawId);
    if (isNaN(parsedGameId)) {
      return res.status(400).json({ error: "Invalid game ID reference" });
    }
    const game = await prisma.game.findUnique({ where: { id: parsedGameId } });
    if (!game) {
      return res.status(404).json({ error: "Game not found" });
    }
    if (!game.status) {
      return res.status(400).json({
        error: `Cannot trigger draw for Game #${parsedGameId}. This game has been disabled by Admin.`
      });
    }
    const phase = String(targetPhase || "FULL").toUpperCase();
    if (phase === "OPEN") {
      const drawResult2 = await executeOpenDraw({
        gameId: parsedGameId,
        declaredById: declaredById ? parseInt(declaredById) : void 0,
        forceOutcome,
        provider,
        simulateLatencyMs
      });
      return res.json({
        gameId: parsedGameId,
        gameid: parsedGameId,
        drawDetails: {
          drawId: drawResult2.drawOutcome.externalDrawId,
          winningNumber: drawResult2.drawOutcome.winningNumber,
          openLine: drawResult2.drawOutcome.openLine,
          openDigit: drawResult2.drawOutcome.openDigit,
          pair: "",
          closeLine: "",
          closeDigit: "",
          fullDraw: drawResult2.drawOutcome.winningNumber,
          status: "OPEN_DECLARED",
          timestamp: drawResult2.drawOutcome.timestamp
        }
      });
    }
    if (phase === "CLOSE") {
      const drawResult2 = await executeCloseDraw({
        gameId: parsedGameId,
        declaredById: declaredById ? parseInt(declaredById) : void 0,
        forceOutcome,
        provider,
        simulateLatencyMs
      });
      return res.json({
        gameId: parsedGameId,
        gameid: parsedGameId,
        drawDetails: {
          drawId: drawResult2.drawOutcome.externalDrawId,
          winningNumber: drawResult2.drawOutcome.winningNumber,
          openLine: drawResult2.drawOutcome.openLine,
          openDigit: drawResult2.drawOutcome.openDigit,
          pair: drawResult2.drawOutcome.pair,
          closeLine: drawResult2.drawOutcome.closeLine,
          closeDigit: drawResult2.drawOutcome.closeDigit,
          fullDraw: drawResult2.drawOutcome.fullDraw,
          status: "COMPLETED",
          timestamp: drawResult2.drawOutcome.timestamp
        }
      });
    }
    const drawResult = await executeGameDraw({
      gameId: parsedGameId,
      declaredById: declaredById ? parseInt(declaredById) : void 0,
      forceOutcome,
      provider,
      simulateLatencyMs
    });
    res.json({
      gameId: parsedGameId,
      gameid: parsedGameId,
      drawDetails: {
        drawId: drawResult.drawOutcome.externalDrawId,
        winningNumber: drawResult.drawOutcome.winningNumber,
        openLine: drawResult.drawOutcome.openLine,
        openDigit: drawResult.drawOutcome.openDigit,
        pair: drawResult.drawOutcome.pair,
        closeLine: drawResult.drawOutcome.closeLine,
        closeDigit: drawResult.drawOutcome.closeDigit,
        fullDraw: drawResult.drawOutcome.fullDraw,
        status: drawResult.drawOutcome.status || "COMPLETED",
        timestamp: drawResult.drawOutcome.timestamp
      }
    });
  } catch (error) {
    console.error("Trigger draw error:", error);
    res.status(500).json({ error: error.message });
  }
});
router5.post("/declare-open", async (req, res) => {
  try {
    const { gameId, openPana, openDigit, declaredById } = req.body;
    if (!gameId || !openPana && !openDigit) {
      return res.status(400).json({
        success: false,
        message: "gameId and openPana (or openDigit) are required"
      });
    }
    const parsedGameId = parseInt(gameId);
    let panaStr = openPana ? String(openPana).replace(/\D/g, "") : "";
    let digitStr = openDigit !== void 0 ? String(openDigit).replace(/\D/g, "").slice(0, 1) : "";
    if (panaStr.length === 3 && !digitStr) {
      const sum = panaStr.split("").reduce((acc, c) => acc + parseInt(c, 10), 0) % 10;
      digitStr = String(sum);
    } else if (!panaStr && digitStr) {
      panaStr = "---";
    }
    const game = await prisma.game.findUnique({ where: { id: parsedGameId } });
    if (!game) {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    if (!game.status) {
      return res.status(400).json({
        success: false,
        message: `Cannot declare results for Game #${parsedGameId}. This game has been disabled by Admin.`
      });
    }
    const existingResult = await prisma.result.findUnique({
      where: { gameId: parsedGameId }
    });
    if (existingResult && existingResult.status === "COMPLETED") {
      return res.status(409).json({
        success: false,
        message: `Game #${parsedGameId} is already fully COMPLETED with winning number ${existingResult.winningNumber}.`
      });
    }
    const cutoffs = getGameCutoffs(game);
    const now = /* @__PURE__ */ new Date();
    if (now < cutoffs.openBetCutoff) {
      return res.status(400).json({
        success: false,
        message: `Cannot declare Open result for Game #${parsedGameId}. Open betting is currently active until ${formatISTTime(cutoffs.openBetCutoff)} (5 minutes prior to Open result at ${formatISTTime(cutoffs.openResultTime)}).`
      });
    }
    const winningPreview = `${panaStr}-${digitStr}***`;
    const result = await prisma.$transaction(async (tx) => {
      const outcome = await tx.result.upsert({
        where: { gameId: parsedGameId },
        create: {
          gameId: parsedGameId,
          winningNumber: winningPreview,
          status: "OPEN_DECLARED",
          openPana: panaStr !== "---" ? panaStr : null,
          openDigit: digitStr,
          openDeclaredAt: now,
          declaredAt: now,
          declaredById: declaredById ? parseInt(declaredById) : null
        },
        update: {
          winningNumber: winningPreview,
          status: "OPEN_DECLARED",
          openPana: panaStr !== "---" ? panaStr : null,
          openDigit: digitStr,
          openDeclaredAt: now,
          declaredById: declaredById ? parseInt(declaredById) : null
        },
        include: {
          game: true,
          declaredBy: { select: { id: true, name: true, badgeId: true } }
        }
      });
      const bets = await tx.bet.findMany({
        where: {
          gameId: parsedGameId,
          ticket: { status: "ACTIVE" }
        },
        include: { ticket: true }
      });
      const openWinners = [];
      let totalWinningLiability = 0;
      const payoutRules = await tx.payoutRule.findMany({ where: { active: true } });
      for (const bet of bets) {
        const evalRes = evaluateTieredBetWin(
          bet,
          winningPreview,
          panaStr !== "---" ? panaStr : null,
          null,
          payoutRules
        );
        if (evalRes.claimableAmount > 0) {
          const payout = await tx.payout.upsert({
            where: { betId: bet.id },
            create: {
              betId: bet.id,
              winningAmount: evalRes.openLegPrize || evalRes.grossWinningAmount,
              status: PayoutStatus2.PENDING
            },
            update: {
              winningAmount: evalRes.openLegPrize || evalRes.grossWinningAmount
            }
          });
          openWinners.push({
            betId: bet.id,
            ticketNumber: bet.ticket.ticketNumber,
            selectedNumber: bet.selectedNumber,
            open: bet.open,
            betType: bet.betType,
            isMultiStage: evalRes.isMultiStage,
            amount: bet.amount,
            payoutAmount: evalRes.claimableAmount,
            payoutId: payout.id,
            note: evalRes.description
          });
          totalWinningLiability += evalRes.claimableAmount;
        }
      }
      return { outcome, openWinners, totalWinningLiability };
    });
    res.status(200).json({
      success: true,
      message: `Open result declared for Game #${parsedGameId} (Open: ${panaStr}-${digitStr}). Partial redemption available for winning Open bets.`,
      data: {
        ...result.outcome,
        openLine: result.outcome.openPana,
        openDigit: result.outcome.openDigit,
        closeLine: null,
        closeDigit: null,
        pair: null,
        fullDraw: winningPreview,
        status: "OPEN_DECLARED",
        canRedeem: true,
        isPartial: true,
        openWinnersCount: result.openWinners.length,
        openWinningLiability: result.totalWinningLiability,
        openWinners: result.openWinners,
        note: "Partial redemption enabled: Open winning bets can be redeemed immediately at Cage. Remaining lines will be redeemable upon Close declaration."
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.post("/declare-close", async (req, res) => {
  try {
    const { gameId, closePana, closeDigit, declaredById } = req.body;
    if (!gameId || !closePana && !closeDigit) {
      return res.status(400).json({
        success: false,
        message: "gameId and closePana (or closeDigit) are required"
      });
    }
    const parsedGameId = parseInt(gameId);
    let closePanaStr = closePana ? String(closePana).replace(/\D/g, "") : "";
    let closeDigitStr = closeDigit !== void 0 ? String(closeDigit).replace(/\D/g, "").slice(0, 1) : "";
    if (closePanaStr.length === 3 && !closeDigitStr) {
      const sum = closePanaStr.split("").reduce((acc, c) => acc + parseInt(c, 10), 0) % 10;
      closeDigitStr = String(sum);
    }
    const existingResult = await prisma.result.findUnique({
      where: { gameId: parsedGameId },
      include: { game: true }
    });
    if (!existingResult) {
      return res.status(400).json({
        success: false,
        message: `Cannot declare Close for Game #${parsedGameId} because Open has not been declared yet. Please declare Open first.`
      });
    }
    if (existingResult.game && !existingResult.game.status) {
      return res.status(400).json({
        success: false,
        message: `Cannot declare results for Game #${parsedGameId}. This game has been disabled by Admin.`
      });
    }
    if (existingResult.status === "COMPLETED" && existingResult.closePana) {
      return res.status(409).json({
        success: false,
        message: `Game #${parsedGameId} is already COMPLETED (Winning Number: ${existingResult.winningNumber}).`
      });
    }
    const targetGame = existingResult.game || await prisma.game.findUnique({ where: { id: parsedGameId } });
    if (targetGame) {
      const cutoffs = getGameCutoffs(targetGame);
      const now2 = /* @__PURE__ */ new Date();
      if (now2 < cutoffs.closeBetCutoff) {
        return res.status(400).json({
          success: false,
          message: `Cannot declare Close result for Game #${parsedGameId}. Close betting is currently active until ${formatISTTime(cutoffs.closeBetCutoff)} (5 minutes prior to Close result at ${formatISTTime(cutoffs.closeResultTime)}).`
        });
      }
    }
    const openPana = existingResult.openPana || "---";
    const openDigit = existingResult.openDigit || "0";
    const pair = `${openDigit}${closeDigitStr}`;
    const fullWinningNumber = `${openPana}-${pair}-${closePanaStr}`;
    const now = /* @__PURE__ */ new Date();
    const outcome = await prisma.$transaction(async (tx) => {
      const updatedResult = await tx.result.update({
        where: { gameId: parsedGameId },
        data: {
          winningNumber: fullWinningNumber,
          status: "COMPLETED",
          closePana: closePanaStr,
          closeDigit: closeDigitStr,
          closeDeclaredAt: now,
          declaredAt: now,
          declaredById: declaredById ? parseInt(declaredById) : existingResult.declaredById
        },
        include: {
          game: true,
          declaredBy: { select: { id: true, name: true, badgeId: true } }
        }
      });
      await tx.game.update({
        where: { id: parsedGameId },
        data: {
          isLocked: true,
          resultTime: now
        }
      });
      const bets = await tx.bet.findMany({
        where: {
          gameId: parsedGameId,
          ticket: { status: "ACTIVE" }
        },
        include: { ticket: true }
      });
      const winners = [];
      let totalWinningLiability = 0;
      const payoutRules = await tx.payoutRule.findMany({ where: { active: true } });
      for (const bet of bets) {
        const evalRes = evaluateTieredBetWin(
          bet,
          fullWinningNumber,
          openPana,
          closePanaStr,
          payoutRules
        );
        if (evalRes.claimableAmount > 0) {
          const payout = await tx.payout.upsert({
            where: { betId: bet.id },
            create: {
              betId: bet.id,
              winningAmount: evalRes.grossWinningAmount,
              status: PayoutStatus2.PENDING
            },
            update: {
              winningAmount: evalRes.grossWinningAmount
            }
          });
          winners.push({
            betId: bet.id,
            ticketNumber: bet.ticket.ticketNumber,
            selectedNumber: bet.selectedNumber,
            open: bet.open,
            close: bet.close,
            betType: bet.betType,
            isMultiStage: evalRes.isMultiStage,
            amount: bet.amount,
            grossWinningAmount: evalRes.grossWinningAmount,
            alreadyRedeemed: evalRes.alreadyRedeemed,
            payoutAmount: evalRes.claimableAmount,
            payoutId: payout.id,
            note: evalRes.description
          });
          totalWinningLiability += evalRes.claimableAmount;
        }
      }
      const components = parseWinningComponents(fullWinningNumber);
      return {
        result: {
          ...updatedResult,
          openLine: components.openLine,
          closeLine: components.closeLine,
          openDigit: components.openDigit,
          closeDigit: components.closeDigit,
          pair: components.pair,
          fullDraw: components.fullDraw,
          components
        },
        totalCheckedBets: bets.length,
        winnersCount: winners.length,
        totalWinningLiability,
        winners
      };
    });
    res.status(200).json({
      success: true,
      message: `Close declared! Game #${parsedGameId} is now CLOSED. Winning Number: ${fullWinningNumber}. ${outcome.winnersCount} winner(s) verified for redemption.`,
      data: outcome
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.post("/", async (req, res) => {
  try {
    const { gameId, winningNumber, declaredById, openPana, closePana, status } = req.body;
    if (!gameId || winningNumber === void 0 && !openPana && !closePana) {
      return res.status(400).json({
        success: false,
        message: "gameId and winningNumber (or openPana/closePana) are required"
      });
    }
    const parsedGameId = parseInt(gameId);
    if (status === "OPEN_DECLARED" || openPana && !closePana) {
      const pana = openPana ? String(openPana) : String(winningNumber);
      return res.redirect(307, "/api/results/declare-open");
    }
    let winNumStr = String(winningNumber || "").trim();
    const onlyDigits = winNumStr.replace(/\D/g, "");
    if (onlyDigits.length === 6) {
      winNumStr = computeFullWinningNumberFrom6Digits(onlyDigits);
    } else if (openPana && closePana) {
      const oP = String(openPana).replace(/\D/g, "");
      const cP = String(closePana).replace(/\D/g, "");
      winNumStr = computeFullWinningNumberFrom6Digits(`${oP}${cP}`);
    }
    const game = await prisma.game.findUnique({
      where: { id: parsedGameId }
    });
    if (!game) {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    const cutoffs = getGameCutoffs(game);
    const now = /* @__PURE__ */ new Date();
    if (now < cutoffs.closeBetCutoff) {
      return res.status(400).json({
        success: false,
        message: `Cannot declare Full Draw for Game #${parsedGameId}. Wagering is currently active until ${formatISTTime(cutoffs.closeBetCutoff)} (5 minutes prior to close at ${formatISTTime(cutoffs.closeResultTime)}). If Open cutoff has passed, declare Open result first.`
      });
    }
    const existingResult = await prisma.result.findUnique({
      where: { gameId: parsedGameId }
    });
    if (existingResult && existingResult.status === "COMPLETED" && existingResult.closePana) {
      return res.status(409).json({
        success: false,
        message: `Result already declared for Game #${parsedGameId} (Winning Number: ${existingResult.winningNumber}). Existing results cannot be overridden.`
      });
    }
    const components = parseWinningComponents(winNumStr);
    const outcome = await prisma.$transaction(async (tx) => {
      const txExisting = await tx.result.findUnique({
        where: { gameId: parsedGameId }
      });
      if (txExisting && txExisting.status === "COMPLETED" && txExisting.closePana) {
        throw new Error(`Result already declared for Game #${parsedGameId} (Winning Number: ${txExisting.winningNumber}). Existing results cannot be overridden.`);
      }
      const createdResult = await tx.result.upsert({
        where: { gameId: parsedGameId },
        create: {
          gameId: parsedGameId,
          winningNumber: winNumStr,
          status: "COMPLETED",
          openPana: components.openLine || null,
          openDigit: components.openDigit || null,
          closePana: components.closeLine || null,
          closeDigit: components.closeDigit || null,
          openDeclaredAt: now,
          closeDeclaredAt: now,
          declaredById: declaredById ? parseInt(declaredById) : null,
          declaredAt: now
        },
        update: {
          winningNumber: winNumStr,
          status: "COMPLETED",
          openPana: components.openLine || null,
          openDigit: components.openDigit || null,
          closePana: components.closeLine || null,
          closeDigit: components.closeDigit || null,
          closeDeclaredAt: now,
          declaredById: declaredById ? parseInt(declaredById) : null,
          declaredAt: now
        },
        include: { game: true, declaredBy: true }
      });
      await tx.game.update({
        where: { id: parsedGameId },
        data: {
          isLocked: true,
          resultTime: now
        }
      });
      const bets = await tx.bet.findMany({
        where: {
          gameId: parsedGameId,
          ticket: { status: "ACTIVE" }
        },
        include: { ticket: true }
      });
      const winners = [];
      let totalWinningLiability = 0;
      for (const bet of bets) {
        if (isWinningBet(bet.selectedNumber, winNumStr, bet.betType, bet.open, bet.close)) {
          const payout = await tx.payout.upsert({
            where: { betId: bet.id },
            create: {
              betId: bet.id,
              winningAmount: bet.potentialPayout,
              status: PayoutStatus2.PENDING
            },
            update: {
              winningAmount: bet.potentialPayout
            }
          });
          winners.push({
            betId: bet.id,
            ticketNumber: bet.ticket.ticketNumber,
            selectedNumber: bet.selectedNumber,
            open: bet.open,
            close: bet.close,
            betType: bet.betType,
            amount: bet.amount,
            payoutAmount: bet.potentialPayout,
            payoutId: payout.id
          });
          totalWinningLiability += bet.potentialPayout;
        }
      }
      return {
        result: {
          ...createdResult,
          openLine: components.openLine,
          closeLine: components.closeLine,
          openDigit: components.openDigit,
          closeDigit: components.closeDigit,
          pair: components.pair,
          fullDraw: components.fullDraw,
          components
        },
        totalCheckedBets: bets.length,
        winnersCount: winners.length,
        totalWinningLiability,
        winners
      };
    });
    res.status(201).json({
      success: true,
      message: `Result declared successfully for ${game.name}. Found ${outcome.winnersCount} winner(s).`,
      data: outcome
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid result ID" });
    }
    const { winningNumber, declaredById } = req.body;
    const result = await prisma.result.update({
      where: { id },
      data: {
        winningNumber: winningNumber !== void 0 ? String(winningNumber) : void 0,
        declaredById: declaredById !== void 0 ? parseInt(declaredById) : void 0
      }
    });
    res.json({ success: true, message: "Result updated successfully", data: result });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Result not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid result ID" });
    }
    const result = await prisma.result.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Result patched successfully", data: result });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Result not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid result ID" });
    }
    await prisma.result.delete({
      where: { id }
    });
    res.json({ success: true, message: "Result deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Result not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var results_default = router5;

// src/server/routes/payouts.ts
import { Router as Router6 } from "express";
import { PayoutStatus as PayoutStatus3, TransactionType as TransactionType2, PaymentMode as PaymentMode2, TicketStatus as TicketStatus2 } from "@prisma/client";
var router6 = Router6();
router6.get("/", async (req, res) => {
  try {
    const { status, processedById, gameId, limit = "100", offset = "0", startDate, endDate, search } = req.query;
    const andConditions = [];
    if (status && Object.values(PayoutStatus3).includes(status)) {
      if (status === PayoutStatus3.PAID) {
        andConditions.push({
          OR: [
            { status: PayoutStatus3.PAID },
            { paidAmount: { gt: 0 } }
          ]
        });
      } else {
        andConditions.push({ status });
      }
    }
    if (processedById) {
      andConditions.push({ processedById: parseInt(processedById) });
    }
    if (gameId) {
      andConditions.push({ bet: { gameId: parseInt(gameId) } });
    }
    if (startDate || endDate) {
      let startD;
      let endD;
      if (startDate && typeof startDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(startDate)) {
        const [sy, sm, sd] = startDate.split("-").map(Number);
        startD = new Date(Date.UTC(sy, sm - 1, sd, 0, 0, 0, 0) - 5.5 * 3600 * 1e3);
      }
      if (endDate && typeof endDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
        const [ey, em, ed] = endDate.split("-").map(Number);
        endD = new Date(Date.UTC(ey, em - 1, ed, 23, 59, 59, 999) - 5.5 * 3600 * 1e3);
      }
      if (startD || endD) {
        const paidAtFilter = {};
        if (startD) paidAtFilter.gte = startD;
        if (endD) paidAtFilter.lte = endD;
        andConditions.push({ paidAt: paidAtFilter });
      }
    }
    if (search && typeof search === "string" && search.trim()) {
      const q = search.trim();
      andConditions.push({
        OR: [
          { bet: { ticket: { ticketNumber: { contains: q } } } },
          { bet: { ticket: { barcode: { contains: q } } } },
          { bet: { ticket: { contact: { contains: q } } } },
          { claimedBy: { contains: q } },
          { transactionRef: { contains: q } }
        ]
      });
    }
    const where = andConditions.length > 0 ? { AND: andConditions } : {};
    const take = parseInt(limit) || 100;
    const skip = parseInt(offset) || 0;
    const [total, payouts] = await Promise.all([
      prisma.payout.count({ where }),
      prisma.payout.findMany({
        where,
        take,
        skip,
        orderBy: { paidAt: "desc" },
        include: {
          bet: {
            include: {
              game: { select: { id: true, name: true, code: true } },
              ticket: {
                select: {
                  id: true,
                  ticketNumber: true,
                  barcode: true,
                  contact: true,
                  status: true,
                  createdAt: true
                }
              }
            }
          },
          processedBy: {
            select: { id: true, name: true, badgeId: true }
          }
        }
      })
    ]);
    res.json({ success: true, total, count: payouts.length, data: payouts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid payout ID" });
    }
    const payout = await prisma.payout.findUnique({
      where: { id },
      include: {
        bet: {
          include: {
            game: true,
            ticket: {
              include: { employee: true }
            }
          }
        },
        processedBy: true
      }
    });
    if (!payout) {
      return res.status(404).json({ success: false, message: "Payout not found" });
    }
    res.json({ success: true, data: payout });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.post("/", async (req, res) => {
  try {
    const { betId, winningAmount, status, claimedBy } = req.body;
    if (!betId || winningAmount === void 0) {
      return res.status(400).json({ success: false, message: "betId and winningAmount are required" });
    }
    const payout = await prisma.payout.create({
      data: {
        betId: parseInt(betId),
        winningAmount: parseFloat(winningAmount),
        status: status || PayoutStatus3.PENDING,
        claimedBy: claimedBy || null
      },
      include: { bet: true }
    });
    res.status(201).json({ success: true, message: "Payout created successfully", data: payout });
  } catch (error) {
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Payout record already exists for this bet" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid payout ID" });
    }
    const { winningAmount, status, claimedBy, processedById } = req.body;
    const payout = await prisma.payout.update({
      where: { id },
      data: {
        winningAmount: winningAmount !== void 0 ? parseFloat(winningAmount) : void 0,
        status,
        claimedBy: claimedBy || null,
        processedById: processedById ? parseInt(processedById) : null,
        paidAt: status === PayoutStatus3.PAID ? /* @__PURE__ */ new Date() : void 0
      }
    });
    res.json({ success: true, message: "Payout updated successfully", data: payout });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid payout ID" });
    }
    const payout = await prisma.payout.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Payout patched successfully", data: payout });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid payout ID" });
    }
    await prisma.payout.delete({
      where: { id }
    });
    res.json({ success: true, message: "Payout deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.post("/:id/settle", async (req, res) => {
  const rawIdempotencyKey = req.headers["x-idempotency-key"] || req.headers["idempotency-key"] || req.body.idempotencyKey;
  const idempotencyKey = rawIdempotencyKey ? String(rawIdempotencyKey).trim() : void 0;
  try {
    const id = parseInt(req.params.id);
    const { processedById, claimedBy, paymentMode = "CASH" } = req.body;
    const settled = await prisma.$transaction(async (tx) => {
      const payout = await tx.payout.findUnique({
        where: { id },
        include: {
          bet: {
            include: { ticket: true }
          }
        }
      });
      if (!payout) {
        throw new Error("Payout record not found");
      }
      if (payout.status === PayoutStatus3.PAID) {
        return { payout, alreadySettled: true };
      }
      const updatedPayout = await tx.payout.update({
        where: { id },
        data: {
          status: PayoutStatus3.PAID,
          claimedBy: claimedBy || "Customer Walk-in",
          processedById: processedById ? parseInt(processedById) : null,
          paidAt: /* @__PURE__ */ new Date()
        }
      });
      const payoutTxKey = idempotencyKey ? `payout-settle-${idempotencyKey}` : `payout-bet-${payout.betId}`;
      await tx.transaction.create({
        data: {
          ticketId: payout.bet.ticketId,
          employeeId: processedById ? parseInt(processedById) : null,
          type: TransactionType2.PAYOUT,
          amount: payout.winningAmount,
          paymentMode: Object.values(PaymentMode2).includes(paymentMode) ? paymentMode : PaymentMode2.CASH,
          referenceNote: `Prize redemption for Bet #${payout.betId} (Ticket: ${payout.bet.ticket.ticketNumber})`,
          idempotencyKey: payoutTxKey
        }
      });
      await tx.ticket.update({
        where: { id: payout.bet.ticketId },
        data: {
          status: TicketStatus2.PAID,
          settledAt: /* @__PURE__ */ new Date()
        }
      });
      return { payout: updatedPayout, alreadySettled: false };
    });
    res.json({
      success: true,
      isDuplicate: settled.alreadySettled,
      message: settled.alreadySettled ? "Payout already settled (idempotent replay)" : "Payout settled and cash disbursed successfully",
      data: settled.payout
    });
  } catch (error) {
    if (error.code === "P2002") {
      const id = parseInt(req.params.id);
      const payout = await prisma.payout.findUnique({ where: { id } });
      if (payout) {
        return res.json({
          success: true,
          isDuplicate: true,
          message: "Payout settled concurrently (idempotent replay)",
          data: payout
        });
      }
    }
    res.status(400).json({ success: false, message: error.message });
  }
});
var payouts_default = router6;

// src/server/routes/transactions.ts
import { Router as Router7 } from "express";
import { TransactionType as TransactionType3, PaymentMode as PaymentMode3 } from "@prisma/client";
var router7 = Router7();
function parseISTDateBounds(startDate, endDate) {
  if (!startDate && !endDate) return null;
  const bounds = {};
  if (startDate && typeof startDate === "string" && startDate.trim()) {
    const s = startDate.trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
      const [sy, sm, sd] = s.split("-").map(Number);
      bounds.gte = new Date(Date.UTC(sy, sm - 1, sd, 0, 0, 0, 0) - 5.5 * 3600 * 1e3);
    } else {
      bounds.gte = new Date(s);
    }
  }
  if (endDate && typeof endDate === "string" && endDate.trim()) {
    const e = endDate.trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(e)) {
      const [ey, em, ed] = e.split("-").map(Number);
      bounds.lte = new Date(Date.UTC(ey, em - 1, ed, 23, 59, 59, 999) - 5.5 * 3600 * 1e3);
    } else {
      bounds.lte = new Date(e);
    }
  }
  return Object.keys(bounds).length > 0 ? bounds : null;
}
router7.get("/", async (req, res) => {
  try {
    const { type, paymentMode, ticketId, employeeId, tabletId, startDate, endDate, gameId, search, limit = "50", offset = "0" } = req.query;
    const where = {};
    if (type && Object.values(TransactionType3).includes(type)) {
      where.type = type;
    }
    if (paymentMode && Object.values(PaymentMode3).includes(paymentMode)) {
      where.paymentMode = paymentMode;
    }
    if (ticketId) where.ticketId = parseInt(ticketId);
    if (employeeId) where.employeeId = parseInt(employeeId);
    if (tabletId && typeof tabletId === "string" && tabletId.trim()) {
      where.ticket = {
        ...where.ticket,
        tabletId: tabletId.trim().toUpperCase()
      };
    }
    const dateBounds = parseISTDateBounds(startDate, endDate);
    if (dateBounds) {
      where.createdAt = dateBounds;
    }
    if (gameId) {
      const gId = parseInt(gameId);
      if (!isNaN(gId)) {
        where.ticket = {
          ...where.ticket,
          bets: {
            some: {
              gameId: gId
            }
          }
        };
      }
    }
    if (search && typeof search === "string" && search.trim()) {
      const q = search.trim();
      where.OR = [
        { referenceNote: { contains: q } },
        { ticket: { ticketNumber: { contains: q } } },
        { ticket: { barcode: { contains: q } } },
        { ticket: { contact: { contains: q } } },
        { ticket: { tabletId: { contains: q } } },
        { employee: { name: { contains: q } } },
        { employee: { badgeId: { contains: q } } }
      ];
    }
    const take = parseInt(limit) || 50;
    const skip = parseInt(offset) || 0;
    const [total, transactions] = await Promise.all([
      prisma.transaction.count({ where }),
      prisma.transaction.findMany({
        where,
        take,
        skip,
        orderBy: { createdAt: "desc" },
        include: {
          employee: { select: { id: true, name: true, badgeId: true, role: true } },
          ticket: {
            select: {
              id: true,
              ticketNumber: true,
              barcode: true,
              contact: true,
              status: true,
              totalAmount: true,
              tabletId: true,
              bets: {
                select: {
                  gameId: true,
                  game: { select: { id: true, code: true, name: true } }
                },
                take: 1
              }
            }
          }
        }
      })
    ]);
    res.json({ success: true, total, count: transactions.length, limit: take, offset: skip, data: transactions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.get("/summary", async (req, res) => {
  try {
    const { employeeId, startDate, endDate } = req.query;
    const where = {};
    if (employeeId) where.employeeId = parseInt(employeeId);
    const dateBounds = parseISTDateBounds(startDate, endDate);
    if (dateBounds) {
      where.createdAt = dateBounds;
    }
    const transactions = await prisma.transaction.findMany({
      where,
      select: { type: true, amount: true, paymentMode: true }
    });
    let totalSales = 0;
    let totalPayouts = 0;
    let totalRefunds = 0;
    let totalFloatIn = 0;
    let totalFloatOut = 0;
    for (const t of transactions) {
      switch (t.type) {
        case TransactionType3.SALE:
          totalSales += t.amount;
          break;
        case TransactionType3.PAYOUT:
          totalPayouts += t.amount;
          break;
        case TransactionType3.REFUND:
          totalRefunds += t.amount;
          break;
        case TransactionType3.FLOAT_IN:
          totalFloatIn += t.amount;
          break;
        case TransactionType3.FLOAT_OUT:
          totalFloatOut += t.amount;
          break;
      }
    }
    const netGamingGross = totalSales - totalPayouts - totalRefunds;
    const netDrawerBalance = totalFloatIn + totalSales - totalPayouts - totalRefunds - totalFloatOut;
    res.json({
      success: true,
      data: {
        totalSales,
        totalPayouts,
        totalRefunds,
        totalFloatIn,
        totalFloatOut,
        netGamingGross,
        netDrawerBalance,
        transactionCount: transactions.length
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid transaction ID" });
    }
    const transaction = await prisma.transaction.findUnique({
      where: { id },
      include: {
        employee: true,
        ticket: {
          include: { bets: true }
        }
      }
    });
    if (!transaction) {
      return res.status(404).json({ success: false, message: "Transaction not found" });
    }
    res.json({ success: true, data: transaction });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.post("/", async (req, res) => {
  const rawIdempotencyKey = req.headers["x-idempotency-key"] || req.headers["idempotency-key"] || req.body.idempotencyKey;
  const idempotencyKey = rawIdempotencyKey ? String(rawIdempotencyKey).trim() : void 0;
  try {
    const { ticketId, employeeId, type, amount, paymentMode = "CASH", referenceNote } = req.body;
    if (!type || amount === void 0) {
      return res.status(400).json({ success: false, message: "type and amount are required" });
    }
    if (!Object.values(TransactionType3).includes(type)) {
      return res.status(400).json({
        success: false,
        message: `Invalid transaction type. Allowed: ${Object.values(TransactionType3).join(", ")}`
      });
    }
    if (idempotencyKey) {
      const existingTx = await prisma.transaction.findUnique({
        where: { idempotencyKey }
      });
      if (existingTx) {
        return res.json({
          success: true,
          isDuplicate: true,
          message: "Transaction already recorded (idempotent replay)",
          data: existingTx
        });
      }
    }
    const transaction = await prisma.transaction.create({
      data: {
        ticketId: ticketId ? parseInt(ticketId) : null,
        employeeId: employeeId ? parseInt(employeeId) : null,
        type,
        amount: parseFloat(amount),
        paymentMode: Object.values(PaymentMode3).includes(paymentMode) ? paymentMode : PaymentMode3.CASH,
        referenceNote: referenceNote || null,
        idempotencyKey: idempotencyKey || null
      }
    });
    res.status(201).json({ success: true, message: "Transaction recorded successfully", data: transaction });
  } catch (error) {
    if (error.code === "P2002" && idempotencyKey) {
      const existingTx = await prisma.transaction.findUnique({
        where: { idempotencyKey }
      });
      if (existingTx) {
        return res.json({
          success: true,
          isDuplicate: true,
          message: "Transaction recorded concurrently (idempotent replay)",
          data: existingTx
        });
      }
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid transaction ID" });
    }
    const { type, amount, paymentMode, referenceNote } = req.body;
    const transaction = await prisma.transaction.update({
      where: { id },
      data: {
        type,
        amount: amount !== void 0 ? parseFloat(amount) : void 0,
        paymentMode,
        referenceNote: referenceNote !== void 0 ? referenceNote : void 0
      }
    });
    res.json({ success: true, message: "Transaction updated successfully", data: transaction });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Transaction not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid transaction ID" });
    }
    const transaction = await prisma.transaction.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Transaction patched successfully", data: transaction });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Transaction not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid transaction ID" });
    }
    await prisma.transaction.delete({
      where: { id }
    });
    res.json({ success: true, message: "Transaction deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Transaction not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var transactions_default = router7;

// src/server/routes/payoutRules.ts
import { Router as Router8 } from "express";
var router8 = Router8();
router8.get("/", async (req, res) => {
  try {
    const rules = await prisma.payoutRule.findMany({
      orderBy: { id: "asc" }
    });
    res.json({ success: true, count: rules.length, data: rules });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.get("/:id", async (req, res) => {
  try {
    const param = req.params.id;
    const isNum = !isNaN(parseInt(param));
    const rule = await prisma.payoutRule.findFirst({
      where: isNum ? { OR: [{ id: parseInt(param) }, { betType: param }] } : { betType: param }
    });
    if (!rule) {
      return res.status(404).json({ success: false, message: "Payout rule not found" });
    }
    res.json({ success: true, data: rule });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.post("/", async (req, res) => {
  try {
    const { betType, multiplier, active = true } = req.body;
    if (!betType || multiplier === void 0) {
      return res.status(400).json({ success: false, message: "betType and multiplier are required" });
    }
    const rule = await prisma.payoutRule.create({
      data: {
        betType: String(betType),
        multiplier: parseFloat(multiplier),
        active: Boolean(active)
      }
    });
    res.status(201).json({ success: true, message: "Payout rule created successfully", data: rule });
  } catch (error) {
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Rule for this betType already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid rule ID" });
    }
    const { betType, multiplier, active } = req.body;
    const rule = await prisma.payoutRule.update({
      where: { id },
      data: {
        betType: betType !== void 0 ? String(betType) : void 0,
        multiplier: multiplier !== void 0 ? parseFloat(multiplier) : void 0,
        active: active !== void 0 ? Boolean(active) : void 0
      }
    });
    res.json({ success: true, message: "Payout rule updated successfully", data: rule });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout rule not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid rule ID" });
    }
    const data = { ...req.body };
    if (data.multiplier !== void 0) data.multiplier = parseFloat(data.multiplier);
    if (data.active !== void 0) data.active = Boolean(data.active);
    const rule = await prisma.payoutRule.update({
      where: { id },
      data
    });
    res.json({ success: true, message: "Payout rule patched successfully", data: rule });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout rule not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid rule ID" });
    }
    await prisma.payoutRule.delete({
      where: { id }
    });
    res.json({ success: true, message: "Payout rule deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout rule not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var payoutRules_default = router8;

// src/server/routes/terminalConfig.ts
import { Router as Router9 } from "express";
var router9 = Router9();
router9.get("/", async (_req, res) => {
  try {
    let config = await prisma.terminalConfig.findFirst();
    if (!config) {
      config = await prisma.terminalConfig.create({
        data: {
          stationName: "Station #04 - Counter 1",
          terminalNodeId: "NODE-4092-NYC-01",
          maxBetPerLine: 5e4,
          maxTicketLimit: 25e4,
          autoPrintReceipt: true,
          paperRollPct: 88,
          cutoffBufferSeconds: 60,
          soundEffectsEnabled: true
        }
      });
    }
    res.json({ success: true, data: config });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router9.put("/", async (req, res) => {
  try {
    const config = await prisma.terminalConfig.findFirst();
    const id = config ? config.id : 1;
    const {
      stationName,
      terminalNodeId,
      maxBetPerLine,
      maxTicketLimit,
      autoPrintReceipt,
      paperRollPct,
      cutoffBufferSeconds,
      soundEffectsEnabled
    } = req.body;
    const updated = await prisma.terminalConfig.upsert({
      where: { id },
      update: {
        stationName,
        terminalNodeId,
        maxBetPerLine: maxBetPerLine !== void 0 ? parseFloat(maxBetPerLine) : void 0,
        maxTicketLimit: maxTicketLimit !== void 0 ? parseFloat(maxTicketLimit) : void 0,
        autoPrintReceipt: autoPrintReceipt !== void 0 ? Boolean(autoPrintReceipt) : void 0,
        paperRollPct: paperRollPct !== void 0 ? parseInt(paperRollPct) : void 0,
        cutoffBufferSeconds: cutoffBufferSeconds !== void 0 ? parseInt(cutoffBufferSeconds) : void 0,
        soundEffectsEnabled: soundEffectsEnabled !== void 0 ? Boolean(soundEffectsEnabled) : void 0
      },
      create: {
        stationName: stationName || "Station #04 - Counter 1",
        terminalNodeId: terminalNodeId || "NODE-4092-NYC-01",
        maxBetPerLine: maxBetPerLine !== void 0 ? parseFloat(maxBetPerLine) : 5e4,
        maxTicketLimit: maxTicketLimit !== void 0 ? parseFloat(maxTicketLimit) : 25e4,
        autoPrintReceipt: autoPrintReceipt !== void 0 ? Boolean(autoPrintReceipt) : true,
        paperRollPct: paperRollPct !== void 0 ? parseInt(paperRollPct) : 88,
        cutoffBufferSeconds: cutoffBufferSeconds !== void 0 ? parseInt(cutoffBufferSeconds) : 60,
        soundEffectsEnabled: soundEffectsEnabled !== void 0 ? Boolean(soundEffectsEnabled) : true
      }
    });
    res.json({ success: true, message: "Terminal configuration updated successfully", data: updated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router9.patch("/", async (req, res) => {
  try {
    const config = await prisma.terminalConfig.findFirst();
    const id = config ? config.id : 1;
    const data = { ...req.body };
    if (data.maxBetPerLine !== void 0) data.maxBetPerLine = parseFloat(data.maxBetPerLine);
    if (data.maxTicketLimit !== void 0) data.maxTicketLimit = parseFloat(data.maxTicketLimit);
    if (data.autoPrintReceipt !== void 0) data.autoPrintReceipt = Boolean(data.autoPrintReceipt);
    if (data.paperRollPct !== void 0) data.paperRollPct = parseInt(data.paperRollPct);
    if (data.cutoffBufferSeconds !== void 0) data.cutoffBufferSeconds = parseInt(data.cutoffBufferSeconds);
    if (data.soundEffectsEnabled !== void 0) data.soundEffectsEnabled = Boolean(data.soundEffectsEnabled);
    const updated = await prisma.terminalConfig.upsert({
      where: { id },
      update: data,
      create: {
        stationName: "Station #04 - Counter 1",
        ...data
      }
    });
    res.json({ success: true, message: "Terminal configuration patched successfully", data: updated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var terminalConfig_default = router9;

// src/server/routes/shiftAudits.ts
import { Router as Router10 } from "express";
import { TransactionType as TransactionType4, PaymentMode as PaymentMode4 } from "@prisma/client";
var router10 = Router10();
router10.get("/", async (req, res) => {
  try {
    const { employeeId, status, limit = "20", offset = "0" } = req.query;
    const where = {};
    if (employeeId) where.employeeId = parseInt(employeeId);
    if (status) where.status = String(status);
    const take = parseInt(limit) || 20;
    const skip = parseInt(offset) || 0;
    const [total, shifts] = await Promise.all([
      prisma.shiftAudit.count({ where }),
      prisma.shiftAudit.findMany({
        where,
        take,
        skip,
        orderBy: { openedAt: "desc" },
        include: {
          employee: {
            select: { id: true, name: true, badgeId: true, role: true }
          }
        }
      })
    ]);
    res.json({ success: true, total, count: shifts.length, data: shifts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.get("/current", async (req, res) => {
  try {
    const { employeeId } = req.query;
    if (!employeeId) {
      return res.status(400).json({ success: false, message: "employeeId is required" });
    }
    const currentShift = await prisma.shiftAudit.findFirst({
      where: {
        employeeId: parseInt(employeeId),
        status: "OPEN"
      },
      include: {
        employee: { select: { id: true, name: true, badgeId: true } }
      }
    });
    if (!currentShift) {
      return res.json({ success: true, data: null, message: "No open shift found" });
    }
    const transactions = await prisma.transaction.findMany({
      where: {
        employeeId: currentShift.employeeId,
        paymentMode: PaymentMode4.CASH,
        createdAt: { gte: currentShift.openedAt }
      }
    });
    let liveSales = 0;
    let livePayouts = 0;
    for (const t of transactions) {
      if (t.type === TransactionType4.SALE) liveSales += t.amount;
      if (t.type === TransactionType4.PAYOUT) livePayouts += t.amount;
      if (t.type === TransactionType4.REFUND) liveSales -= t.amount;
    }
    const liveExpected = currentShift.openingFloat + liveSales - livePayouts;
    res.json({
      success: true,
      data: {
        ...currentShift,
        liveSales,
        livePayouts,
        liveExpectedCash: liveExpected
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid shift audit ID" });
    }
    const shift = await prisma.shiftAudit.findUnique({
      where: { id },
      include: {
        employee: true
      }
    });
    if (!shift) {
      return res.status(404).json({ success: false, message: "Shift audit not found" });
    }
    res.json({ success: true, data: shift });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.post("/open", async (req, res) => {
  try {
    const { employeeId, openingFloat, terminalId = "TERM-04" } = req.body;
    if (!employeeId || openingFloat === void 0) {
      return res.status(400).json({ success: false, message: "employeeId and openingFloat are required" });
    }
    const empId = parseInt(employeeId);
    const existing = await prisma.shiftAudit.findFirst({
      where: { employeeId: empId, status: "OPEN" }
    });
    if (existing) {
      return res.status(400).json({
        success: false,
        message: "An open shift already exists for this employee. Please close it first.",
        data: existing
      });
    }
    const shift = await prisma.$transaction(async (tx) => {
      const createdShift = await tx.shiftAudit.create({
        data: {
          employeeId: empId,
          terminalId,
          openingFloat: parseFloat(openingFloat),
          status: "OPEN",
          expectedCash: parseFloat(openingFloat)
        }
      });
      await tx.transaction.create({
        data: {
          employeeId: empId,
          type: TransactionType4.FLOAT_IN,
          amount: parseFloat(openingFloat),
          paymentMode: PaymentMode4.CASH,
          referenceNote: `Opening cash float for shift #${createdShift.id}`,
          idempotencyKey: `shift-open-${createdShift.id}`
        }
      });
      return createdShift;
    });
    res.status(201).json({ success: true, message: "Shift opened successfully", data: shift });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.post("/:id/close", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { actualCash, notes } = req.body;
    if (actualCash === void 0) {
      return res.status(400).json({ success: false, message: "actualCash counted is required to close shift" });
    }
    const shift = await prisma.shiftAudit.findUnique({
      where: { id }
    });
    if (!shift) {
      return res.status(404).json({ success: false, message: "Shift audit not found" });
    }
    if (shift.status === "CLOSED") {
      return res.status(400).json({ success: false, message: "Shift is already closed" });
    }
    const closedAt = /* @__PURE__ */ new Date();
    const transactions = await prisma.transaction.findMany({
      where: {
        employeeId: shift.employeeId,
        paymentMode: PaymentMode4.CASH,
        createdAt: {
          gte: shift.openedAt,
          lte: closedAt
        }
      }
    });
    let cashSales = 0;
    let cashPayouts = 0;
    for (const t of transactions) {
      if (t.type === TransactionType4.SALE) cashSales += t.amount;
      if (t.type === TransactionType4.PAYOUT) cashPayouts += t.amount;
      if (t.type === TransactionType4.REFUND) cashSales -= t.amount;
    }
    const expectedCash = shift.openingFloat + cashSales - cashPayouts;
    const countedCash = parseFloat(actualCash);
    const difference = countedCash - expectedCash;
    const closedShift = await prisma.$transaction(async (tx) => {
      const updated = await tx.shiftAudit.update({
        where: { id },
        data: {
          status: "CLOSED",
          cashSales,
          cashPayouts,
          expectedCash,
          actualCash: countedCash,
          closingFloat: countedCash,
          difference,
          closedAt
        }
      });
      await tx.transaction.create({
        data: {
          employeeId: shift.employeeId,
          type: TransactionType4.FLOAT_OUT,
          amount: countedCash,
          paymentMode: PaymentMode4.CASH,
          referenceNote: `End-of-shift cash drawer balance. Diff: ${difference.toFixed(2)}. ${notes || ""}`,
          idempotencyKey: `shift-close-${shift.id}`
        }
      });
      return updated;
    });
    res.json({
      success: true,
      message: `Shift #${id} closed successfully. Difference: INR ${difference.toFixed(2)}`,
      data: closedShift
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const shift = await prisma.shiftAudit.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Shift audit updated successfully", data: shift });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const shift = await prisma.shiftAudit.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Shift audit patched successfully", data: shift });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await prisma.shiftAudit.delete({ where: { id } });
    res.json({ success: true, message: "Shift audit deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var shiftAudits_default = router10;

// src/server/routes/loginActivities.ts
import { Router as Router11 } from "express";
var router11 = Router11();
router11.get("/", async (req, res) => {
  try {
    const { employeeId, limit = "50", offset = "0" } = req.query;
    const where = {};
    if (employeeId) where.employeeId = parseInt(employeeId);
    const take = parseInt(limit) || 50;
    const skip = parseInt(offset) || 0;
    const [total, logs] = await Promise.all([
      prisma.loginActivity.count({ where }),
      prisma.loginActivity.findMany({
        where,
        take,
        skip,
        orderBy: { loginTime: "desc" },
        include: {
          employee: {
            select: { id: true, name: true, badgeId: true, role: true }
          }
        }
      })
    ]);
    res.json({ success: true, total, count: logs.length, data: logs });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router11.post("/", async (req, res) => {
  try {
    const { employeeId, deviceInfo, ipAddress } = req.body;
    if (!employeeId) {
      return res.status(400).json({ success: false, message: "employeeId is required" });
    }
    const log = await prisma.loginActivity.create({
      data: {
        employeeId: parseInt(employeeId),
        deviceInfo: deviceInfo || "Web Terminal Client",
        ipAddress: ipAddress || req.ip
      },
      include: { employee: true }
    });
    res.status(201).json({ success: true, message: "Login recorded", data: log });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router11.patch("/:id/logout", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const log = await prisma.loginActivity.update({
      where: { id },
      data: { logoutTime: /* @__PURE__ */ new Date() }
    });
    res.json({ success: true, message: "Logout recorded", data: log });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router11.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await prisma.loginActivity.delete({ where: { id } });
    res.json({ success: true, message: "Record deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var loginActivities_default = router11;

// src/server/routes/cage.ts
import { Router as Router12 } from "express";
import { TicketStatus as TicketStatus3, PayoutStatus as PayoutStatus4, TransactionType as TransactionType5, PaymentMode as PaymentMode5 } from "@prisma/client";
var router12 = Router12();
async function getOrCreateCage(operatorId, tx = prisma) {
  let cage = null;
  if (operatorId) {
    cage = await tx.cage.findFirst({
      where: { operatorId, status: "OPEN" },
      orderBy: { id: "desc" }
    });
  }
  if (!cage) {
    cage = await tx.cage.findFirst({
      where: { status: "OPEN" },
      orderBy: { id: "desc" }
    });
  }
  if (!cage) {
    cage = await tx.cage.create({
      data: {
        cageCode: "CAGE-01",
        stationName: "Cage Desk #01",
        operatorId: operatorId || 3,
        openingFloat: 1e5,
        currentBalance: 1e5,
        totalPayout: 0,
        todayPaidCount: 0,
        status: "OPEN"
      }
    });
  }
  return cage;
}
router12.get("/verify-ticket/:query", async (req, res) => {
  try {
    const rawQuery = req.params.query.trim();
    const query = rawQuery;
    const cleanDigits = rawQuery.replace(/\D/g, "");
    const matchConditions = [
      { ticketNumber: query },
      { barcode: query },
      { securityCode: query },
      { contact: query }
    ];
    if (cleanDigits.length >= 3) {
      matchConditions.push({ contact: { contains: cleanDigits } });
    }
    if (query.length >= 3) {
      matchConditions.push({ contact: { contains: query } });
      matchConditions.push({ ticketNumber: { contains: query } });
      matchConditions.push({ barcode: { contains: query } });
    }
    const tickets = await prisma.ticket.findMany({
      where: {
        OR: matchConditions
      },
      take: 25,
      orderBy: { createdAt: "desc" },
      include: {
        employee: {
          select: { id: true, name: true, badgeId: true }
        },
        bets: {
          include: {
            game: {
              include: {
                results: {
                  take: 1,
                  orderBy: { declaredAt: "desc" }
                }
              }
            },
            payout: {
              include: {
                processedBy: { select: { id: true, name: true } }
              }
            }
          }
        },
        transactions: true
      }
    });
    if (!tickets || tickets.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No ticket found matching identifier or contact "${query}"`
      });
    }
    const ticket = tickets[0];
    const payoutRules = await prisma.payoutRule.findMany({ where: { active: true } });
    const isTicketVoided = ticket.status === TicketStatus3.CANCELLED || ticket.status === TicketStatus3.VOID;
    let totalClaimableAmount = 0;
    let totalPaidAmount = 0;
    let winningBetsCount = 0;
    let pendingDrawsCount = 0;
    let awaitingCloseCount = 0;
    const betEvaluations = ticket.bets.map((bet) => {
      const latestResult = bet.game.results[0] || null;
      const isDrawn = Boolean(latestResult && latestResult.winningNumber && latestResult.winningNumber.trim().toLowerCase() !== "pending");
      const isGameCompleted = Boolean(latestResult && (latestResult.status === "COMPLETED" || !latestResult.winningNumber.includes("*") && latestResult.winningNumber.includes("-")));
      const isOpenDeclaredOnly = Boolean(latestResult && !isGameCompleted && (latestResult.status === "OPEN_DECLARED" || latestResult.winningNumber.includes("*")));
      if (isTicketVoided) {
        return {
          betId: bet.id,
          gameName: bet.game.name,
          gameCode: bet.game.code,
          gameStatus: bet.game.status,
          resultWinningNumber: latestResult ? latestResult.winningNumber : null,
          resultDeclaredAt: latestResult ? latestResult.declaredAt : null,
          selectedNumber: bet.selectedNumber,
          open: bet.open,
          close: bet.close,
          betType: bet.betType,
          stakeAmount: bet.amount,
          multiplier: bet.multiplier,
          potentialPayout: 0,
          grossWinningAmount: 0,
          alreadyRedeemed: 0,
          isWinner: false,
          isMatched: false,
          hasRedeemed: false,
          status: "VOIDED",
          claimableAmount: 0,
          payoutRecord: null,
          calculation: {
            formula: "TICKET VOIDED \u2014 No claimable payout",
            stakeAmount: bet.amount,
            multiplier: 0,
            grossPayout: 0,
            alreadyRedeemed: 0,
            claimableAmount: 0,
            selectedNumber: bet.selectedNumber,
            open: bet.open,
            close: bet.close,
            winningNumber: latestResult ? latestResult.winningNumber : null,
            isMatched: false,
            hasRedeemed: false,
            betType: bet.betType,
            ruleDescription: "Ticket has been voided. All wagers refunded and redemption disabled."
          }
        };
      }
      const evalRes = evaluateTieredBetWin(
        bet,
        latestResult ? latestResult.winningNumber : null,
        latestResult ? latestResult.openPana : null,
        latestResult ? latestResult.closePana : null,
        payoutRules
      );
      if (evalRes.status === "AWAITING_DRAW") {
        pendingDrawsCount++;
      }
      if (evalRes.isAwaitingClose) {
        awaitingCloseCount++;
      }
      if (evalRes.claimableAmount > 0) {
        winningBetsCount++;
        totalClaimableAmount += evalRes.claimableAmount;
      }
      if (evalRes.alreadyRedeemed > 0) {
        totalPaidAmount += evalRes.alreadyRedeemed;
      }
      const betSession = categorizeBetSession(bet);
      return {
        betId: bet.id,
        gameName: bet.game.name,
        gameCode: bet.game.code,
        gameStatus: bet.game.status,
        resultWinningNumber: latestResult ? latestResult.winningNumber : null,
        resultStatus: latestResult ? latestResult.status : null,
        resultDeclaredAt: latestResult ? latestResult.declaredAt : null,
        selectedNumber: bet.selectedNumber,
        open: bet.open,
        close: bet.close,
        betType: bet.betType,
        session: betSession,
        stakeAmount: bet.amount,
        multiplier: bet.multiplier,
        potentialPayout: bet.potentialPayout,
        grossWinningAmount: evalRes.grossWinningAmount,
        alreadyRedeemed: evalRes.alreadyRedeemed,
        isWinner: evalRes.isOpenMatched || evalRes.isCloseMatched || evalRes.isFullJackpotWon,
        isMatched: evalRes.isOpenMatched || evalRes.isCloseMatched || evalRes.isFullJackpotWon,
        hasRedeemed: evalRes.alreadyRedeemed > 0 && evalRes.claimableAmount === 0 && !evalRes.isAwaitingClose,
        status: evalRes.status,
        claimableAmount: evalRes.claimableAmount,
        payoutRecord: bet.payout,
        isMultiStage: evalRes.isMultiStage,
        calculation: {
          formula: evalRes.isMultiStage ? `Gross: INR ${evalRes.grossWinningAmount.toFixed(2)}${evalRes.alreadyRedeemed > 0 ? ` - Already Paid at Open: INR ${evalRes.alreadyRedeemed.toFixed(2)}` : ""} = Net Claimable: INR ${evalRes.claimableAmount.toFixed(2)}` : `INR ${bet.amount.toFixed(2)} \xD7 ${bet.multiplier.toFixed(1)}x = INR ${bet.potentialPayout.toFixed(2)}`,
          stakeAmount: bet.amount,
          multiplier: bet.multiplier,
          grossPayout: evalRes.grossWinningAmount,
          alreadyRedeemed: evalRes.alreadyRedeemed,
          claimableAmount: evalRes.claimableAmount,
          selectedNumber: bet.selectedNumber,
          open: bet.open,
          close: bet.close,
          winningNumber: latestResult ? latestResult.winningNumber : null,
          isMatched: evalRes.isOpenMatched || evalRes.isCloseMatched || evalRes.isFullJackpotWon,
          hasRedeemed: evalRes.alreadyRedeemed > 0 && evalRes.claimableAmount === 0 && !evalRes.isAwaitingClose,
          betType: bet.betType,
          session: betSession,
          ruleDescription: evalRes.description
        }
      };
    });
    let overallVerdict;
    let verdictMessage = "";
    if (isTicketVoided) {
      overallVerdict = "CANCELLED_VOID";
      verdictMessage = "Ticket is cancelled / voided. Redemption disabled.";
      totalClaimableAmount = 0;
      totalPaidAmount = 0;
      winningBetsCount = 0;
    } else if (ticket.status === TicketStatus3.PAID || totalPaidAmount > 0 && totalClaimableAmount === 0 && awaitingCloseCount === 0 && pendingDrawsCount === 0) {
      overallVerdict = "ALREADY_REDEEMED";
      verdictMessage = `Ticket has already been fully redeemed and paid out (Total Paid: INR ${totalPaidAmount.toFixed(2)}).`;
    } else if (totalClaimableAmount > 0) {
      overallVerdict = "READY_FOR_PAYOUT";
      if (awaitingCloseCount > 0) {
        verdictMessage = `Partial Redemption Available! Open winning lines claimable now: INR ${totalClaimableAmount.toFixed(2)} (${awaitingCloseCount} line(s) awaiting Close draw result). Same barcode remains active for Close.`;
      } else if (totalPaidAmount > 0) {
        verdictMessage = `Full Fortune Winner! Gross Prize: INR ${(totalClaimableAmount + totalPaidAmount).toFixed(2)}, Already Paid at Open: -INR ${totalPaidAmount.toFixed(2)}, Net Balance Payable: INR ${totalClaimableAmount.toFixed(2)}.`;
      } else {
        verdictMessage = `Verified winning ticket! Total payable: INR ${totalClaimableAmount.toFixed(2)}`;
      }
    } else if (awaitingCloseCount > 0) {
      overallVerdict = "AWAITING_CLOSE";
      if (totalPaidAmount > 0) {
        verdictMessage = `Open winnings (INR ${totalPaidAmount.toFixed(2)}) already paid out. Remaining ${awaitingCloseCount} line(s) awaiting Close draw result.`;
      } else {
        verdictMessage = `Open declared. ${awaitingCloseCount} line(s) on this ticket are awaiting Close draw result. No claimable Open winnings.`;
      }
    } else if (pendingDrawsCount > 0) {
      overallVerdict = "AWAITING_RESULTS";
      verdictMessage = "Draw result not yet declared. Wagering in progress.";
    } else {
      overallVerdict = "NOT_A_WINNER";
      verdictMessage = "Draw completed. No winning lines found on this ticket.";
    }
    res.json({
      success: true,
      multiple: tickets.length > 1,
      totalMatches: tickets.length,
      matchingTickets: tickets.length > 1 ? tickets.map((t) => ({
        id: t.id,
        ticketNumber: t.ticketNumber,
        barcode: t.barcode,
        contact: t.contact,
        totalAmount: t.totalAmount,
        status: t.status,
        createdAt: t.createdAt,
        gameName: t.bets[0]?.game?.name || "Hourly Draw",
        drawNumber: t.bets[0]?.game?.code || t.bets[0]?.game?.drawNumber || String(t.bets[0]?.game?.id || ""),
        betsCount: t.bets.length
      })) : [],
      data: {
        ticket: {
          id: ticket.id,
          ticketNumber: ticket.ticketNumber,
          barcode: ticket.barcode,
          securityCode: ticket.securityCode,
          contact: ticket.contact,
          status: ticket.status,
          totalAmount: ticket.totalAmount,
          createdAt: ticket.createdAt,
          settledAt: ticket.settledAt,
          issuedBy: ticket.employee.name,
          issuedBadgeId: ticket.employee.badgeId
        },
        summary: {
          overallVerdict,
          verdictMessage,
          totalBets: ticket.bets.length,
          winningBetsCount: isTicketVoided ? 0 : winningBetsCount,
          isWinner: isTicketVoided ? false : winningBetsCount > 0,
          hasRedeemed: isTicketVoided ? false : ticket.status === TicketStatus3.PAID || totalPaidAmount > 0 && totalClaimableAmount === 0 && awaitingCloseCount === 0 && pendingDrawsCount === 0,
          pendingDrawsCount: isTicketVoided ? 0 : pendingDrawsCount,
          awaitingCloseCount: isTicketVoided ? 0 : awaitingCloseCount,
          totalClaimableAmount: isTicketVoided ? 0 : totalClaimableAmount,
          totalPaidAmount: isTicketVoided ? 0 : totalPaidAmount,
          totalGrossWinningAmount: isTicketVoided ? 0 : totalClaimableAmount + totalPaidAmount,
          canRedeem: isTicketVoided ? false : totalClaimableAmount > 0,
          isPartialRedemption: isTicketVoided ? false : totalClaimableAmount > 0 && awaitingCloseCount > 0,
          isCloseStageClaim: isTicketVoided ? false : totalPaidAmount > 0 && totalClaimableAmount > 0 && awaitingCloseCount === 0,
          policy: "Open winnings can be redeemed immediately upon Open declaration. Lines requiring Close are held until Close declaration.",
          previousPayouts: ticket.transactions ? ticket.transactions.filter((tx) => tx.type === "PAYOUT").map((tx) => ({
            id: tx.id,
            amount: tx.amount,
            paymentMode: tx.paymentMode,
            referenceNote: tx.referenceNote,
            createdAt: tx.createdAt,
            employeeId: tx.employeeId
          })) : []
        },
        bets: betEvaluations
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router12.post("/redeem-ticket", async (req, res) => {
  const rawIdempotencyKey = req.headers["x-idempotency-key"] || req.headers["idempotency-key"] || req.body.idempotencyKey;
  const idempotencyKey = rawIdempotencyKey ? String(rawIdempotencyKey).trim() : void 0;
  const { ticketId, operatorId, claimedBy, paymentMode = "CASH" } = req.body;
  try {
    if (!ticketId || !operatorId) {
      return res.status(400).json({
        success: false,
        message: "ticketId and operatorId are required"
      });
    }
    const tId = parseInt(ticketId);
    const opId = parseInt(operatorId);
    if (idempotencyKey) {
      const existingTx = await prisma.transaction.findUnique({
        where: { idempotencyKey: `payout-${idempotencyKey}` },
        include: { ticket: true }
      });
      if (existingTx) {
        return res.json({
          success: true,
          isDuplicate: true,
          message: "Ticket redemption already processed (idempotent replay)",
          data: {
            ticketNumber: existingTx.ticket?.ticketNumber,
            barcode: existingTx.ticket?.barcode,
            redeemedAmount: existingTx.amount,
            paymentMode: existingTx.paymentMode,
            paidAt: existingTx.createdAt,
            processedById: existingTx.employeeId,
            transactionId: existingTx.id,
            voucherCode: `VCH-${new Date(existingTx.createdAt).getFullYear()}${String(new Date(existingTx.createdAt).getMonth() + 1).padStart(2, "0")}-${String(existingTx.ticketId || 0).padStart(4, "0")}`,
            ticketStatus: existingTx.ticket?.status || TicketStatus3.PAID,
            isPartial: false,
            claimedBy: claimedBy || "Walk-in Customer"
          }
        });
      }
    }
    const redemptionResult = await prisma.$transaction(async (tx) => {
      const ticket = await tx.ticket.findUnique({
        where: { id: tId },
        include: {
          bets: {
            include: {
              payout: true,
              game: {
                include: {
                  results: {
                    take: 1,
                    orderBy: { declaredAt: "desc" }
                  }
                }
              }
            }
          }
        }
      });
      if (!ticket) {
        throw new Error("Ticket not found");
      }
      if (ticket.status === TicketStatus3.CANCELLED || ticket.status === TicketStatus3.VOID) {
        throw new Error(`Ticket is ${ticket.status} and cannot be redeemed`);
      }
      if (ticket.status === TicketStatus3.PAID) {
        throw new Error("This ticket has already been settled and paid out");
      }
      const payoutRules = await tx.payoutRule.findMany({ where: { active: true } });
      const payableBets = [];
      let totalPayable = 0;
      let remainingUnsettledBetsCount = 0;
      for (const bet of ticket.bets) {
        const latestResult = bet.game.results[0];
        if (!latestResult || !latestResult.winningNumber || latestResult.winningNumber.trim().toLowerCase() === "pending") {
          remainingUnsettledBetsCount++;
          continue;
        }
        const evalRes = evaluateTieredBetWin(
          bet,
          latestResult.winningNumber,
          latestResult.openPana,
          latestResult.closePana,
          payoutRules
        );
        if (evalRes.isAwaitingClose) {
          remainingUnsettledBetsCount++;
        }
        if (evalRes.claimableAmount > 0) {
          let payout = bet.payout;
          if (!payout) {
            payout = await tx.payout.create({
              data: {
                betId: bet.id,
                winningAmount: evalRes.grossWinningAmount || evalRes.claimableAmount,
                status: PayoutStatus4.PENDING
              }
            });
          }
          totalPayable += evalRes.claimableAmount;
          payableBets.push({ bet, payout, payableAmount: evalRes.claimableAmount, evalRes });
        }
      }
      if (payableBets.length === 0) {
        if (remainingUnsettledBetsCount > 0) {
          throw new Error("This ticket has no claimable winning lines currently available. Remaining line(s) are awaiting draw or Close declaration.");
        }
        throw new Error("This ticket has no verified unclaimed winning lines");
      }
      const isPartial = remainingUnsettledBetsCount > 0;
      const totalPaidBefore = ticket.bets.reduce((sum, b) => sum + (Number(b.redeemedAmount) || 0), 0);
      const cage = await getOrCreateCage(opId, tx);
      const prevBalance = cage.currentBalance;
      const validPayment = Object.values(PaymentMode5).includes(paymentMode) ? paymentMode : PaymentMode5.CASH;
      const now = /* @__PURE__ */ new Date();
      for (const item of payableBets) {
        const newRedeemed = (Number(item.bet.redeemedAmount) || 0) + item.payableAmount;
        const isBetSettled = item.evalRes.isFullySettled || !item.evalRes.isAwaitingClose;
        await tx.bet.update({
          where: { id: item.bet.id },
          data: {
            redeemedAmount: newRedeemed,
            hasRedeemed: isBetSettled
          }
        });
        await tx.payout.update({
          where: { id: item.payout.id },
          data: {
            winningAmount: item.evalRes.grossWinningAmount || item.payout.winningAmount,
            paidAmount: (Number(item.payout.paidAmount) || 0) + item.payableAmount,
            status: isBetSettled ? PayoutStatus4.PAID : PayoutStatus4.PENDING,
            claimedBy: claimedBy || "Walk-in Customer",
            processedById: opId,
            paidAt: now
          }
        });
      }
      const payoutTx = await tx.transaction.create({
        data: {
          ticketId: ticket.id,
          employeeId: opId,
          type: TransactionType5.PAYOUT,
          amount: totalPayable,
          paymentMode: validPayment,
          referenceNote: isPartial ? `Cage Partial Redemption Voucher: Paid INR ${totalPayable.toFixed(2)} (${validPayment}) (Open Winnings) for ${ticket.ticketNumber} [Same barcode active for Close]` : `Cage Redemption Voucher: Paid INR ${totalPayable.toFixed(2)} (${validPayment}) for ${ticket.ticketNumber}`,
          idempotencyKey: idempotencyKey ? `payout-${idempotencyKey}` : null
        }
      });
      const updatedTicket = await tx.ticket.update({
        where: { id: ticket.id },
        data: {
          status: isPartial ? TicketStatus3.ACTIVE : TicketStatus3.PAID,
          settledAt: isPartial ? null : now
        }
      });
      const updatedCage = await tx.cage.update({
        where: { id: cage.id },
        data: {
          currentBalance: { decrement: totalPayable },
          totalPayout: { increment: totalPayable },
          todayPaidCount: { increment: 1 }
        }
      });
      let activeShift = await tx.shiftAudit.findFirst({
        where: { employeeId: opId, status: "OPEN" },
        orderBy: { openedAt: "desc" }
      });
      if (activeShift) {
        await tx.shiftAudit.update({
          where: { id: activeShift.id },
          data: {
            cashPayouts: { increment: totalPayable },
            expectedCash: { decrement: totalPayable }
          }
        });
      }
      const voucherCode = `VCH-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}-${String(ticket.id).padStart(4, "0")}`;
      return {
        ticketNumber: ticket.ticketNumber,
        barcode: ticket.barcode,
        redeemedAmount: totalPayable,
        paymentMode: validPayment,
        paidAt: now,
        processedById: opId,
        transactionId: payoutTx.id,
        voucherCode,
        redeemedLinesCount: payableBets.length,
        ticketStatus: updatedTicket.status,
        isPartial,
        totalPaidBefore,
        totalGrossPrize: totalPayable + totalPaidBefore,
        remainingUnsettledBetsCount,
        claimedBy: claimedBy || "Walk-in Customer",
        cageBalance: {
          previousBalance: prevBalance,
          debitedAmount: totalPayable,
          newBalance: updatedCage.currentBalance,
          openingFloat: updatedCage.openingFloat,
          totalPayoutsToday: updatedCage.totalPayout
        }
      };
    });
    res.json({
      success: true,
      message: redemptionResult.isPartial ? `Partial redemption complete! Paid INR ${redemptionResult.redeemedAmount.toFixed(2)} (${redemptionResult.paymentMode}) for Open winnings. Ticket remains ACTIVE for ${redemptionResult.remainingUnsettledBetsCount} pending line(s).` : `Redemption complete! Paid INR ${redemptionResult.redeemedAmount.toFixed(2)} (${redemptionResult.paymentMode}). Ticket settled in full.`,
      data: redemptionResult
    });
  } catch (error) {
    if (error.code === "P2002" && idempotencyKey) {
      const existingTx = await prisma.transaction.findUnique({
        where: { idempotencyKey: `payout-${idempotencyKey}` },
        include: { ticket: true }
      });
      if (existingTx) {
        return res.json({
          success: true,
          isDuplicate: true,
          message: "Ticket redemption already processed (idempotent replay)",
          data: {
            ticketNumber: existingTx.ticket?.ticketNumber,
            barcode: existingTx.ticket?.barcode,
            redeemedAmount: existingTx.amount,
            paymentMode: existingTx.paymentMode,
            paidAt: existingTx.createdAt,
            processedById: existingTx.employeeId,
            transactionId: existingTx.id,
            voucherCode: `VCH-${new Date(existingTx.createdAt).getFullYear()}${String(new Date(existingTx.createdAt).getMonth() + 1).padStart(2, "0")}-${String(existingTx.ticketId || 0).padStart(4, "0")}`,
            ticketStatus: existingTx.ticket?.status || TicketStatus3.PAID,
            isPartial: false,
            claimedBy: claimedBy || "Walk-in Customer"
          }
        });
      }
    }
    res.status(400).json({ success: false, message: error.message });
  }
});
router12.post("/float-adjustment", async (req, res) => {
  const rawIdempotencyKey = req.headers["x-idempotency-key"] || req.headers["idempotency-key"] || req.body.idempotencyKey;
  const idempotencyKey = rawIdempotencyKey ? String(rawIdempotencyKey).trim() : void 0;
  try {
    const { operatorId, amount, type = "FLOAT_IN", note } = req.body;
    const opId = parseInt(operatorId);
    const adjAmount = parseFloat(amount);
    if (!opId || isNaN(adjAmount) || adjAmount <= 0) {
      return res.status(400).json({ success: false, message: "Valid operatorId and positive amount required" });
    }
    if (idempotencyKey) {
      const existingTx = await prisma.transaction.findUnique({
        where: { idempotencyKey: `float-${idempotencyKey}` }
      });
      if (existingTx) {
        return res.json({
          success: true,
          isDuplicate: true,
          message: "Float adjustment already processed (idempotent replay)",
          data: {
            transactionId: existingTx.id,
            adjustment: existingTx.type === TransactionType5.FLOAT_IN ? existingTx.amount : -existingTx.amount,
            type: existingTx.type
          }
        });
      }
    }
    const result = await prisma.$transaction(async (tx) => {
      const cage = await getOrCreateCage(opId, tx);
      const txType = type === "FLOAT_OUT" ? TransactionType5.FLOAT_OUT : TransactionType5.FLOAT_IN;
      const delta = txType === TransactionType5.FLOAT_IN ? adjAmount : -adjAmount;
      if (txType === TransactionType5.FLOAT_OUT && cage.currentBalance < adjAmount) {
        throw new Error(`Insufficient Cage balance for Float Out (Available: INR ${cage.currentBalance.toFixed(2)})`);
      }
      await tx.transaction.create({
        data: {
          employeeId: opId,
          type: txType,
          amount: adjAmount,
          paymentMode: PaymentMode5.CASH,
          referenceNote: note || (txType === TransactionType5.FLOAT_IN ? "Vault Float In" : "Vault Cash Drop Float Out"),
          idempotencyKey: idempotencyKey ? `float-${idempotencyKey}` : null
        }
      });
      const updatedCage = await tx.cage.update({
        where: { id: cage.id },
        data: {
          currentBalance: { increment: delta },
          ...txType === TransactionType5.FLOAT_IN ? { openingFloat: { increment: adjAmount } } : {}
        }
      });
      let activeShift = await tx.shiftAudit.findFirst({
        where: { employeeId: opId, status: "OPEN" },
        orderBy: { openedAt: "desc" }
      });
      if (activeShift) {
        await tx.shiftAudit.update({
          where: { id: activeShift.id },
          data: { expectedCash: { increment: delta } }
        });
      }
      return {
        previousBalance: cage.currentBalance,
        adjustment: delta,
        newBalance: updatedCage.currentBalance,
        openingFloat: updatedCage.openingFloat,
        type: txType
      };
    });
    res.json({ success: true, message: `Cage float adjusted by INR ${adjAmount.toFixed(2)}`, data: result });
  } catch (error) {
    if (error.code === "P2002" && idempotencyKey) {
      const existingTx = await prisma.transaction.findUnique({
        where: { idempotencyKey: `float-${idempotencyKey}` }
      });
      if (existingTx) {
        return res.json({
          success: true,
          isDuplicate: true,
          message: "Float adjustment already processed (idempotent replay)",
          data: {
            transactionId: existingTx.id,
            adjustment: existingTx.type === TransactionType5.FLOAT_IN ? existingTx.amount : -existingTx.amount,
            type: existingTx.type
          }
        });
      }
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router12.get("/", async (req, res) => {
  try {
    const { operatorId } = req.query;
    const opId = operatorId ? parseInt(operatorId) : void 0;
    const cage = await getOrCreateCage(opId);
    res.json({ success: true, data: cage });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router12.get("/summary", async (req, res) => {
  try {
    const { operatorId, date, startDate, endDate, gameId } = req.query;
    const opId = operatorId ? parseInt(operatorId) : void 0;
    const cage = await getOrCreateCage(opId);
    let todayStart;
    let todayEnd;
    let localDateStr;
    const sParam = startDate || date;
    const eParam = endDate || date;
    if (sParam && typeof sParam === "string" && /^\d{4}-\d{2}-\d{2}$/.test(sParam)) {
      const [sy, sm, sd] = sParam.split("-").map(Number);
      todayStart = new Date(Date.UTC(sy, sm - 1, sd, 0, 0, 0, 0) - 5.5 * 3600 * 1e3);
      if (eParam && typeof eParam === "string" && /^\d{4}-\d{2}-\d{2}$/.test(eParam)) {
        const [ey, em, ed] = eParam.split("-").map(Number);
        todayEnd = new Date(Date.UTC(ey, em - 1, ed, 23, 59, 59, 999) - 5.5 * 3600 * 1e3);
      } else {
        todayEnd = new Date(Date.UTC(sy, sm - 1, sd, 23, 59, 59, 999) - 5.5 * 3600 * 1e3);
      }
      localDateStr = sParam;
    } else {
      const istRange = getISTDayRange();
      todayStart = istRange.start;
      todayEnd = istRange.end;
      localDateStr = istRange.dateStr;
    }
    const [
      todayPaidAgg,
      todayPendingPayouts,
      todayRedemptions,
      todayFloatInAgg,
      todayFloatOutAgg,
      todayTicketsSoldAgg,
      todayVoidedAgg,
      todayRefundAgg
    ] = await Promise.all([
      // Today's Settled Payouts strictly between start of day and end of day:
      // Authoritative source is the Transaction table with type PAYOUT (cash disbursed at the cage)
      prisma.transaction.aggregate({
        where: {
          type: TransactionType5.PAYOUT,
          createdAt: {
            gte: todayStart,
            lte: todayEnd
          },
          ...gameId ? { ticket: { bets: { some: { gameId: parseInt(gameId) } } } } : {}
        },
        _sum: { amount: true },
        _count: true
      }),
      // Unclaimed winning liability declared today
      prisma.payout.aggregate({
        where: {
          status: PayoutStatus4.PENDING,
          paidAt: null,
          createdAt: {
            gte: todayStart,
            lte: todayEnd
          }
        },
        _sum: { winningAmount: true },
        _count: true
      }),
      // Today's settled payouts for the Settlement Audit Ledger & Big Wins Ticker
      prisma.payout.findMany({
        where: {
          OR: [
            { status: PayoutStatus4.PAID },
            { paidAmount: { gt: 0 } }
          ],
          paidAt: {
            gte: todayStart,
            lte: todayEnd
          },
          ...gameId ? { bet: { gameId: parseInt(gameId) } } : {}
        },
        orderBy: { paidAt: "desc" },
        include: {
          bet: {
            include: {
              game: { select: { id: true, name: true, code: true } },
              ticket: { select: { ticketNumber: true, barcode: true, totalAmount: true } }
            }
          },
          processedBy: { select: { id: true, name: true, badgeId: true } }
        }
      }),
      // Today's Float-In transactions
      prisma.transaction.aggregate({
        where: {
          type: TransactionType5.FLOAT_IN,
          createdAt: { gte: todayStart, lte: todayEnd }
        },
        _sum: { amount: true }
      }),
      // Today's Float-Out transactions
      prisma.transaction.aggregate({
        where: {
          type: TransactionType5.FLOAT_OUT,
          createdAt: { gte: todayStart, lte: todayEnd }
        },
        _sum: { amount: true }
      }),
      // Total tickets sold today (excluding cancelled / voided)
      prisma.ticket.aggregate({
        where: {
          createdAt: {
            gte: todayStart,
            lte: todayEnd
          },
          status: { notIn: [TicketStatus3.CANCELLED, TicketStatus3.VOID] }
        },
        _count: true,
        _sum: { totalAmount: true }
      }),
      // Voided / Cancelled tickets for the selected period
      prisma.ticket.aggregate({
        where: {
          createdAt: {
            gte: todayStart,
            lte: todayEnd
          },
          status: { in: [TicketStatus3.CANCELLED, TicketStatus3.VOID] }
        },
        _count: true,
        _sum: { totalAmount: true }
      }),
      // Refund transactions in ledger for the selected period
      prisma.transaction.aggregate({
        where: {
          type: TransactionType5.REFUND,
          createdAt: { gte: todayStart, lte: todayEnd }
        },
        _count: true,
        _sum: { amount: true }
      })
    ]);
    const todayPaidAmount = todayPaidAgg._sum.amount || 0;
    const todayPaidCount = todayPaidAgg._count || 0;
    const todayFloatIn = todayFloatInAgg._sum.amount || 0;
    const todayFloatOut = todayFloatOutAgg._sum.amount || 0;
    const todayTicketsSoldCount = todayTicketsSoldAgg._count || 0;
    const todayTicketsSoldAmount = todayTicketsSoldAgg._sum.totalAmount || 0;
    const todayVoidedCount = todayVoidedAgg._count || 0;
    const todayVoidedAmount = todayVoidedAgg._sum.totalAmount || todayRefundAgg._sum.amount || 0;
    const todayRefundCount = todayRefundAgg._count || 0;
    const todayRefundAmount = todayRefundAgg._sum.amount || 0;
    const netDailyPosition = todayTicketsSoldAmount - todayPaidAmount;
    const isShiftOpenedToday = cage.openedAt ? new Date(cage.openedAt) >= todayStart : false;
    const todayOpeningFloat = isShiftOpenedToday ? cage.openingFloat : cage.currentBalance + todayPaidAmount - todayFloatIn + todayFloatOut;
    const cageBalance = {
      openingFloat: todayOpeningFloat,
      currentBalance: cage.currentBalance,
      cashPayouts: todayPaidAmount,
      totalPayout: todayPaidAmount,
      todayPaidCount,
      todayPaidAmount,
      todayFloatIn,
      todayFloatOut,
      todayTicketsSoldCount,
      todayTicketsSoldAmount,
      todayVoidedCount,
      todayVoidedAmount,
      todayRefundCount,
      todayRefundAmount,
      netDailyPosition,
      status: cage.status,
      shiftOpenedAt: cage.openedAt,
      date: localDateStr
    };
    res.json({
      success: true,
      data: {
        date: localDateStr,
        cage: {
          ...cage,
          openingFloat: todayOpeningFloat,
          totalPayout: todayPaidAmount,
          todayPaidCount
        },
        cageBalance,
        todayPaidCount,
        todayPaidAmount,
        todayFloatIn,
        todayFloatOut,
        todayTicketsSoldCount,
        todayTicketsSoldAmount,
        todayVoidedCount,
        todayVoidedAmount,
        todayRefundCount,
        todayRefundAmount,
        netDailyPosition,
        todayTicketsSold: {
          count: todayTicketsSoldCount,
          totalAmount: todayTicketsSoldAmount
        },
        todayVoided: {
          count: todayVoidedCount,
          totalAmount: todayVoidedAmount
        },
        unclaimedPendingCount: todayPendingPayouts._count || 0,
        unclaimedPendingAmount: todayPendingPayouts._sum.winningAmount || 0,
        recentRedemptions: todayRedemptions
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var cage_default = router12;

// src/server/routes/admin.ts
import { Router as Router13 } from "express";
import { TransactionType as TransactionType6, TicketStatus as TicketStatus4 } from "@prisma/client";
var router13 = Router13();
router13.get("/metrics", async (_req, res) => {
  try {
    const todayStart = /* @__PURE__ */ new Date();
    todayStart.setHours(0, 0, 0, 0);
    const [
      totalTickets,
      activeTickets,
      todayTickets,
      totalSalesAgg,
      todaySalesAgg,
      totalPayoutsAgg,
      todayPayoutsAgg,
      totalEmployees,
      activeGames,
      recentTransactions,
      totalVoidedTickets,
      todayVoidedTickets,
      totalRefundsAgg,
      todayRefundsAgg
    ] = await Promise.all([
      prisma.ticket.count({ where: { status: { notIn: [TicketStatus4.CANCELLED, TicketStatus4.VOID] } } }),
      prisma.ticket.count({ where: { status: TicketStatus4.ACTIVE } }),
      prisma.ticket.count({ where: { createdAt: { gte: todayStart }, status: { notIn: [TicketStatus4.CANCELLED, TicketStatus4.VOID] } } }),
      prisma.transaction.aggregate({
        where: {
          type: TransactionType6.SALE,
          ticket: { status: { notIn: [TicketStatus4.CANCELLED, TicketStatus4.VOID] } }
        },
        _sum: { amount: true }
      }),
      prisma.transaction.aggregate({
        where: {
          type: TransactionType6.SALE,
          createdAt: { gte: todayStart },
          ticket: { status: { notIn: [TicketStatus4.CANCELLED, TicketStatus4.VOID] } }
        },
        _sum: { amount: true }
      }),
      prisma.transaction.aggregate({
        where: { type: TransactionType6.PAYOUT },
        _sum: { amount: true }
      }),
      prisma.transaction.aggregate({
        where: { type: TransactionType6.PAYOUT, createdAt: { gte: todayStart } },
        _sum: { amount: true }
      }),
      prisma.employee.count(),
      prisma.game.count({ where: { status: true } }),
      prisma.transaction.findMany({
        take: 8,
        orderBy: { createdAt: "desc" },
        include: {
          employee: { select: { id: true, name: true, badgeId: true } },
          ticket: { select: { ticketNumber: true } }
        }
      }),
      prisma.ticket.count({ where: { status: { in: [TicketStatus4.CANCELLED, TicketStatus4.VOID] } } }),
      prisma.ticket.count({ where: { createdAt: { gte: todayStart }, status: { in: [TicketStatus4.CANCELLED, TicketStatus4.VOID] } } }),
      prisma.transaction.aggregate({
        where: { type: TransactionType6.REFUND },
        _sum: { amount: true }
      }),
      prisma.transaction.aggregate({
        where: { type: TransactionType6.REFUND, createdAt: { gte: todayStart } },
        _sum: { amount: true }
      })
    ]);
    const totalSales = totalSalesAgg._sum.amount || 0;
    const todaySales = todaySalesAgg._sum.amount || 0;
    const totalPayouts = totalPayoutsAgg._sum.amount || 0;
    const todayPayouts = todayPayoutsAgg._sum.amount || 0;
    const totalRefunds = totalRefundsAgg._sum.amount || 0;
    const todayRefunds = todayRefundsAgg._sum.amount || 0;
    const netGrossGamingRevenue = totalSales - totalPayouts;
    const todayNetRevenue = todaySales - todayPayouts;
    const payoutRatio = totalSales > 0 ? totalPayouts / totalSales * 100 : 0;
    res.json({
      success: true,
      data: {
        kpis: {
          totalSales,
          todaySales,
          totalPayouts,
          todayPayouts,
          netGrossGamingRevenue,
          todayNetRevenue,
          payoutRatio: parseFloat(payoutRatio.toFixed(1)),
          totalTickets,
          activeTickets,
          todayTickets,
          totalEmployees,
          activeGames,
          totalVoidedTickets,
          todayVoidedTickets,
          totalRefunds,
          todayRefunds
        },
        recentTransactions
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router13.get("/game-analytics", async (req, res) => {
  try {
    const { startDate, endDate, limit, activeOnly } = req.query;
    const where = {};
    if (startDate || endDate) {
      const sDigits = startDate ? startDate.replace(/[^0-9]/g, "").slice(0, 8) : null;
      const eDigits = endDate ? endDate.replace(/[^0-9]/g, "").slice(0, 8) : null;
      if (sDigits?.length === 8 || eDigits?.length === 8) {
        const idFilter = {};
        if (sDigits?.length === 8) idFilter.gte = parseInt(sDigits + "00", 10);
        if (eDigits?.length === 8) idFilter.lte = parseInt(eDigits + "23", 10);
        where.id = idFilter;
      } else {
        where.openTime = {};
        if (startDate) where.openTime.gte = new Date(startDate);
        if (endDate) where.openTime.lte = new Date(endDate);
      }
    }
    if (activeOnly === "true") {
      where.status = true;
    }
    const games = await prisma.game.findMany({
      where,
      orderBy: { id: "desc" },
      take: limit ? parseInt(limit, 10) : void 0,
      include: {
        _count: {
          select: { bets: true, results: true }
        },
        results: {
          take: 1,
          orderBy: { declaredAt: "desc" }
        },
        bets: {
          select: {
            amount: true,
            selectedNumber: true,
            betType: true,
            potentialPayout: true,
            hasRedeemed: true,
            payout: {
              select: {
                winningAmount: true,
                status: true
              }
            }
          }
        }
      }
    });
    const analytics = games.map((game) => {
      let gameSales = 0;
      let gamePayoutLiability = 0;
      let winningBetsCount = 0;
      let redeemedBetsCount = 0;
      const latestResult = game.results[0]?.winningNumber;
      for (const bet of game.bets) {
        gameSales += bet.amount;
        if (bet.payout) {
          gamePayoutLiability += bet.payout.winningAmount;
          winningBetsCount++;
        } else {
          const isMatched = latestResult ? evaluateBetWinFromString(bet.selectedNumber, bet.betType, latestResult) : false;
          if (isMatched) {
            gamePayoutLiability += bet.potentialPayout;
            winningBetsCount++;
          }
        }
        if (bet.hasRedeemed) {
          redeemedBetsCount++;
        }
      }
      return {
        id: game.id,
        name: game.name,
        code: game.code,
        status: game.status,
        isLocked: game.isLocked,
        openTime: game.openTime,
        closeTime: game.closeTime,
        resultTime: game.resultTime,
        latestResult: game.results[0] ? game.results[0].winningNumber : null,
        betsCount: game.bets.length,
        totalDbBetsCount: game._count.bets,
        winningBetsCount,
        redeemedBetsCount,
        totalSales: gameSales,
        totalPayouts: gamePayoutLiability,
        netRevenue: gameSales - gamePayoutLiability
      };
    });
    analytics.sort((a, b) => {
      if (a.totalSales > 0 && b.totalSales === 0) return -1;
      if (b.totalSales > 0 && a.totalSales === 0) return 1;
      if (a.totalSales !== b.totalSales) return b.totalSales - a.totalSales;
      return b.id - a.id;
    });
    res.json({ success: true, count: analytics.length, data: analytics });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router13.post("/reset-database", async (_req, res) => {
  try {
    await prisma.$transaction(async (tx) => {
      await tx.payout.deleteMany({});
      await tx.bet.deleteMany({});
      await tx.transaction.deleteMany({});
      await tx.ticket.deleteMany({});
      await tx.result.deleteMany({});
      await tx.shiftAudit.deleteMany({});
      await tx.loginActivity.deleteMany({});
      await tx.cage.deleteMany({});
      await tx.cage.create({
        data: {
          cageCode: "CAGE-01",
          stationName: "Cage Desk #01",
          openingFloat: 1e5,
          currentBalance: 1e5,
          totalPayout: 0,
          todayPaidCount: 0,
          status: "OPEN"
        }
      });
      await tx.game.deleteMany({});
    });
    const seededGames = await ensureUpcomingHourlyGames(12);
    res.json({
      success: true,
      message: "Full Clean Slate Reset completed successfully. All test tickets, bets, transactions, payouts, results and old games have been cleared. Fresh upcoming hourly draws generated.",
      seededCount: seededGames.length
    });
  } catch (error) {
    console.error("Error during database reset:", error);
    res.status(500).json({ success: false, message: error.message });
  }
});
var admin_default = router13;

// src/server/routes/tablets.ts
import { Router as Router14 } from "express";
var router14 = Router14();
router14.get("/", async (req, res) => {
  try {
    const { search, status } = req.query;
    const where = {};
    if (status !== void 0 && status !== "") {
      where.status = status === "true" || status === "1" || status === "active";
    }
    if (search && typeof search === "string") {
      const q = search.trim();
      where.OR = [
        { tabletId: { contains: q } },
        { name: { contains: q } },
        { ipAddress: { contains: q } },
        { owner: { name: { contains: q } } },
        { owner: { badgeId: { contains: q } } }
      ];
    }
    const tablets = await prisma.tablet.findMany({
      where,
      orderBy: { updatedAt: "desc" },
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            badgeId: true,
            phone: true,
            role: true,
            status: true
          }
        }
      }
    });
    res.json({ success: true, count: tablets.length, data: tablets });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router14.get("/:tabletId", async (req, res) => {
  try {
    const query = req.params.tabletId.trim();
    const idNum = parseInt(query, 10);
    const tablet = await prisma.tablet.findFirst({
      where: {
        OR: [
          { tabletId: query },
          { tabletId: query.toUpperCase() },
          ...!isNaN(idNum) ? [{ id: idNum }] : []
        ]
      },
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            badgeId: true,
            phone: true,
            role: true,
            status: true
          }
        }
      }
    });
    if (!tablet) {
      return res.status(404).json({ success: false, message: `Tablet "${query}" not found.` });
    }
    res.json({ success: true, data: tablet });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router14.post("/verify", async (req, res) => {
  try {
    const { tabletId, name, ipAddress, employeeId } = req.body;
    const cleanId = String(tabletId || "").trim();
    if (!cleanId) {
      return res.status(400).json({ success: false, message: "tabletId is required" });
    }
    const clientIp = ipAddress || req.ip || req.socket.remoteAddress || null;
    const now = /* @__PURE__ */ new Date();
    let tablet = await prisma.tablet.findUnique({
      where: { tabletId: cleanId },
      include: {
        owner: {
          select: { id: true, name: true, badgeId: true, role: true }
        }
      }
    });
    if (!tablet) {
      tablet = await prisma.tablet.create({
        data: {
          tabletId: cleanId,
          name: name ? String(name).trim() : `Tablet (${cleanId})`,
          status: true,
          ipAddress: clientIp,
          lastUsed: now,
          ownerId: employeeId ? parseInt(employeeId, 10) : null
        },
        include: {
          owner: {
            select: { id: true, name: true, badgeId: true, role: true }
          }
        }
      });
    } else {
      const lastUsedDiffMs = tablet.lastUsed ? now.getTime() - new Date(tablet.lastUsed).getTime() : Infinity;
      if (lastUsedDiffMs > 6e4 || clientIp && tablet.ipAddress !== clientIp || employeeId && !tablet.ownerId) {
        tablet = await prisma.tablet.update({
          where: { id: tablet.id },
          data: {
            lastUsed: now,
            ...clientIp ? { ipAddress: clientIp } : {},
            ...employeeId && !tablet.ownerId ? { ownerId: parseInt(employeeId, 10) } : {}
          },
          include: {
            owner: {
              select: { id: true, name: true, badgeId: true, role: true }
            }
          }
        });
      }
    }
    if (!tablet.status) {
      return res.status(403).json({
        success: false,
        isAllowed: false,
        message: `Tablet "${tablet.tabletId}" has been disabled by Administrator. Access is blocked.`,
        data: tablet
      });
    }
    res.json({
      success: true,
      isAllowed: true,
      message: `Tablet "${tablet.tabletId}" is authorized and active.`,
      data: tablet
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router14.post("/", async (req, res) => {
  try {
    const { tabletId, name, status = true, ownerId, ipAddress } = req.body;
    const cleanId = String(tabletId || "").trim();
    if (!cleanId) {
      return res.status(400).json({ success: false, message: "tabletId is required" });
    }
    const tablet = await prisma.tablet.upsert({
      where: { tabletId: cleanId },
      create: {
        tabletId: cleanId,
        name: name ? String(name).trim() : `Tablet (${cleanId})`,
        status: status === true || status === "true",
        ownerId: ownerId ? parseInt(ownerId, 10) : null,
        ipAddress: ipAddress ? String(ipAddress).trim() : null,
        lastUsed: /* @__PURE__ */ new Date()
      },
      update: {
        name: name !== void 0 ? name ? String(name).trim() : null : void 0,
        status: status !== void 0 ? status === true || status === "true" : void 0,
        ownerId: ownerId !== void 0 ? ownerId ? parseInt(ownerId, 10) : null : void 0,
        ipAddress: ipAddress ? String(ipAddress).trim() : void 0
      },
      include: {
        owner: {
          select: { id: true, name: true, badgeId: true, role: true }
        }
      }
    });
    res.json({ success: true, message: `Tablet "${tablet.tabletId}" saved successfully.`, data: tablet });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router14.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid tablet ID" });
    }
    const { tabletId, name, status, ownerId, ipAddress } = req.body;
    const updateData = {};
    if (tabletId) updateData.tabletId = String(tabletId).trim();
    if (name !== void 0) updateData.name = name ? String(name).trim() : null;
    if (status !== void 0) updateData.status = status === true || status === "true";
    if (ownerId !== void 0) updateData.ownerId = ownerId ? parseInt(ownerId, 10) : null;
    if (ipAddress !== void 0) updateData.ipAddress = ipAddress ? String(ipAddress).trim() : null;
    const tablet = await prisma.tablet.update({
      where: { id },
      data: updateData,
      include: {
        owner: {
          select: { id: true, name: true, badgeId: true, role: true }
        }
      }
    });
    res.json({ success: true, message: `Tablet "${tablet.tabletId}" updated.`, data: tablet });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router14.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid tablet ID" });
    }
    await prisma.tablet.delete({ where: { id } });
    res.json({ success: true, message: "Tablet removed successfully." });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var tablets_default = router14;

// src/server/routes/telemetry.ts
import express from "express";

// src/server/logger.ts
import winston from "winston";
import DailyRotateFile from "winston-daily-rotate-file";
import path from "path";
import fs from "fs";
var LOGS_DIR = path.resolve(process.cwd(), "logs");
if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
}
var istFormatter = new Intl.DateTimeFormat("en-IN", {
  timeZone: "Asia/Kolkata",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hour12: false
});
var istTimestamp = () => istFormatter.format(/* @__PURE__ */ new Date());
var fileFormat = winston.format.combine(
  winston.format.timestamp({ format: istTimestamp }),
  winston.format.errors({ stack: true }),
  winston.format.printf(({ timestamp, level, message, stack, ...meta }) => {
    const metaString = Object.keys(meta).length ? ` | ${JSON.stringify(meta)}` : "";
    const stackString = stack ? `
Stack: ${stack}` : "";
    return `[${timestamp} IST] [${level.toUpperCase()}]: ${message}${metaString}${stackString}`;
  })
);
var consoleFormat = winston.format.combine(
  winston.format.colorize(),
  winston.format.timestamp({ format: istTimestamp }),
  winston.format.printf(({ timestamp, level, message, stack }) => {
    const stackString = stack ? `
${stack}` : "";
    return `[${timestamp}] ${level}: ${message}${stackString}`;
  })
);
var combinedRotateTransport = new DailyRotateFile({
  filename: path.join(LOGS_DIR, "combined-%DATE%.log"),
  datePattern: "YYYY-MM-DD",
  zippedArchive: true,
  maxSize: "50m",
  maxFiles: "30d",
  format: fileFormat
});
var errorRotateTransport = new DailyRotateFile({
  filename: path.join(LOGS_DIR, "error-%DATE%.log"),
  datePattern: "YYYY-MM-DD",
  level: "error",
  zippedArchive: true,
  maxSize: "50m",
  maxFiles: "60d",
  format: fileFormat
});
var downtimeRotateTransport = new DailyRotateFile({
  filename: path.join(LOGS_DIR, "downtime-%DATE%.log"),
  datePattern: "YYYY-MM-DD",
  zippedArchive: true,
  maxSize: "20m",
  maxFiles: "90d",
  format: fileFormat
});
var downtimeLogger = winston.createLogger({
  level: "info",
  format: fileFormat,
  transports: [
    downtimeRotateTransport,
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.timestamp({ format: istTimestamp }),
        winston.format.printf(({ timestamp, level, message }) => `[${timestamp}] ${level} [DOWNTIME]: ${message}`)
      )
    })
  ]
});
var logger = winston.createLogger({
  level: process.env.LOG_LEVEL || "info",
  transports: [
    combinedRotateTransport,
    errorRotateTransport,
    new winston.transports.Console({
      format: consoleFormat
    })
  ],
  exitOnError: false
});
function logDowntimeIncident(incident) {
  const startStr = typeof incident.startedAt === "string" ? incident.startedAt : incident.startedAt.toISOString();
  const endStr = typeof incident.endedAt === "string" ? incident.endedAt : incident.endedAt.toISOString();
  const mins = (incident.durationSeconds / 60).toFixed(1);
  const summary = `[OUTAGE_RESOLVED] Source: ${incident.source} | Device: ${incident.deviceId || "N/A"} | Operator: ${incident.employeeId || "N/A"} | Downtime: ${incident.durationSeconds}s (${mins}m) | Interval: [${startStr} -> ${endStr}] | Reason: ${incident.reason || "Network/Server connection lost"} | Failed Attempts: ${incident.failedRequests || 0}`;
  downtimeLogger.warn(summary, {
    ...incident,
    event: "DOWNTIME_INCIDENT"
  });
  logger.warn(summary);
}

// src/server/routes/telemetry.ts
import path2 from "path";
import fs2 from "fs";
var router15 = express.Router();
var LOGS_DIR2 = path2.resolve(process.cwd(), "logs");
router15.post("/downtime", async (req, res) => {
  try {
    const {
      source = "CLIENT",
      deviceId,
      employeeId,
      serviceUrl,
      startedAt,
      endedAt,
      durationSeconds,
      reason,
      failedRequests = 0,
      details
    } = req.body;
    if (!startedAt || !endedAt || durationSeconds === void 0) {
      return res.status(400).json({
        success: false,
        message: "startedAt, endedAt, and durationSeconds are required"
      });
    }
    const start = new Date(startedAt);
    const end = new Date(endedAt);
    const durSec = Math.max(1, parseInt(durationSeconds) || Math.round((end.getTime() - start.getTime()) / 1e3));
    const empId = employeeId ? parseInt(String(employeeId)) : null;
    const incident = await prisma.downtimeIncident.create({
      data: {
        source,
        deviceId: deviceId ? String(deviceId) : null,
        employeeId: isNaN(empId) ? null : empId,
        serviceUrl: serviceUrl || null,
        startedAt: start,
        endedAt: end,
        durationSeconds: durSec,
        reason: reason || "Connection to server lost / timed out",
        failedRequests: parseInt(failedRequests) || 0,
        details: typeof details === "object" ? JSON.stringify(details) : details || null
      }
    });
    logDowntimeIncident({
      source,
      deviceId: deviceId || void 0,
      employeeId: empId || void 0,
      serviceUrl,
      startedAt: start,
      endedAt: end,
      durationSeconds: durSec,
      reason,
      failedRequests: parseInt(failedRequests) || 0,
      details: typeof details === "string" ? details : void 0
    });
    res.status(201).json({
      success: true,
      message: `Downtime incident of ${durSec} seconds logged successfully`,
      data: incident
    });
  } catch (error) {
    logger.error("Failed to record downtime incident:", error);
    res.status(500).json({ success: false, message: error.message });
  }
});
router15.get("/downtime", async (req, res) => {
  try {
    const { source, deviceId, limit = "50", offset = "0", startDate, endDate } = req.query;
    const where = {};
    if (source) where.source = String(source);
    if (deviceId) where.deviceId = String(deviceId);
    if (startDate || endDate) {
      where.startedAt = {};
      if (startDate) where.startedAt.gte = new Date(String(startDate));
      if (endDate) where.startedAt.lte = new Date(String(endDate));
    }
    const [total, incidents] = await Promise.all([
      prisma.downtimeIncident.count({ where }),
      prisma.downtimeIncident.findMany({
        where,
        orderBy: { startedAt: "desc" },
        take: parseInt(limit),
        skip: parseInt(offset)
      })
    ]);
    res.json({
      success: true,
      total,
      count: incidents.length,
      data: incidents
    });
  } catch (error) {
    logger.error("Failed to fetch downtime incidents:", error);
    res.status(500).json({ success: false, message: error.message });
  }
});
router15.get("/logs", (_req, res) => {
  try {
    if (!fs2.existsSync(LOGS_DIR2)) {
      return res.json({ success: true, count: 0, files: [] });
    }
    const files = fs2.readdirSync(LOGS_DIR2).filter((f) => f.endsWith(".log") || f.endsWith(".gz")).map((name) => {
      const fullPath = path2.join(LOGS_DIR2, name);
      const stat = fs2.statSync(fullPath);
      return {
        filename: name,
        sizeBytes: stat.size,
        sizeFormatted: `${(stat.size / 1024).toFixed(1)} KB`,
        lastModified: stat.mtime.toISOString(),
        type: name.startsWith("error") ? "ERROR" : name.startsWith("downtime") ? "DOWNTIME" : "COMBINED"
      };
    }).sort((a, b) => b.lastModified.localeCompare(a.lastModified));
    res.json({
      success: true,
      count: files.length,
      files
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router15.get("/logs/:filename", (req, res) => {
  try {
    const rawFilename = path2.basename(req.params.filename);
    if (!rawFilename.endsWith(".log")) {
      return res.status(400).json({ success: false, message: "Only .log files can be read directly" });
    }
    const filePath = path2.join(LOGS_DIR2, rawFilename);
    if (!fs2.existsSync(filePath)) {
      return res.status(404).json({ success: false, message: "Log file not found" });
    }
    const maxLines = parseInt(req.query.lines) || 200;
    const content = fs2.readFileSync(filePath, "utf-8");
    const lines = content.split("\n");
    const recent = lines.slice(-maxLines).join("\n");
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.send(recent);
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var telemetry_default = router15;

// src/server/index.ts
import path3 from "path";
import fs3 from "fs";
dotenv.config();
var app = express2();
var PORT = process.env.PORT || 5001;
app.use(cors({
  origin: "*",
  // Allow connections from frontend dev server, mobile app and external clients
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["*"],
  exposedHeaders: ["*"]
}));
app.use(express2.json());
app.use((req, res, next) => {
  const start = Date.now();
  const clientIp = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "";
  const tabletId = req.headers["x-tablet-id"] || "";
  res.on("finish", () => {
    const isRoutinePoll = req.path === "/api/health" || req.path === "/health" || req.method === "GET" && (req.path === "/api/terminal-config" || req.path === "/api/payout-rules" || req.path === "/api/games" || req.path === "/api/tablets" || req.path === "/api/admin/metrics" || req.path === "/api/admin/game-analytics" || req.path.startsWith("/api/shift-audits/current"));
    if (isRoutinePoll && res.statusCode < 400) {
      return;
    }
    const durationMs = Date.now() - start;
    const cleanIp = clientIp.split(",")[0].trim() || "internal";
    const tabletInfo = tabletId ? ` | Tablet: ${tabletId}` : "";
    const logLine = `${req.method} ${req.originalUrl || req.url} ${res.statusCode} (${durationMs}ms) [IP: ${cleanIp}${tabletInfo}]`;
    if (res.statusCode >= 500) {
      logger.error(logLine);
    } else if (res.statusCode >= 400) {
      logger.warn(logLine);
    } else {
      logger.info(logLine);
    }
  });
  next();
});
app.use("/api", (_req, res, next) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  next();
});
var healthHandler = (_req, res) => {
  res.json({
    status: "UP",
    service: "GameXpro Lottery Management API Server",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
};
app.get("/api/health", healthHandler);
app.get("/health", healthHandler);
app.get(["/download/apk", "/api/download/apk"], (_req, res) => {
  const possiblePaths = [
    path3.resolve(process.cwd(), "android/app/build/outputs/apk/debug/GameXpro-Lottery.apk"),
    path3.resolve(process.cwd(), "android/app/build/outputs/apk/debug/GameXpro-Lottery-debug.apk"),
    path3.resolve(process.cwd(), "android/app/build/outputs/apk/debug/app-debug.apk")
  ];
  const apkPath = possiblePaths.find((p) => fs3.existsSync(p));
  if (apkPath) {
    const stat = fs3.statSync(apkPath);
    res.setHeader("Content-Type", "application/vnd.android.package-archive");
    res.setHeader("Content-Disposition", 'attachment; filename="GameXpro-Lottery.apk"');
    res.setHeader("Content-Length", stat.size);
    return res.sendFile(apkPath);
  }
  return res.status(404).json({
    success: false,
    message: "APK build not found. Please run npm run android:build first to compile the APK."
  });
});
app.get(["/download/info", "/api/download/info"], (_req, res) => {
  const possiblePaths = [
    path3.resolve(process.cwd(), "android/app/build/outputs/apk/debug/GameXpro-Lottery.apk"),
    path3.resolve(process.cwd(), "android/app/build/outputs/apk/debug/GameXpro-Lottery-debug.apk"),
    path3.resolve(process.cwd(), "android/app/build/outputs/apk/debug/app-debug.apk")
  ];
  const apkPath = possiblePaths.find((p) => fs3.existsSync(p));
  if (apkPath) {
    const stat = fs3.statSync(apkPath);
    return res.json({
      success: true,
      filename: path3.basename(apkPath),
      sizeBytes: stat.size,
      sizeFormatted: `${(stat.size / (1024 * 1024)).toFixed(2)} MB`,
      lastModified: stat.mtime.toISOString(),
      downloadUrl: "/download/apk"
    });
  }
  return res.status(404).json({ success: false, message: "No APK built yet." });
});
app.use("/api/employees", employees_default);
app.use("/api/games", games_default);
app.use("/api/tickets", tickets_default);
app.use("/api/bets", bets_default);
app.use("/api/results", results_default);
app.use("/api/payouts", payouts_default);
app.use("/api/transactions", transactions_default);
app.use("/api/payout-rules", payoutRules_default);
app.use("/api/terminal-config", terminalConfig_default);
app.use("/api/shift-audits", shiftAudits_default);
app.use("/api/login-activities", loginActivities_default);
app.use("/api/cage", cage_default);
app.use("/api/admin", admin_default);
app.use("/api/tablets", tablets_default);
app.use("/api/telemetry", telemetry_default);
var distPath = path3.resolve(process.cwd(), "dist");
if (fs3.existsSync(distPath)) {
  app.use(express2.static(distPath));
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api") || req.path.startsWith("/download") || req.path.startsWith("/health")) {
      return next();
    }
    const indexPath = path3.join(distPath, "index.html");
    if (fs3.existsSync(indexPath)) {
      return res.sendFile(indexPath);
    }
    next();
  });
}
app.use((err, _req, res, _next) => {
  logger.error("Unhandled Server Error:", err);
  res.status(500).json({
    success: false,
    message: err.message || "Internal Server Error"
  });
});
var HEARTBEAT_FILE = path3.resolve(process.cwd(), "logs/.server-heartbeat.json");
function checkPreviousServerDowntime() {
  try {
    if (fs3.existsSync(HEARTBEAT_FILE)) {
      const raw = fs3.readFileSync(HEARTBEAT_FILE, "utf-8");
      const prev = JSON.parse(raw);
      if (prev && prev.lastHeartbeat) {
        const lastHb = new Date(prev.lastHeartbeat).getTime();
        const now = Date.now();
        const downtimeSec = Math.round((now - lastHb) / 1e3);
        if (downtimeSec > 30) {
          const reason = prev.status === "SHUTDOWN" ? "Graceful server restart or maintenance" : "Unplanned server outage / crash / power loss";
          logDowntimeIncident({
            source: "SERVER",
            startedAt: new Date(lastHb),
            endedAt: new Date(now),
            durationSeconds: downtimeSec,
            reason,
            details: `Previous status was "${prev.status || "UNKNOWN"}" recorded at ${prev.lastHeartbeat}`
          });
          prisma.downtimeIncident.create({
            data: {
              source: "SERVER",
              startedAt: new Date(lastHb),
              endedAt: new Date(now),
              durationSeconds: downtimeSec,
              reason,
              details: `Previous status was "${prev.status || "UNKNOWN"}" recorded at ${prev.lastHeartbeat}`
            }
          }).catch((e) => logger.warn("Could not save server downtime incident to db:", e));
        }
      }
    }
  } catch (err) {
    logger.warn("Error verifying previous server downtime heartbeat:", err);
  }
}
function updateHeartbeat(status) {
  try {
    const data = {
      status,
      lastHeartbeat: (/* @__PURE__ */ new Date()).toISOString(),
      pid: process.pid
    };
    fs3.promises.writeFile(HEARTBEAT_FILE, JSON.stringify(data, null, 2), "utf-8").catch(() => {
    });
  } catch {
  }
}
app.listen(PORT, () => {
  logger.info(`\u{1F680} GameXpro Lottery API Server is running on http://localhost:${PORT}`);
  logger.info(`\u{1F4E1} Daily auto-rotated logs are active in ./logs/ directory`);
  checkPreviousServerDowntime();
  updateHeartbeat("RUNNING");
  setInterval(() => updateHeartbeat("RUNNING"), 5e3);
  ensureUpcomingHourlyGames(12).catch((err) => logger.warn("Initial draw generation error:", err));
  setInterval(() => {
    ensureUpcomingHourlyGames(12).catch((err) => logger.warn("Background draw generation error:", err));
  }, 60 * 1e3);
});
var handleShutdown = (signal) => {
  logger.warn(`Received ${signal}. Marking server shutdown in heartbeat...`);
  updateHeartbeat("SHUTDOWN");
  process.exit(0);
};
process.on("SIGINT", () => handleShutdown("SIGINT"));
process.on("SIGTERM", () => handleShutdown("SIGTERM"));
var index_default = app;
export {
  index_default as default
};
