// src/server/index.ts
import express from "express";
import cors from "cors";
import dotenv from "dotenv";

// src/server/routes/employees.ts
import { Router } from "express";

// src/server/db.ts
import { PrismaClient } from "@prisma/client";

// src/utils/istGameId.ts
function getISTDateTime(date = /* @__PURE__ */ new Date()) {
  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });
  const parts = formatter.formatToParts(date);
  const partMap = {};
  for (const part of parts) {
    partMap[part.type] = part.value;
  }
  const year = parseInt(partMap.year, 10);
  const month = parseInt(partMap.month, 10);
  const day = parseInt(partMap.day, 10);
  let hour = parseInt(partMap.hour, 10);
  if (hour === 24) hour = 0;
  const minute = parseInt(partMap.minute, 10);
  const second = parseInt(partMap.second, 10);
  const YYYY = String(year).padStart(4, "0");
  const MM = String(month).padStart(2, "0");
  const DD = String(day).padStart(2, "0");
  const HH = String(hour).padStart(2, "0");
  const gameIdStr = `${YYYY}${MM}${DD}${HH}`;
  const gameIdNum = parseInt(gameIdStr, 10);
  return {
    year,
    month,
    day,
    hour,
    minute,
    second,
    gameIdStr,
    gameIdNum
  };
}
function getCurrentISTGameId(date = /* @__PURE__ */ new Date()) {
  return getISTDateTime(date).gameIdNum;
}
function getISTDateString(date = /* @__PURE__ */ new Date()) {
  const ist = getISTDateTime(date);
  const yy = String(ist.year).slice(-2);
  const mm = String(ist.month).padStart(2, "0");
  const dd = String(ist.day).padStart(2, "0");
  return `${yy}${mm}${dd}`;
}
function generateISTTicketId(date = /* @__PURE__ */ new Date(), terminalId) {
  const dateStr = getISTDateString(date);
  let termPrefix = "";
  if (terminalId) {
    const cleanTerm = terminalId.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
    if (cleanTerm.length > 0) {
      const suffix = cleanTerm.slice(-2);
      termPrefix = `T${suffix}-`;
    }
  }
  const randNum = Math.floor(1e5 + Math.random() * 9e5);
  return `TK-${dateStr}-${termPrefix}${randNum}`;
}
function getISTDayRange(date = /* @__PURE__ */ new Date()) {
  const ist = getISTDateTime(date);
  const start = new Date(Date.UTC(ist.year, ist.month - 1, ist.day, 0, 0, 0, 0));
  const end = new Date(Date.UTC(ist.year, ist.month - 1, ist.day, 23, 59, 59, 999));
  const mm = String(ist.month).padStart(2, "0");
  const dd = String(ist.day).padStart(2, "0");
  const dateStr = `${ist.year}-${mm}-${dd}`;
  const datePrefix = `${ist.year}${mm}${dd}`;
  return { start, end, dateStr, datePrefix };
}
function getNowIST() {
  const now = /* @__PURE__ */ new Date();
  return new Date(now.getTime() + 5.5 * 3600 * 1e3);
}
function getISTHourlyWindow(date = /* @__PURE__ */ new Date()) {
  const ist = getISTDateTime(date);
  const secondsElapsedInHour = ist.minute * 60 + ist.second;
  const cutoffSecondsLeft = Math.max(0, 3600 - secondsElapsedInHour);
  const nextHour = (ist.hour + 1) % 24;
  const cutoffFormatted = `${String(nextHour).padStart(2, "0")}:00 IST`;
  return {
    gameId: ist.gameIdNum,
    gameIdStr: ist.gameIdStr,
    currentHour: ist.hour,
    nextHour,
    cutoffFormatted,
    cutoffSecondsLeft
  };
}

// src/server/db.ts
var globalForPrisma = global;
var basePrisma = globalForPrisma.basePrisma || new PrismaClient({
  log: process.env.NODE_ENV === "development" ? ["query", "error", "warn"] : ["error"]
});
var MODELS_WITH_CREATED_AT = /* @__PURE__ */ new Set([
  "Employee",
  "Ticket",
  "Bet",
  "Game",
  "Transaction",
  "Payout",
  "Cage"
]);
var prisma = globalForPrisma.prisma || basePrisma.$extends({
  query: {
    $allModels: {
      async create({ model, args, query }) {
        args.data = args.data || {};
        const nowIST = getNowIST();
        if (MODELS_WITH_CREATED_AT.has(model) && !args.data.createdAt) {
          args.data.createdAt = nowIST;
        }
        if (model === "Result" && !args.data.declaredAt) {
          args.data.declaredAt = nowIST;
        }
        if (model === "ShiftAudit" && !args.data.openedAt) {
          args.data.openedAt = nowIST;
        }
        if (model === "Cage" && !args.data.openedAt) {
          args.data.openedAt = nowIST;
        }
        if (model === "LoginActivity" && !args.data.loginTime) {
          args.data.loginTime = nowIST;
        }
        return query(args);
      },
      async update({ args, query }) {
        args.data = args.data || {};
        if ("updatedAt" in args.data) {
          args.data.updatedAt = getNowIST();
        }
        return query(args);
      }
    }
  }
});
if (process.env.NODE_ENV !== "production") {
  globalForPrisma.basePrisma = basePrisma;
  globalForPrisma.prisma = prisma;
}

// src/server/routes/employees.ts
import { Role } from "@prisma/client";

// src/utils/rfidCrypto.ts
var DEFAULT_SECRET = "GXPRO_LOTTERY_SECURE_RFID_KEY_v2026";
function getSecretKey() {
  if (typeof process !== "undefined" && process.env?.RFID_SECRET_KEY) {
    return process.env.RFID_SECRET_KEY;
  }
  return DEFAULT_SECRET;
}
function stringToBytes(str) {
  const bytes = new Uint8Array(str.length);
  for (let i = 0; i < str.length; i++) {
    bytes[i] = str.charCodeAt(i) & 255;
  }
  return bytes;
}
function base64UrlToBytes(base64url) {
  let base64 = base64url.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4) {
    base64 += "=";
  }
  const binary = typeof atob === "function" ? atob(base64) : Buffer.from(base64, "base64").toString("binary");
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}
function deriveKeyStream(secret, salt, length) {
  const stream = new Uint8Array(length);
  const secretBytes = stringToBytes(secret);
  let h = 2166136261;
  for (let i = 0; i < salt.length; i++) {
    h ^= salt[i];
    h = Math.imul(h, 16777619);
  }
  for (let i = 0; i < length; i++) {
    const secByte = secretBytes[(i + salt[i % salt.length]) % secretBytes.length];
    h ^= secByte ^ i * 31;
    h = Math.imul(h, 16777619);
    stream[i] = h >>> 8 * (i % 4) & 255;
  }
  return stream;
}
function decodeRfidToken(token, maxAgeMs = 5 * 60 * 1e3) {
  if (!token || typeof token !== "string") {
    throw new Error("Invalid token");
  }
  if (!token.startsWith("rfid_v1_")) {
    return token.trim();
  }
  const rawPayload = token.substring("rfid_v1_".length);
  const combined = base64UrlToBytes(rawPayload);
  if (combined.length <= 8) {
    throw new Error("Corrupt or truncated RFID token");
  }
  const salt = combined.slice(0, 8);
  const encrypted = combined.slice(8);
  const keyStream = deriveKeyStream(getSecretKey(), salt, encrypted.length);
  const decryptedBytes = new Uint8Array(encrypted.length);
  let prev = salt[0];
  for (let i = 0; i < encrypted.length; i++) {
    const enc = encrypted[i];
    decryptedBytes[i] = enc ^ keyStream[i] ^ prev;
    prev = enc;
  }
  const payloadStr = new TextDecoder().decode(decryptedBytes);
  const parsed = JSON.parse(payloadStr);
  if (!parsed || !parsed.rfid) {
    throw new Error("Invalid RFID payload structure");
  }
  if (parsed.ts && maxAgeMs > 0) {
    const age = Math.abs(Date.now() - parsed.ts);
    if (age > maxAgeMs) {
      throw new Error("Expired RFID authentication token. Please rescan badge.");
    }
  }
  return parsed.rfid.trim();
}

// src/server/routes/employees.ts
var router = Router();
router.get("/", async (req, res) => {
  try {
    const { role, status, search } = req.query;
    const where = {};
    if (role && Object.values(Role).includes(role)) {
      where.role = role;
    }
    if (status !== void 0) {
      where.status = status === "true";
    }
    if (search && typeof search === "string") {
      where.OR = [
        { name: { contains: search } },
        { phone: { contains: search } },
        { badgeId: { contains: search } },
        { rfid: { contains: search } }
      ];
    }
    const employees = await prisma.employee.findMany({
      where,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        name: true,
        badgeId: true,
        rfid: true,
        phone: true,
        role: true,
        status: true,
        createdAt: true,
        updatedAt: true,
        _count: {
          select: {
            tickets: true,
            payouts: true,
            shiftAudits: true
          }
        }
      }
    });
    res.json({ success: true, count: employees.length, data: employees });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid employee ID" });
    }
    const employee = await prisma.employee.findUnique({
      where: { id },
      include: {
        tickets: {
          take: 10,
          orderBy: { createdAt: "desc" },
          include: { bets: true }
        },
        payouts: {
          take: 10,
          orderBy: { paidAt: "desc" }
        },
        shiftAudits: {
          take: 5,
          orderBy: { openedAt: "desc" }
        }
      }
    });
    if (!employee) {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router.post("/", async (req, res) => {
  try {
    const { name, phone, role, badgeId, rfid, pin, status } = req.body;
    if (!name || !role) {
      return res.status(400).json({ success: false, message: "Name and role are required" });
    }
    if (!rfid || !String(rfid).trim()) {
      return res.status(400).json({ success: false, message: "RFID number is mandatory for all staff members" });
    }
    if (!Object.values(Role).includes(role)) {
      return res.status(400).json({
        success: false,
        message: `Invalid role. Allowed: ${Object.values(Role).join(", ")}`
      });
    }
    const cleanRfid = String(rfid).trim();
    const existingRfid = await prisma.employee.findUnique({
      where: { rfid: cleanRfid }
    });
    if (existingRfid) {
      return res.status(409).json({
        success: false,
        message: `RFID "${cleanRfid}" is already assigned to ${existingRfid.name} (${existingRfid.role})`
      });
    }
    const employee = await prisma.employee.create({
      data: {
        name: String(name).trim(),
        phone: phone ? String(phone).trim() : null,
        role,
        badgeId: badgeId ? String(badgeId).trim() : null,
        rfid: cleanRfid,
        pin: pin ? String(pin).trim() : null,
        status: status !== void 0 ? Boolean(status) : true
      }
    });
    res.status(201).json({ success: true, message: "Employee created successfully", data: employee });
  } catch (error) {
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Phone, Badge ID, or RFID already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid employee ID" });
    }
    const { name, phone, role, badgeId, rfid, pin, status } = req.body;
    if (rfid !== void 0 && (!rfid || !String(rfid).trim())) {
      return res.status(400).json({ success: false, message: "RFID number is mandatory and cannot be empty" });
    }
    const cleanRfid = rfid !== void 0 ? String(rfid).trim() : void 0;
    if (cleanRfid) {
      const existingRfid = await prisma.employee.findFirst({
        where: { rfid: cleanRfid, NOT: { id } }
      });
      if (existingRfid) {
        return res.status(409).json({
          success: false,
          message: `RFID "${cleanRfid}" is already assigned to ${existingRfid.name} (${existingRfid.role})`
        });
      }
    }
    const employee = await prisma.employee.update({
      where: { id },
      data: {
        name,
        phone: phone || null,
        role,
        badgeId: badgeId || null,
        rfid: cleanRfid,
        pin: pin || null,
        status: Boolean(status)
      }
    });
    res.json({ success: true, message: "Employee updated successfully", data: employee });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Phone, Badge ID, or RFID already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid employee ID" });
    }
    const dataToUpdate = { ...req.body };
    if (dataToUpdate.rfid !== void 0) {
      const cleanRfid = String(dataToUpdate.rfid).trim();
      if (!cleanRfid) {
        return res.status(400).json({ success: false, message: "RFID number is mandatory and cannot be empty" });
      }
      const existingRfid = await prisma.employee.findFirst({
        where: { rfid: cleanRfid, NOT: { id } }
      });
      if (existingRfid) {
        return res.status(409).json({
          success: false,
          message: `RFID "${cleanRfid}" is already assigned to ${existingRfid.name} (${existingRfid.role})`
        });
      }
      dataToUpdate.rfid = cleanRfid;
    }
    const employee = await prisma.employee.update({
      where: { id },
      data: dataToUpdate
    });
    res.json({ success: true, message: "Employee patched successfully", data: employee });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Phone, Badge ID, or RFID already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid employee ID" });
    }
    await prisma.employee.delete({
      where: { id }
    });
    res.json({ success: true, message: "Employee deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router.post("/auth", async (req, res) => {
  try {
    const { encodedRfid, rfid, badgeId, pin, phone, deviceInfo, ipAddress } = req.body;
    let employee = null;
    if (encodedRfid || rfid) {
      const rawToken = encodedRfid || rfid;
      let decodedTag;
      try {
        decodedTag = decodeRfidToken(rawToken);
      } catch (decodeErr) {
        return res.status(400).json({ success: false, message: `RFID decode error: ${decodeErr.message}` });
      }
      const cleanUpper = decodedTag.toUpperCase();
      const stripped = decodedTag.replace(/[:-]/g, "").toUpperCase();
      employee = await prisma.employee.findFirst({
        where: {
          OR: [
            { rfid: decodedTag },
            { rfid: cleanUpper },
            { rfid: stripped },
            { badgeId: decodedTag },
            { badgeId: cleanUpper }
          ],
          status: true
        }
      });
    } else if (badgeId) {
      employee = await prisma.employee.findFirst({
        where: { badgeId, status: true }
      });
    } else if (phone && pin) {
      employee = await prisma.employee.findFirst({
        where: { phone, pin, status: true }
      });
    }
    if (!employee) {
      return res.status(401).json({ success: false, message: "Invalid RFID badge credentials or inactive account" });
    }
    const isAndroidDevice = req.body.isAndroid === true || req.body.platform === "android" || /Android/i.test(req.headers["user-agent"] || "") || typeof deviceInfo === "string" && /Android/i.test(deviceInfo);
    if (isAndroidDevice && employee.role === "CAGE_OPERATOR") {
      return res.status(403).json({
        success: false,
        message: "ACCESS DENIED: Cage Operator accounts are not permitted to log in on Android application."
      });
    }
    await prisma.loginActivity.create({
      data: {
        employeeId: employee.id,
        deviceInfo: deviceInfo || "Terminal Station Client (RFID Reader)",
        ipAddress: ipAddress || req.ip
      }
    });
    res.json({
      success: true,
      message: `Authenticated as ${employee.name} (${employee.role})`,
      data: {
        id: employee.id,
        name: employee.name,
        badgeId: employee.badgeId,
        rfid: employee.rfid,
        phone: employee.phone,
        role: employee.role
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var employees_default = router;

// src/server/routes/games.ts
import { Router as Router2 } from "express";

// src/server/services/thirdPartyDrawService.ts
import crypto2 from "crypto";
import { PayoutStatus } from "@prisma/client";
async function ensureHourlyGameExists(targetGameId, tx = prisma) {
  const currentIstId = targetGameId || getCurrentISTGameId();
  let game = await tx.game.findUnique({
    where: { id: currentIstId },
    include: {
      results: {
        take: 1,
        orderBy: { declaredAt: "desc" }
      },
      _count: {
        select: { bets: true, results: true }
      }
    }
  });
  if (!game) {
    const idStr = String(currentIstId);
    let name = `Hourly Draw #${idStr}`;
    let openTime = /* @__PURE__ */ new Date();
    let closeTime = new Date(openTime.getTime() + 36e5);
    let resultTime = closeTime;
    if (idStr.length === 10) {
      const year = parseInt(idStr.substring(0, 4), 10);
      const month = parseInt(idStr.substring(4, 6), 10);
      const day = parseInt(idStr.substring(6, 8), 10);
      const hour = parseInt(idStr.substring(8, 10), 10);
      openTime = new Date(Date.UTC(year, month - 1, day, hour, 0, 0, 0));
      closeTime = new Date(Date.UTC(year, month - 1, day, hour + 1, 0, 0, 0));
      resultTime = closeTime;
      name = `Hourly Draw (${String(hour).padStart(2, "0")}:00 IST)`;
    }
    game = await tx.game.create({
      data: {
        id: currentIstId,
        name,
        code: idStr,
        openTime,
        closeTime,
        resultTime,
        baseMultiplier: 70,
        status: true,
        isLocked: false
      },
      include: {
        results: {
          take: 1,
          orderBy: { declaredAt: "desc" }
        },
        _count: {
          select: { bets: true, results: true }
        }
      }
    });
  }
  return game;
}
function generatePana() {
  const d1 = Math.floor(Math.random() * 10);
  const d2 = Math.floor(Math.random() * 10);
  const d3 = Math.floor(Math.random() * 10);
  const sorted = [d1, d2, d3].sort((a, b) => {
    const valA = a === 0 ? 10 : a;
    const valB = b === 0 ? 10 : b;
    return valA - valB;
  });
  const pana = `${sorted[0]}${sorted[1]}${sorted[2]}`;
  const sum = (d1 + d2 + d3) % 10;
  return { pana, digit: String(sum) };
}
async function simulateThirdPartyDraw(options) {
  const {
    gameId,
    gameCode = "LOTTO",
    forceOutcome,
    provider = "MOCK_THIRD_PARTY_RNG_GATEWAY",
    simulateLatencyMs = 350
  } = options;
  if (simulateLatencyMs > 0) {
    await new Promise((resolve) => setTimeout(resolve, Math.min(simulateLatencyMs, 2e3)));
  }
  const now = /* @__PURE__ */ new Date();
  const externalDrawId = `EXT-DRAW-${gameId}-${Date.now().toString(36).toUpperCase()}-${Math.floor(1e3 + Math.random() * 9e3)}`;
  const randomEntropy = crypto2.randomBytes(32).toString("hex");
  const seedHash = crypto2.createHash("sha256").update(`${externalDrawId}:${gameCode}:${randomEntropy}:${now.toISOString()}`).digest("hex");
  let openLine;
  let openDigit;
  let closeLine;
  let closeDigit;
  let pair;
  let fullDraw;
  let winningNumber;
  if (forceOutcome && forceOutcome.trim()) {
    const raw = forceOutcome.trim();
    if (raw.includes("-")) {
      const parts = raw.split("-");
      if (parts.length === 3) {
        openLine = parts[0];
        pair = parts[1];
        closeLine = parts[2];
        openDigit = pair.length >= 1 ? pair[0] : "0";
        closeDigit = pair.length >= 2 ? pair[1] : "0";
      } else if (parts.length === 2) {
        if (parts[1].length === 1) {
          openLine = parts[0];
          closeDigit = parts[1];
          const sum = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
          openDigit = String(sum);
          pair = `${openDigit}${closeDigit}`;
          closeLine = "123";
        } else {
          openLine = parts[0];
          closeLine = parts[1];
          const s1 = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
          const s2 = closeLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
          openDigit = String(s1);
          closeDigit = String(s2);
          pair = `${openDigit}${closeDigit}`;
        }
      } else {
        openLine = "248";
        openDigit = "4";
        closeLine = "369";
        closeDigit = "8";
        pair = "48";
      }
      fullDraw = raw;
      winningNumber = raw;
    } else if (raw.length === 1) {
      openDigit = raw;
      closeDigit = raw;
      pair = `${raw}${raw}`;
      openLine = "124";
      closeLine = "248";
      fullDraw = raw;
      winningNumber = raw;
    } else if (raw.length === 2) {
      openDigit = raw[0];
      closeDigit = raw[1];
      pair = raw;
      openLine = "123";
      closeLine = "456";
      fullDraw = raw;
      winningNumber = raw;
    } else if (raw.length === 3) {
      openLine = raw;
      const sum = raw.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
      openDigit = String(sum);
      closeDigit = "0";
      closeLine = "123";
      pair = `${openDigit}${closeDigit}`;
      fullDraw = raw;
      winningNumber = raw;
    } else {
      openLine = "248";
      openDigit = "4";
      closeLine = "369";
      closeDigit = "8";
      pair = "48";
      fullDraw = raw;
      winningNumber = raw;
    }
  } else {
    const openRes = generatePana();
    const closeRes = generatePana();
    openLine = openRes.pana;
    openDigit = openRes.digit;
    closeLine = closeRes.pana;
    closeDigit = closeRes.digit;
    pair = `${openDigit}${closeDigit}`;
    fullDraw = `${openLine}-${pair}-${closeLine}`;
    winningNumber = fullDraw;
  }
  return {
    externalDrawId,
    provider,
    timestamp: now.toISOString(),
    seedHash,
    winningNumber,
    openLine,
    openDigit,
    closeLine,
    closeDigit,
    pair,
    fullDraw,
    status: "SUCCESS",
    simulated: true,
    note: "Temporary simulated outcome. Will be replaced by actual third-party endpoint once integrated."
  };
}
function computeFullWinningNumberFrom6Digits(input) {
  const digits = String(input || "").replace(/\D/g, "");
  if (digits.length !== 6) return String(input || "").trim();
  const openLine = digits.slice(0, 3);
  const closeLine = digits.slice(3, 6);
  const s1 = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
  const s2 = closeLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
  const pair = `${s1}${s2}`;
  return `${openLine}-${pair}-${closeLine}`;
}
function parseWinningComponents(rawWin) {
  const raw = String(rawWin || "").trim();
  let openLine = "";
  let openDigit = "";
  let closeLine = "";
  let closeDigit = "";
  let pair = "";
  if (raw.includes("-")) {
    const parts = raw.split("-");
    if (parts.length === 3) {
      openLine = parts[0];
      pair = parts[1];
      closeLine = parts[2];
      openDigit = pair.length >= 1 ? pair[0] : openLine ? String(openLine.split("").reduce((a, c) => a + parseInt(c || "0", 10), 0) % 10) : "0";
      closeDigit = pair.length >= 2 ? pair[1] : closeLine ? String(closeLine.split("").reduce((a, c) => a + parseInt(c || "0", 10), 0) % 10) : "0";
    } else if (parts.length === 2) {
      if (parts[1].length === 1) {
        openLine = parts[0];
        closeDigit = parts[1];
        const sum = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
        openDigit = String(sum);
        pair = `${openDigit}${closeDigit}`;
        closeLine = "";
      } else {
        openLine = parts[0];
        closeLine = parts[1];
        const s1 = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
        const s2 = closeLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
        openDigit = String(s1);
        closeDigit = String(s2);
        pair = `${openDigit}${closeDigit}`;
      }
    } else {
      openLine = "248";
      openDigit = "4";
      closeLine = "369";
      closeDigit = "8";
      pair = "48";
    }
  } else if (raw.length === 6 && /^\d{6}$/.test(raw)) {
    openLine = raw.slice(0, 3);
    closeLine = raw.slice(3, 6);
    const s1 = openLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
    const s2 = closeLine.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
    openDigit = String(s1);
    closeDigit = String(s2);
    pair = `${openDigit}${closeDigit}`;
  } else if (raw.length === 1) {
    openDigit = raw;
    closeDigit = raw;
    pair = `${raw}${raw}`;
  } else if (raw.length === 2) {
    openDigit = raw[0];
    closeDigit = raw[1];
    pair = raw;
  } else if (raw.length === 3) {
    openLine = raw;
    const sum = raw.split("").reduce((acc, c) => acc + parseInt(c || "0", 10), 0) % 10;
    openDigit = String(sum);
    pair = `${openDigit}0`;
  }
  const computedFullDraw = openLine && closeLine && pair ? `${openLine}-${pair}-${closeLine}` : raw;
  return {
    openLine,
    closeLine,
    openDigit,
    closeDigit,
    pair,
    fullDraw: computedFullDraw,
    winningNumber: computedFullDraw
  };
}
function evaluateBetWin(selectedNumber, betType, outcome) {
  const sel = String(selectedNumber).trim();
  const bType = String(betType || "").toLowerCase();
  const win = String(outcome.winningNumber || outcome.fullDraw || "").trim();
  if (sel === win || outcome.fullDraw && sel === outcome.fullDraw) {
    return true;
  }
  let openLine = outcome.openLine || "";
  let closeLine = outcome.closeLine || "";
  let openDigit = outcome.openDigit || "";
  let closeDigit = outcome.closeDigit || "";
  let pair = outcome.pair || "";
  if (!pair && win.includes("-")) {
    const parsed = parseWinningComponents(win);
    openLine = openLine || parsed.openLine;
    closeLine = closeLine || parsed.closeLine;
    openDigit = openDigit || parsed.openDigit;
    closeDigit = closeDigit || parsed.closeDigit;
    pair = pair || parsed.pair;
  }
  if (bType.includes("pair") || bType.includes("double") || bType.includes("jodi")) {
    if (pair && sel === pair) {
      return true;
    }
    if (win.includes("-")) {
      const parts = win.split("-");
      if (parts.length === 3 && sel === parts[1]) {
        return true;
      }
    }
    if (bType.includes("box") && pair) {
      const selSorted = sel.split("").sort().join("");
      const pairSorted = pair.split("").sort().join("");
      if (selSorted === pairSorted) return true;
    }
    return false;
  }
  if (bType.includes("half")) {
    const expected1 = `${openLine}-${closeDigit}`;
    const expected2 = `${closeLine}-${openDigit}`;
    return openLine && sel === expected1 || closeLine && sel === expected2;
  }
  if (bType.includes("full")) {
    const expected = `${openLine}-${closeLine}`;
    return Boolean(openLine && closeLine && sel === expected);
  }
  if (bType.includes("line") || bType.includes("triple") || bType.includes("pana") || sel.length === 3 && !bType.includes("digit")) {
    if (bType.includes("box")) {
      const selSorted = sel.split("").sort().join("");
      const openSorted = openLine.split("").sort().join("");
      const closeSorted = closeLine.split("").sort().join("");
      return openSorted && selSorted === openSorted || closeSorted && selSorted === closeSorted;
    }
    return openLine && sel === openLine || closeLine && sel === closeLine;
  }
  if ((bType.includes("digit") || bType.includes("single") || bType.includes("ank")) && !bType.includes("line")) {
    return sel === openDigit || sel === closeDigit || sel === win;
  }
  if (bType.includes("box")) {
    const selSorted = sel.split("").sort().join("");
    const winDigits = win.replace(/\D/g, "");
    const winSorted = winDigits.split("").sort().join("");
    return selSorted === winSorted;
  }
  if (sel.length === 3) {
    return openLine && sel === openLine || closeLine && sel === closeLine;
  }
  if (sel.length === 2 && pair) {
    return sel === pair;
  }
  if (sel.length === 1) {
    return sel === openDigit || sel === closeDigit;
  }
  return false;
}
function evaluateBetWinFromString(selectedNumber, betType, winningNumberStr) {
  const components = parseWinningComponents(winningNumberStr);
  return evaluateBetWin(selectedNumber, betType, components);
}
async function executeGameDraw(options) {
  const { gameId, declaredById, forceOutcome, provider, simulateLatencyMs } = options;
  let game = await prisma.game.findUnique({
    where: { id: gameId }
  });
  if (!game) {
    game = await ensureHourlyGameExists(gameId);
  }
  const existingResult = await prisma.result.findUnique({
    where: { gameId }
  });
  if (existingResult) {
    throw new Error(`Result already declared for Game #${gameId} (Winning Number: ${existingResult.winningNumber}). Existing results cannot be overridden.`);
  }
  const drawOutcome = await simulateThirdPartyDraw({
    gameId,
    gameCode: game.code,
    forceOutcome,
    provider,
    simulateLatencyMs
  });
  const settlementResult = await prisma.$transaction(async (tx) => {
    const txExisting = await tx.result.findUnique({
      where: { gameId }
    });
    if (txExisting) {
      throw new Error(`Result already declared for Game #${gameId} (Winning Number: ${txExisting.winningNumber}). Existing results cannot be overridden.`);
    }
    const createdResult = await tx.result.create({
      data: {
        gameId,
        winningNumber: drawOutcome.winningNumber,
        declaredById: declaredById || null,
        declaredAt: new Date(drawOutcome.timestamp)
      },
      include: {
        game: { select: { id: true, name: true, code: true } },
        declaredBy: { select: { id: true, name: true, badgeId: true } }
      }
    });
    await tx.game.update({
      where: { id: gameId },
      data: {
        isLocked: true,
        resultTime: new Date(drawOutcome.timestamp)
      }
    });
    const activeBets = await tx.bet.findMany({
      where: {
        gameId,
        ticket: { status: "ACTIVE" }
      },
      include: {
        ticket: { select: { id: true, ticketNumber: true, status: true } }
      }
    });
    const winners = [];
    let totalWinningLiability = 0;
    for (const bet of activeBets) {
      const isMatched = evaluateBetWin(bet.selectedNumber, bet.betType, drawOutcome);
      if (isMatched) {
        const payout = await tx.payout.upsert({
          where: { betId: bet.id },
          create: {
            betId: bet.id,
            winningAmount: bet.potentialPayout,
            status: PayoutStatus.PENDING
          },
          update: {
            winningAmount: bet.potentialPayout
          }
        });
        winners.push({
          betId: bet.id,
          ticketNumber: bet.ticket.ticketNumber,
          selectedNumber: bet.selectedNumber,
          betType: bet.betType,
          stakeAmount: bet.amount,
          payoutAmount: bet.potentialPayout,
          payoutId: payout.id
        });
        totalWinningLiability += bet.potentialPayout;
      }
    }
    return {
      result: createdResult,
      totalCheckedBets: activeBets.length,
      winnersCount: winners.length,
      totalWinningLiability,
      winners
    };
  });
  return {
    game: {
      id: game.id,
      name: game.name,
      code: game.code,
      isLocked: true
    },
    result: settlementResult.result,
    drawOutcome,
    thirdPartySimulation: {
      provider: drawOutcome.provider,
      externalDrawReference: drawOutcome.externalDrawId,
      rngSeedHash: drawOutcome.seedHash,
      timestamp: drawOutcome.timestamp,
      simulated: true,
      note: drawOutcome.note
    },
    settlement: {
      totalCheckedBets: settlementResult.totalCheckedBets,
      winnersCount: settlementResult.winnersCount,
      totalWinningLiability: settlementResult.totalWinningLiability,
      winners: settlementResult.winners
    }
  };
}

// src/server/routes/games.ts
var router2 = Router2();
router2.get("/current", async (_req, res) => {
  try {
    const game = await ensureHourlyGameExists();
    const windowInfo = getISTHourlyWindow();
    res.json({
      success: true,
      data: {
        ...game,
        drawNumber: `#${game.id}`,
        cutoffFormatted: windowInfo.cutoffFormatted,
        cutoffSecondsLeft: windowInfo.cutoffSecondsLeft
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.get("/", async (req, res) => {
  try {
    const { status, isLocked, search } = req.query;
    await ensureHourlyGameExists();
    const where = {};
    if (status !== void 0) {
      where.status = status === "true";
    }
    if (isLocked !== void 0) {
      where.isLocked = isLocked === "true";
    }
    if (search && typeof search === "string") {
      where.OR = [
        { name: { contains: search } },
        { code: { contains: search } }
      ];
    }
    const games = await prisma.game.findMany({
      where,
      orderBy: { openTime: "desc" },
      include: {
        results: {
          take: 1,
          orderBy: { declaredAt: "desc" }
        },
        _count: {
          select: {
            bets: true,
            results: true
          }
        }
      }
    });
    const enrichedGames = games.map((g) => ({
      ...g,
      results: g.results.map((r) => {
        const components = parseWinningComponents(r.winningNumber);
        return {
          ...r,
          openLine: components.openLine,
          closeLine: components.closeLine,
          openDigit: components.openDigit,
          closeDigit: components.closeDigit,
          pair: components.pair,
          fullDraw: components.fullDraw,
          components
        };
      })
    }));
    res.json({ success: true, count: enrichedGames.length, data: enrichedGames });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID" });
    }
    let game = await prisma.game.findUnique({
      where: { id },
      include: {
        results: {
          orderBy: { declaredAt: "desc" },
          take: 5
        },
        _count: {
          select: { bets: true }
        }
      }
    });
    if (!game) {
      game = await ensureHourlyGameExists(id);
    }
    if (!game) {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    const enrichedGame = {
      ...game,
      results: game.results.map((r) => {
        const components = parseWinningComponents(r.winningNumber);
        return {
          ...r,
          openLine: components.openLine,
          closeLine: components.closeLine,
          openDigit: components.openDigit,
          closeDigit: components.closeDigit,
          pair: components.pair,
          fullDraw: components.fullDraw,
          components
        };
      })
    };
    res.json({ success: true, data: enrichedGame });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.post("/:id/trigger-draw", async (req, res) => {
  try {
    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ error: "Invalid game ID" });
    }
    const { declaredById, forceOutcome, provider, simulateLatencyMs, dryRun } = req.body || {};
    const game = await ensureHourlyGameExists(gameId);
    const existingResult = await prisma.result.findUnique({
      where: { gameId }
    });
    if (existingResult) {
      return res.status(409).json({
        error: `Result has already been declared for Game #${gameId} (${existingResult.winningNumber}). Existing results cannot be overridden.`
      });
    }
    if (dryRun) {
      const outcome = await simulateThirdPartyDraw({
        gameId,
        gameCode: game.code,
        forceOutcome,
        provider,
        simulateLatencyMs
      });
      return res.json({
        gameId,
        gameid: gameId,
        drawDetails: {
          drawId: outcome.externalDrawId,
          winningNumber: outcome.winningNumber,
          openLine: outcome.openLine,
          openDigit: outcome.openDigit,
          pair: outcome.pair,
          closeLine: outcome.closeLine,
          closeDigit: outcome.closeDigit,
          fullDraw: outcome.fullDraw,
          timestamp: outcome.timestamp
        }
      });
    }
    const drawResult = await executeGameDraw({
      gameId,
      declaredById: declaredById ? parseInt(declaredById) : void 0,
      forceOutcome,
      provider,
      simulateLatencyMs
    });
    res.json({
      gameId,
      gameid: gameId,
      drawDetails: {
        drawId: drawResult.drawOutcome.externalDrawId,
        winningNumber: drawResult.drawOutcome.winningNumber,
        openLine: drawResult.drawOutcome.openLine,
        openDigit: drawResult.drawOutcome.openDigit,
        pair: drawResult.drawOutcome.pair,
        closeLine: drawResult.drawOutcome.closeLine,
        closeDigit: drawResult.drawOutcome.closeDigit,
        fullDraw: drawResult.drawOutcome.fullDraw,
        timestamp: drawResult.drawOutcome.timestamp
      }
    });
  } catch (error) {
    console.error("Trigger game draw error:", error);
    res.status(500).json({ error: error.message });
  }
});
router2.post("/trigger-draw", async (req, res) => {
  try {
    const { gameId, gameid, declaredById, forceOutcome, provider, simulateLatencyMs, dryRun } = req.body || {};
    const rawId = gameId !== void 0 ? gameId : gameid;
    const parsedGameId = rawId !== void 0 && !isNaN(parseInt(rawId)) ? parseInt(rawId) : getCurrentISTGameId();
    const game = await ensureHourlyGameExists(parsedGameId);
    if (!game) {
      return res.status(404).json({ error: "Game not found" });
    }
    const existingResult = await prisma.result.findUnique({
      where: { gameId: parsedGameId }
    });
    if (existingResult) {
      return res.status(409).json({
        error: `Result has already been declared for Game #${parsedGameId} (${existingResult.winningNumber}). Existing results cannot be overridden.`
      });
    }
    if (dryRun) {
      const outcome = await simulateThirdPartyDraw({
        gameId: parsedGameId,
        gameCode: game.code,
        forceOutcome,
        provider,
        simulateLatencyMs
      });
      return res.json({
        gameId: parsedGameId,
        gameid: parsedGameId,
        drawDetails: {
          drawId: outcome.externalDrawId,
          winningNumber: outcome.winningNumber,
          openLine: outcome.openLine,
          openDigit: outcome.openDigit,
          pair: outcome.pair,
          closeLine: outcome.closeLine,
          closeDigit: outcome.closeDigit,
          fullDraw: outcome.fullDraw,
          timestamp: outcome.timestamp
        }
      });
    }
    const drawResult = await executeGameDraw({
      gameId: parsedGameId,
      declaredById: declaredById ? parseInt(declaredById) : void 0,
      forceOutcome,
      provider,
      simulateLatencyMs
    });
    res.json({
      gameId: parsedGameId,
      gameid: parsedGameId,
      drawDetails: {
        drawId: drawResult.drawOutcome.externalDrawId,
        winningNumber: drawResult.drawOutcome.winningNumber,
        openLine: drawResult.drawOutcome.openLine,
        openDigit: drawResult.drawOutcome.openDigit,
        pair: drawResult.drawOutcome.pair,
        closeLine: drawResult.drawOutcome.closeLine,
        closeDigit: drawResult.drawOutcome.closeDigit,
        fullDraw: drawResult.drawOutcome.fullDraw,
        timestamp: drawResult.drawOutcome.timestamp
      }
    });
  } catch (error) {
    console.error("Trigger game draw error:", error);
    res.status(500).json({ error: error.message });
  }
});
router2.post("/", async (req, res) => {
  try {
    const { name, code, openTime, closeTime, resultTime, baseMultiplier, status, isLocked } = req.body;
    if (!name || !openTime || !closeTime || !resultTime) {
      return res.status(400).json({
        success: false,
        message: "Name, openTime, closeTime, and resultTime are required"
      });
    }
    const game = await prisma.game.create({
      data: {
        name,
        code: code || null,
        openTime: new Date(openTime),
        closeTime: new Date(closeTime),
        resultTime: new Date(resultTime),
        baseMultiplier: baseMultiplier ? parseFloat(baseMultiplier) : 90,
        status: status !== void 0 ? Boolean(status) : true,
        isLocked: isLocked !== void 0 ? Boolean(isLocked) : false
      }
    });
    res.status(201).json({ success: true, message: "Game created successfully", data: game });
  } catch (error) {
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Game code already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID" });
    }
    const { name, code, openTime, closeTime, resultTime, baseMultiplier, status, isLocked } = req.body;
    const game = await prisma.game.update({
      where: { id },
      data: {
        name,
        code: code || null,
        openTime: openTime ? new Date(openTime) : void 0,
        closeTime: closeTime ? new Date(closeTime) : void 0,
        resultTime: resultTime ? new Date(resultTime) : void 0,
        baseMultiplier: baseMultiplier !== void 0 ? parseFloat(baseMultiplier) : void 0,
        status: status !== void 0 ? Boolean(status) : void 0,
        isLocked: isLocked !== void 0 ? Boolean(isLocked) : void 0
      }
    });
    res.json({ success: true, message: "Game updated successfully", data: game });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID" });
    }
    const data = { ...req.body };
    if (data.openTime) data.openTime = new Date(data.openTime);
    if (data.closeTime) data.closeTime = new Date(data.closeTime);
    if (data.resultTime) data.resultTime = new Date(data.resultTime);
    if (data.baseMultiplier !== void 0) data.baseMultiplier = parseFloat(data.baseMultiplier);
    const game = await prisma.game.update({
      where: { id },
      data
    });
    res.json({ success: true, message: "Game updated successfully", data: game });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router2.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid game ID" });
    }
    await prisma.game.delete({
      where: { id }
    });
    res.json({ success: true, message: "Game deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var games_default = router2;

// src/server/routes/tickets.ts
import { Router as Router3 } from "express";
import { TicketStatus, TransactionType, PaymentMode } from "@prisma/client";
var router3 = Router3();
async function generateUniqueTicketNumber(terminalId) {
  for (let attempt = 0; attempt < 10; attempt++) {
    const candidate = generateISTTicketId(/* @__PURE__ */ new Date(), terminalId);
    const existing = await prisma.ticket.findUnique({
      where: { ticketNumber: candidate },
      select: { id: true }
    });
    if (!existing) {
      return candidate;
    }
  }
  const dateStr = getISTDateString();
  const hex = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `TK-${dateStr}-${hex}`;
}
async function generateUniqueBarcode() {
  for (let attempt = 0; attempt < 10; attempt++) {
    const candidate = `${Date.now().toString().slice(-8)}${Math.floor(1e3 + Math.random() * 9e3)}`;
    const existing = await prisma.ticket.findUnique({
      where: { barcode: candidate },
      select: { id: true }
    });
    if (!existing) {
      return candidate;
    }
  }
  return `${Date.now()}${Math.floor(10 + Math.random() * 90)}`;
}
function generateSecurityCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}
router3.get("/", async (req, res) => {
  try {
    const { status, employeeId, gameId, search, limit = "50", offset = "0" } = req.query;
    const where = {};
    if (status && Object.values(TicketStatus).includes(status)) {
      where.status = status;
    }
    if (employeeId) {
      where.employeeId = parseInt(employeeId);
    }
    if (gameId) {
      where.bets = {
        some: { gameId: parseInt(gameId) }
      };
    }
    if (search && typeof search === "string") {
      where.OR = [
        { ticketNumber: { contains: search } },
        { barcode: { contains: search } },
        { securityCode: { contains: search } }
      ];
    }
    const take = parseInt(limit) || 50;
    const skip = parseInt(offset) || 0;
    const [total, tickets] = await Promise.all([
      prisma.ticket.count({ where }),
      prisma.ticket.findMany({
        where,
        take,
        skip,
        orderBy: { createdAt: "desc" },
        include: {
          employee: {
            select: { id: true, name: true, badgeId: true }
          },
          bets: {
            include: {
              game: { select: { id: true, name: true, code: true } },
              payout: true
            }
          },
          transactions: true
        }
      })
    ]);
    res.json({
      success: true,
      total,
      count: tickets.length,
      limit: take,
      offset: skip,
      data: tickets
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.get("/:id", async (req, res) => {
  try {
    const param = req.params.id;
    const isNum = !isNaN(parseInt(param));
    const ticket = await prisma.ticket.findFirst({
      where: isNum ? { OR: [{ id: parseInt(param) }, { ticketNumber: param }, { barcode: param }] } : { OR: [{ ticketNumber: param }, { barcode: param }] },
      include: {
        employee: {
          select: { id: true, name: true, badgeId: true, role: true }
        },
        bets: {
          include: {
            game: true,
            payout: true
          }
        },
        transactions: {
          orderBy: { createdAt: "desc" }
        }
      }
    });
    if (!ticket) {
      return res.status(404).json({ success: false, message: "Ticket not found" });
    }
    res.json({ success: true, data: ticket });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.post("/", async (req, res) => {
  try {
    const { employeeId, bets, paymentMode = "CASH", totalAmount, terminalId } = req.body;
    if (!employeeId || !Array.isArray(bets) || bets.length === 0) {
      return res.status(400).json({
        success: false,
        message: "employeeId and a non-empty array of bets are required"
      });
    }
    let employee = null;
    const parsedId = parseInt(employeeId);
    if (!isNaN(parsedId)) {
      employee = await prisma.employee.findUnique({
        where: { id: parsedId }
      });
    }
    if (!employee || !employee.status) {
      employee = await prisma.employee.findFirst({
        where: {
          OR: [
            { badgeId: String(employeeId) },
            { name: String(employeeId) },
            { role: "OPERATOR", status: true }
          ]
        }
      });
    }
    if (!employee || !employee.status) {
      return res.status(400).json({ success: false, message: "Invalid or inactive employee" });
    }
    const calculatedTotal = bets.reduce((sum, b) => sum + (parseFloat(b.amount) || 0), 0);
    const finalTotal = totalAmount !== void 0 ? parseFloat(totalAmount) : calculatedTotal;
    let newTicket = null;
    for (let attempt = 0; attempt < 5; attempt++) {
      try {
        const ticketNum = await generateUniqueTicketNumber(terminalId);
        const barcode = await generateUniqueBarcode();
        const secCode = generateSecurityCode();
        newTicket = await prisma.$transaction(async (tx) => {
          const createdTicket = await tx.ticket.create({
            data: {
              ticketNumber: ticketNum,
              barcode,
              securityCode: secCode,
              employeeId: employee.id,
              totalAmount: finalTotal,
              status: TicketStatus.ACTIVE
            }
          });
          const currentHourlyGameId = getCurrentISTGameId();
          await ensureHourlyGameExists(currentHourlyGameId, tx);
          for (const b of bets) {
            const betAmount = parseFloat(b.amount) || 10;
            const multiplier = parseFloat(b.multiplier) || 90;
            const potentialPayout = parseFloat(b.potentialPayout) || betAmount * multiplier;
            const rawGameId = parseInt(b.gameId);
            const resolvedGameId = !isNaN(rawGameId) && rawGameId > 0 ? rawGameId : currentHourlyGameId;
            await ensureHourlyGameExists(resolvedGameId, tx);
            await tx.bet.create({
              data: {
                ticketId: createdTicket.id,
                gameId: resolvedGameId,
                selectedNumber: String(b.selectedNumber),
                betType: b.betType || "Single",
                amount: betAmount,
                multiplier,
                potentialPayout
              }
            });
          }
          const validPaymentMode = Object.values(PaymentMode).includes(paymentMode) ? paymentMode : PaymentMode.CASH;
          await tx.transaction.create({
            data: {
              ticketId: createdTicket.id,
              employeeId: employee.id,
              type: TransactionType.SALE,
              amount: finalTotal,
              paymentMode: validPaymentMode,
              referenceNote: `Ticket sale: ${ticketNum}`
            }
          });
          return await tx.ticket.findUnique({
            where: { id: createdTicket.id },
            include: {
              employee: { select: { id: true, name: true, badgeId: true } },
              bets: { include: { game: true } },
              transactions: true
            }
          });
        });
        break;
      } catch (txErr) {
        if (txErr.code === "P2002" && attempt < 4) {
          console.warn(`[Tickets] Concurrent collision detected on attempt ${attempt + 1}, retrying with new ticket number...`);
          continue;
        }
        throw txErr;
      }
    }
    res.status(201).json({
      success: true,
      message: "Ticket issued successfully",
      data: newTicket
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid ticket ID" });
    }
    const { status, totalAmount } = req.body;
    const ticket = await prisma.ticket.update({
      where: { id },
      data: {
        status,
        totalAmount: totalAmount !== void 0 ? parseFloat(totalAmount) : void 0
      },
      include: { bets: true, transactions: true }
    });
    res.json({ success: true, message: "Ticket updated successfully", data: ticket });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Ticket not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid ticket ID" });
    }
    const ticket = await prisma.ticket.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Ticket patched successfully", data: ticket });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Ticket not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid ticket ID" });
    }
    await prisma.ticket.delete({
      where: { id }
    });
    res.json({ success: true, message: "Ticket deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Ticket not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router3.post(["/:id/cancel", "/:id/void"], async (req, res) => {
  try {
    const param = req.params.id;
    const isNum = !isNaN(parseInt(param));
    const { employeeId, reason } = req.body;
    const result = await prisma.$transaction(async (tx) => {
      const ticket = await tx.ticket.findFirst({
        where: isNum ? { OR: [{ id: parseInt(param) }, { ticketNumber: param }, { barcode: param }] } : { OR: [{ ticketNumber: param }, { barcode: param }] },
        include: { bets: true }
      });
      if (!ticket) {
        throw new Error("Ticket not found");
      }
      if (ticket.status !== TicketStatus.ACTIVE) {
        throw new Error(`Cannot void ticket with status: ${ticket.status}`);
      }
      const updatedTicket = await tx.ticket.update({
        where: { id: ticket.id },
        data: { status: TicketStatus.VOID }
      });
      await tx.transaction.create({
        data: {
          ticketId: ticket.id,
          employeeId: employeeId ? parseInt(employeeId) : ticket.employeeId,
          type: TransactionType.REFUND,
          amount: ticket.totalAmount,
          paymentMode: PaymentMode.CASH,
          referenceNote: reason || "Operator void ticket cancellation"
        }
      });
      await tx.transaction.updateMany({
        where: { ticketId: ticket.id, type: TransactionType.SALE },
        data: {
          referenceNote: "SALE (Voided & Refunded)"
        }
      });
      return updatedTicket;
    });
    res.json({
      success: true,
      message: "Ticket voided and refunded successfully",
      data: result
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});
var tickets_default = router3;

// src/server/routes/bets.ts
import { Router as Router4 } from "express";
var router4 = Router4();
router4.get("/", async (req, res) => {
  try {
    const { ticketId, gameId, hasRedeemed, betType, limit = "100", offset = "0" } = req.query;
    const where = {};
    if (ticketId) where.ticketId = parseInt(ticketId);
    if (gameId) where.gameId = parseInt(gameId);
    if (hasRedeemed !== void 0) where.hasRedeemed = hasRedeemed === "true";
    if (betType) where.betType = String(betType);
    const take = parseInt(limit) || 100;
    const skip = parseInt(offset) || 0;
    const [total, bets] = await Promise.all([
      prisma.bet.count({ where }),
      prisma.bet.findMany({
        where,
        take,
        skip,
        orderBy: { createdAt: "desc" },
        include: {
          game: { select: { id: true, name: true, code: true } },
          ticket: { select: { id: true, ticketNumber: true, status: true } },
          payout: true
        }
      })
    ]);
    res.json({ success: true, total, count: bets.length, data: bets });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid bet ID" });
    }
    const bet = await prisma.bet.findUnique({
      where: { id },
      include: {
        game: true,
        ticket: true,
        payout: true
      }
    });
    if (!bet) {
      return res.status(404).json({ success: false, message: "Bet not found" });
    }
    res.json({ success: true, data: bet });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.post("/", async (req, res) => {
  try {
    const { ticketId, gameId, selectedNumber, betType = "Single", amount, multiplier = 90 } = req.body;
    if (!ticketId || !gameId || selectedNumber === void 0 || !amount) {
      return res.status(400).json({
        success: false,
        message: "ticketId, gameId, selectedNumber, and amount are required"
      });
    }
    const parsedAmount = parseFloat(amount);
    const parsedMultiplier = parseFloat(multiplier);
    const potentialPayout = parsedAmount * parsedMultiplier;
    const resolvedGameId = parseInt(gameId) || getCurrentISTGameId();
    await ensureHourlyGameExists(resolvedGameId);
    const bet = await prisma.bet.create({
      data: {
        ticketId: parseInt(ticketId),
        gameId: resolvedGameId,
        selectedNumber: String(selectedNumber),
        betType,
        amount: parsedAmount,
        multiplier: parsedMultiplier,
        potentialPayout
      },
      include: { game: true, ticket: true }
    });
    res.status(201).json({ success: true, message: "Bet created successfully", data: bet });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid bet ID" });
    }
    const { selectedNumber, betType, amount, multiplier, hasRedeemed } = req.body;
    const parsedAmount = amount !== void 0 ? parseFloat(amount) : void 0;
    const parsedMultiplier = multiplier !== void 0 ? parseFloat(multiplier) : void 0;
    const potentialPayout = parsedAmount !== void 0 && parsedMultiplier !== void 0 ? parsedAmount * parsedMultiplier : void 0;
    const bet = await prisma.bet.update({
      where: { id },
      data: {
        selectedNumber: selectedNumber !== void 0 ? String(selectedNumber) : void 0,
        betType,
        amount: parsedAmount,
        multiplier: parsedMultiplier,
        potentialPayout,
        hasRedeemed: hasRedeemed !== void 0 ? Boolean(hasRedeemed) : void 0
      }
    });
    res.json({ success: true, message: "Bet updated successfully", data: bet });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Bet not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid bet ID" });
    }
    const bet = await prisma.bet.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Bet patched successfully", data: bet });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Bet not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router4.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid bet ID" });
    }
    await prisma.bet.delete({
      where: { id }
    });
    res.json({ success: true, message: "Bet deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Bet not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var bets_default = router4;

// src/server/routes/results.ts
import { Router as Router5 } from "express";
import { PayoutStatus as PayoutStatus2 } from "@prisma/client";
var router5 = Router5();
function isWinningBet(selectedNumber, winningNumber, betType) {
  return evaluateBetWinFromString(selectedNumber, betType, winningNumber);
}
router5.get("/", async (req, res) => {
  try {
    const { gameId, limit = "200", offset = "0", startDate, endDate, date, hour, search } = req.query;
    const where = {};
    if (gameId) where.gameId = parseInt(gameId);
    if (search && typeof search === "string" && search.trim()) {
      const q = search.trim();
      const qNum = parseInt(q, 10);
      where.OR = [
        { winningNumber: { contains: q } },
        { game: { name: { contains: q } } },
        { game: { code: { contains: q } } },
        ...!isNaN(qNum) ? [{ gameId: qNum }] : []
      ];
    }
    const filterStartDate = date || startDate;
    const filterEndDate = date || endDate;
    if (filterStartDate || filterEndDate) {
      where.declaredAt = {};
      if (filterStartDate) {
        const s = String(filterStartDate).trim();
        where.declaredAt.gte = new Date(s.length === 10 ? `${s}T00:00:00.000Z` : s);
      }
      if (filterEndDate) {
        const e = String(filterEndDate).trim();
        const endD = new Date(e.length === 10 ? `${e}T23:59:59.999Z` : e);
        where.declaredAt.lte = endD;
      }
    }
    const take = parseInt(limit) || 200;
    const skip = parseInt(offset) || 0;
    const [total, results] = await Promise.all([
      prisma.result.count({ where }),
      prisma.result.findMany({
        where,
        take,
        skip,
        orderBy: { declaredAt: "desc" },
        include: {
          game: { select: { id: true, name: true, code: true, openTime: true, closeTime: true, resultTime: true } },
          declaredBy: { select: { id: true, name: true, badgeId: true } }
        }
      })
    ]);
    const gameIds = Array.from(new Set(results.map((r) => r.gameId)));
    const payouts = gameIds.length > 0 ? await prisma.payout.findMany({
      where: {
        bet: {
          gameId: { in: gameIds }
        }
      },
      select: {
        winningAmount: true,
        status: true,
        bet: { select: { gameId: true } }
      }
    }) : [];
    const payoutMap = /* @__PURE__ */ new Map();
    for (const p of payouts) {
      const gId = p.bet.gameId;
      const prev = payoutMap.get(gId) || { totalPayout: 0, paidCount: 0, pendingCount: 0 };
      prev.totalPayout += p.winningAmount || 0;
      if (p.status === "PAID") prev.paidCount++;
      else prev.pendingCount++;
      payoutMap.set(gId, prev);
    }
    let enrichedResults = results.map((r) => {
      const components = parseWinningComponents(r.winningNumber);
      const pInfo = payoutMap.get(r.gameId) || { totalPayout: 0, paidCount: 0, pendingCount: 0 };
      return {
        ...r,
        openLine: components.openLine,
        closeLine: components.closeLine,
        openDigit: components.openDigit,
        closeDigit: components.closeDigit,
        pair: components.pair,
        fullDraw: components.fullDraw,
        components,
        totalPayoutAmount: pInfo.totalPayout,
        payoutsCount: pInfo.paidCount + pInfo.pendingCount
      };
    });
    if (hour !== void 0 && hour !== "all" && hour !== "") {
      const targetHour = parseInt(hour);
      if (!isNaN(targetHour)) {
        enrichedResults = enrichedResults.filter((r) => {
          const gIdStr = String(r.gameId);
          if (gIdStr.length === 10 && /^\d{10}$/.test(gIdStr)) {
            const h = parseInt(gIdStr.substring(8, 10), 10);
            return h === targetHour;
          }
          const d = new Date(r.declaredAt);
          const istHour = (d.getUTCHours() + 5 + Math.floor((d.getUTCMinutes() + 30) / 60)) % 24;
          return istHour === targetHour;
        });
      }
    }
    res.json({ success: true, total, count: enrichedResults.length, data: enrichedResults });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid result ID" });
    }
    const result = await prisma.result.findUnique({
      where: { id },
      include: {
        game: true,
        declaredBy: { select: { id: true, name: true, badgeId: true } }
      }
    });
    if (!result) {
      return res.status(404).json({ success: false, message: "Result not found" });
    }
    const components = parseWinningComponents(result.winningNumber);
    res.json({
      success: true,
      data: {
        ...result,
        openLine: components.openLine,
        closeLine: components.closeLine,
        openDigit: components.openDigit,
        closeDigit: components.closeDigit,
        pair: components.pair,
        fullDraw: components.fullDraw,
        components
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.post("/trigger-draw", async (req, res) => {
  try {
    const { gameId, gameid, declaredById, forceOutcome, provider, simulateLatencyMs, dryRun } = req.body || {};
    const rawId = gameId !== void 0 ? gameId : gameid;
    if (!rawId) {
      return res.status(400).json({ error: "gameId reference is required" });
    }
    const parsedGameId = parseInt(rawId);
    if (isNaN(parsedGameId)) {
      return res.status(400).json({ error: "Invalid game ID reference" });
    }
    const game = await prisma.game.findUnique({ where: { id: parsedGameId } });
    if (!game) {
      return res.status(404).json({ error: "Game not found" });
    }
    if (dryRun) {
      const outcome = await simulateThirdPartyDraw({
        gameId: parsedGameId,
        gameCode: game.code,
        forceOutcome,
        provider,
        simulateLatencyMs
      });
      return res.json({
        gameId: parsedGameId,
        gameid: parsedGameId,
        drawDetails: {
          drawId: outcome.externalDrawId,
          winningNumber: outcome.winningNumber,
          openLine: outcome.openLine,
          openDigit: outcome.openDigit,
          pair: outcome.pair,
          closeLine: outcome.closeLine,
          closeDigit: outcome.closeDigit,
          fullDraw: outcome.fullDraw,
          timestamp: outcome.timestamp
        }
      });
    }
    const drawResult = await executeGameDraw({
      gameId: parsedGameId,
      declaredById: declaredById ? parseInt(declaredById) : void 0,
      forceOutcome,
      provider,
      simulateLatencyMs
    });
    res.json({
      gameId: parsedGameId,
      gameid: parsedGameId,
      drawDetails: {
        drawId: drawResult.drawOutcome.externalDrawId,
        winningNumber: drawResult.drawOutcome.winningNumber,
        openLine: drawResult.drawOutcome.openLine,
        openDigit: drawResult.drawOutcome.openDigit,
        pair: drawResult.drawOutcome.pair,
        closeLine: drawResult.drawOutcome.closeLine,
        closeDigit: drawResult.drawOutcome.closeDigit,
        fullDraw: drawResult.drawOutcome.fullDraw,
        timestamp: drawResult.drawOutcome.timestamp
      }
    });
  } catch (error) {
    console.error("Trigger draw error:", error);
    res.status(500).json({ error: error.message });
  }
});
router5.post("/", async (req, res) => {
  try {
    const { gameId, winningNumber, declaredById } = req.body;
    if (!gameId || winningNumber === void 0) {
      return res.status(400).json({
        success: false,
        message: "gameId and winningNumber are required"
      });
    }
    const parsedGameId = parseInt(gameId);
    let winNumStr = String(winningNumber).trim();
    const onlyDigits = winNumStr.replace(/\D/g, "");
    if (onlyDigits.length === 6) {
      winNumStr = computeFullWinningNumberFrom6Digits(onlyDigits);
    }
    const game = await prisma.game.findUnique({
      where: { id: parsedGameId }
    });
    if (!game) {
      return res.status(404).json({ success: false, message: "Game not found" });
    }
    const existingResult = await prisma.result.findUnique({
      where: { gameId: parsedGameId }
    });
    if (existingResult) {
      return res.status(409).json({
        success: false,
        message: `Result already declared for Game #${parsedGameId} (Winning Number: ${existingResult.winningNumber}). Existing results cannot be overridden.`
      });
    }
    const outcome = await prisma.$transaction(async (tx) => {
      const txExisting = await tx.result.findUnique({
        where: { gameId: parsedGameId }
      });
      if (txExisting) {
        throw new Error(`Result already declared for Game #${parsedGameId} (Winning Number: ${txExisting.winningNumber}). Existing results cannot be overridden.`);
      }
      const createdResult = await tx.result.create({
        data: {
          gameId: parsedGameId,
          winningNumber: winNumStr,
          declaredById: declaredById ? parseInt(declaredById) : null,
          declaredAt: /* @__PURE__ */ new Date()
        },
        include: { game: true, declaredBy: true }
      });
      await tx.game.update({
        where: { id: parsedGameId },
        data: {
          isLocked: true,
          resultTime: /* @__PURE__ */ new Date()
        }
      });
      const bets = await tx.bet.findMany({
        where: {
          gameId: parsedGameId,
          ticket: { status: "ACTIVE" }
        },
        include: { ticket: true }
      });
      const winners = [];
      let totalWinningLiability = 0;
      for (const bet of bets) {
        if (isWinningBet(bet.selectedNumber, winNumStr, bet.betType)) {
          const payout = await tx.payout.upsert({
            where: { betId: bet.id },
            create: {
              betId: bet.id,
              winningAmount: bet.potentialPayout,
              status: PayoutStatus2.PENDING
            },
            update: {
              winningAmount: bet.potentialPayout
            }
          });
          winners.push({
            betId: bet.id,
            ticketNumber: bet.ticket.ticketNumber,
            selectedNumber: bet.selectedNumber,
            betType: bet.betType,
            amount: bet.amount,
            payoutAmount: bet.potentialPayout,
            payoutId: payout.id
          });
          totalWinningLiability += bet.potentialPayout;
        }
      }
      const components = parseWinningComponents(createdResult.winningNumber);
      return {
        result: {
          ...createdResult,
          openLine: components.openLine,
          closeLine: components.closeLine,
          openDigit: components.openDigit,
          closeDigit: components.closeDigit,
          pair: components.pair,
          fullDraw: components.fullDraw,
          components
        },
        totalCheckedBets: bets.length,
        winnersCount: winners.length,
        totalWinningLiability,
        winners
      };
    });
    res.status(201).json({
      success: true,
      message: `Result declared successfully for ${game.name}. Found ${outcome.winnersCount} winner(s).`,
      data: outcome
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid result ID" });
    }
    const { winningNumber, declaredById } = req.body;
    const result = await prisma.result.update({
      where: { id },
      data: {
        winningNumber: winningNumber !== void 0 ? String(winningNumber) : void 0,
        declaredById: declaredById !== void 0 ? parseInt(declaredById) : void 0
      }
    });
    res.json({ success: true, message: "Result updated successfully", data: result });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Result not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid result ID" });
    }
    const result = await prisma.result.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Result patched successfully", data: result });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Result not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router5.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid result ID" });
    }
    await prisma.result.delete({
      where: { id }
    });
    res.json({ success: true, message: "Result deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Result not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var results_default = router5;

// src/server/routes/payouts.ts
import { Router as Router6 } from "express";
import { PayoutStatus as PayoutStatus3, TransactionType as TransactionType2, PaymentMode as PaymentMode2, TicketStatus as TicketStatus2 } from "@prisma/client";
var router6 = Router6();
router6.get("/", async (req, res) => {
  try {
    const { status, processedById, gameId, limit = "100", offset = "0", startDate, endDate, search } = req.query;
    const where = {};
    if (status && Object.values(PayoutStatus3).includes(status)) {
      where.status = status;
    }
    if (processedById) {
      where.processedById = parseInt(processedById);
    }
    if (gameId) {
      where.bet = { ...where.bet || {}, gameId: parseInt(gameId) };
    }
    if (startDate || endDate) {
      let startD;
      let endD;
      if (startDate && typeof startDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(startDate)) {
        const [sy, sm, sd] = startDate.split("-").map(Number);
        startD = new Date(Date.UTC(sy, sm - 1, sd, 0, 0, 0, 0));
      }
      if (endDate && typeof endDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
        const [ey, em, ed] = endDate.split("-").map(Number);
        endD = new Date(Date.UTC(ey, em - 1, ed, 23, 59, 59, 999));
      }
      if (startD || endD) {
        where.paidAt = {};
        if (startD) where.paidAt.gte = startD;
        if (endD) where.paidAt.lte = endD;
      }
    }
    if (search && typeof search === "string" && search.trim()) {
      const q = search.trim();
      where.OR = [
        { bet: { ticket: { ticketNumber: { contains: q } } } },
        { bet: { ticket: { barcode: { contains: q } } } },
        { claimedBy: { contains: q } },
        { transactionRef: { contains: q } }
      ];
    }
    const take = parseInt(limit) || 100;
    const skip = parseInt(offset) || 0;
    const [total, payouts] = await Promise.all([
      prisma.payout.count({ where }),
      prisma.payout.findMany({
        where,
        take,
        skip,
        orderBy: { paidAt: "desc" },
        include: {
          bet: {
            include: {
              game: { select: { id: true, name: true, code: true } },
              ticket: {
                select: {
                  id: true,
                  ticketNumber: true,
                  barcode: true,
                  status: true,
                  createdAt: true
                }
              }
            }
          },
          processedBy: {
            select: { id: true, name: true, badgeId: true }
          }
        }
      })
    ]);
    res.json({ success: true, total, count: payouts.length, data: payouts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid payout ID" });
    }
    const payout = await prisma.payout.findUnique({
      where: { id },
      include: {
        bet: {
          include: {
            game: true,
            ticket: {
              include: { employee: true }
            }
          }
        },
        processedBy: true
      }
    });
    if (!payout) {
      return res.status(404).json({ success: false, message: "Payout not found" });
    }
    res.json({ success: true, data: payout });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.post("/", async (req, res) => {
  try {
    const { betId, winningAmount, status, claimedBy } = req.body;
    if (!betId || winningAmount === void 0) {
      return res.status(400).json({ success: false, message: "betId and winningAmount are required" });
    }
    const payout = await prisma.payout.create({
      data: {
        betId: parseInt(betId),
        winningAmount: parseFloat(winningAmount),
        status: status || PayoutStatus3.PENDING,
        claimedBy: claimedBy || null
      },
      include: { bet: true }
    });
    res.status(201).json({ success: true, message: "Payout created successfully", data: payout });
  } catch (error) {
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Payout record already exists for this bet" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid payout ID" });
    }
    const { winningAmount, status, claimedBy, processedById } = req.body;
    const payout = await prisma.payout.update({
      where: { id },
      data: {
        winningAmount: winningAmount !== void 0 ? parseFloat(winningAmount) : void 0,
        status,
        claimedBy: claimedBy || null,
        processedById: processedById ? parseInt(processedById) : null,
        paidAt: status === PayoutStatus3.PAID ? /* @__PURE__ */ new Date() : void 0
      }
    });
    res.json({ success: true, message: "Payout updated successfully", data: payout });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid payout ID" });
    }
    const payout = await prisma.payout.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Payout patched successfully", data: payout });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid payout ID" });
    }
    await prisma.payout.delete({
      where: { id }
    });
    res.json({ success: true, message: "Payout deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router6.post("/:id/settle", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { processedById, claimedBy, paymentMode = "CASH" } = req.body;
    const settled = await prisma.$transaction(async (tx) => {
      const payout = await tx.payout.findUnique({
        where: { id },
        include: {
          bet: {
            include: { ticket: true }
          }
        }
      });
      if (!payout) {
        throw new Error("Payout record not found");
      }
      if (payout.status === PayoutStatus3.PAID) {
        throw new Error("Payout has already been settled and paid");
      }
      const updatedPayout = await tx.payout.update({
        where: { id },
        data: {
          status: PayoutStatus3.PAID,
          claimedBy: claimedBy || "Customer Walk-in",
          processedById: processedById ? parseInt(processedById) : null,
          paidAt: /* @__PURE__ */ new Date()
        }
      });
      await tx.transaction.create({
        data: {
          ticketId: payout.bet.ticketId,
          employeeId: processedById ? parseInt(processedById) : null,
          type: TransactionType2.PAYOUT,
          amount: payout.winningAmount,
          paymentMode: Object.values(PaymentMode2).includes(paymentMode) ? paymentMode : PaymentMode2.CASH,
          referenceNote: `Prize redemption for Bet #${payout.betId} (Ticket: ${payout.bet.ticket.ticketNumber})`
        }
      });
      await tx.ticket.update({
        where: { id: payout.bet.ticketId },
        data: {
          status: TicketStatus2.PAID,
          settledAt: /* @__PURE__ */ new Date()
        }
      });
      return updatedPayout;
    });
    res.json({
      success: true,
      message: "Payout settled and cash disbursed successfully",
      data: settled
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});
var payouts_default = router6;

// src/server/routes/transactions.ts
import { Router as Router7 } from "express";
import { TransactionType as TransactionType3, PaymentMode as PaymentMode3 } from "@prisma/client";
var router7 = Router7();
router7.get("/", async (req, res) => {
  try {
    const { type, paymentMode, ticketId, employeeId, startDate, endDate, gameId, search, limit = "50", offset = "0" } = req.query;
    const where = {};
    if (type && Object.values(TransactionType3).includes(type)) {
      where.type = type;
    }
    if (paymentMode && Object.values(PaymentMode3).includes(paymentMode)) {
      where.paymentMode = paymentMode;
    }
    if (ticketId) where.ticketId = parseInt(ticketId);
    if (employeeId) where.employeeId = parseInt(employeeId);
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) {
        let endD = new Date(endDate);
        if (typeof endDate === "string" && endDate.length === 10) {
          endD = /* @__PURE__ */ new Date(`${endDate}T23:59:59.999Z`);
        }
        where.createdAt.lte = endD;
      }
    }
    if (gameId) {
      const gId = parseInt(gameId);
      if (!isNaN(gId)) {
        where.ticket = {
          bets: {
            some: {
              gameId: gId
            }
          }
        };
      }
    }
    if (search && typeof search === "string" && search.trim()) {
      const q = search.trim();
      where.OR = [
        { referenceNote: { contains: q } },
        { ticket: { ticketNumber: { contains: q } } },
        { ticket: { barcode: { contains: q } } },
        { employee: { name: { contains: q } } },
        { employee: { badgeId: { contains: q } } }
      ];
    }
    const take = parseInt(limit) || 50;
    const skip = parseInt(offset) || 0;
    const [total, transactions] = await Promise.all([
      prisma.transaction.count({ where }),
      prisma.transaction.findMany({
        where,
        take,
        skip,
        orderBy: { createdAt: "desc" },
        include: {
          employee: { select: { id: true, name: true, badgeId: true, role: true } },
          ticket: {
            select: {
              id: true,
              ticketNumber: true,
              status: true,
              totalAmount: true,
              bets: {
                select: {
                  gameId: true,
                  game: { select: { id: true, code: true, name: true } }
                },
                take: 1
              }
            }
          }
        }
      })
    ]);
    res.json({ success: true, total, count: transactions.length, limit: take, offset: skip, data: transactions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.get("/summary", async (req, res) => {
  try {
    const { employeeId, startDate, endDate } = req.query;
    const where = {};
    if (employeeId) where.employeeId = parseInt(employeeId);
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) {
        let endD = new Date(endDate);
        if (typeof endDate === "string" && endDate.length === 10) {
          endD = /* @__PURE__ */ new Date(`${endDate}T23:59:59.999Z`);
        }
        where.createdAt.lte = endD;
      }
    }
    const transactions = await prisma.transaction.findMany({
      where,
      select: { type: true, amount: true, paymentMode: true }
    });
    let totalSales = 0;
    let totalPayouts = 0;
    let totalRefunds = 0;
    let totalFloatIn = 0;
    let totalFloatOut = 0;
    for (const t of transactions) {
      switch (t.type) {
        case TransactionType3.SALE:
          totalSales += t.amount;
          break;
        case TransactionType3.PAYOUT:
          totalPayouts += t.amount;
          break;
        case TransactionType3.REFUND:
          totalRefunds += t.amount;
          break;
        case TransactionType3.FLOAT_IN:
          totalFloatIn += t.amount;
          break;
        case TransactionType3.FLOAT_OUT:
          totalFloatOut += t.amount;
          break;
      }
    }
    const netGamingGross = totalSales - totalPayouts - totalRefunds;
    const netDrawerBalance = totalFloatIn + totalSales - totalPayouts - totalRefunds - totalFloatOut;
    res.json({
      success: true,
      data: {
        totalSales,
        totalPayouts,
        totalRefunds,
        totalFloatIn,
        totalFloatOut,
        netGamingGross,
        netDrawerBalance,
        transactionCount: transactions.length
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid transaction ID" });
    }
    const transaction = await prisma.transaction.findUnique({
      where: { id },
      include: {
        employee: true,
        ticket: {
          include: { bets: true }
        }
      }
    });
    if (!transaction) {
      return res.status(404).json({ success: false, message: "Transaction not found" });
    }
    res.json({ success: true, data: transaction });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.post("/", async (req, res) => {
  try {
    const { ticketId, employeeId, type, amount, paymentMode = "CASH", referenceNote } = req.body;
    if (!type || amount === void 0) {
      return res.status(400).json({ success: false, message: "type and amount are required" });
    }
    if (!Object.values(TransactionType3).includes(type)) {
      return res.status(400).json({
        success: false,
        message: `Invalid transaction type. Allowed: ${Object.values(TransactionType3).join(", ")}`
      });
    }
    const transaction = await prisma.transaction.create({
      data: {
        ticketId: ticketId ? parseInt(ticketId) : null,
        employeeId: employeeId ? parseInt(employeeId) : null,
        type,
        amount: parseFloat(amount),
        paymentMode: Object.values(PaymentMode3).includes(paymentMode) ? paymentMode : PaymentMode3.CASH,
        referenceNote: referenceNote || null
      }
    });
    res.status(201).json({ success: true, message: "Transaction recorded successfully", data: transaction });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid transaction ID" });
    }
    const { type, amount, paymentMode, referenceNote } = req.body;
    const transaction = await prisma.transaction.update({
      where: { id },
      data: {
        type,
        amount: amount !== void 0 ? parseFloat(amount) : void 0,
        paymentMode,
        referenceNote: referenceNote !== void 0 ? referenceNote : void 0
      }
    });
    res.json({ success: true, message: "Transaction updated successfully", data: transaction });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Transaction not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid transaction ID" });
    }
    const transaction = await prisma.transaction.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Transaction patched successfully", data: transaction });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Transaction not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router7.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid transaction ID" });
    }
    await prisma.transaction.delete({
      where: { id }
    });
    res.json({ success: true, message: "Transaction deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Transaction not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var transactions_default = router7;

// src/server/routes/payoutRules.ts
import { Router as Router8 } from "express";
var router8 = Router8();
router8.get("/", async (req, res) => {
  try {
    const rules = await prisma.payoutRule.findMany({
      orderBy: { id: "asc" }
    });
    res.json({ success: true, count: rules.length, data: rules });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.get("/:id", async (req, res) => {
  try {
    const param = req.params.id;
    const isNum = !isNaN(parseInt(param));
    const rule = await prisma.payoutRule.findFirst({
      where: isNum ? { OR: [{ id: parseInt(param) }, { betType: param }] } : { betType: param }
    });
    if (!rule) {
      return res.status(404).json({ success: false, message: "Payout rule not found" });
    }
    res.json({ success: true, data: rule });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.post("/", async (req, res) => {
  try {
    const { betType, multiplier, active = true } = req.body;
    if (!betType || multiplier === void 0) {
      return res.status(400).json({ success: false, message: "betType and multiplier are required" });
    }
    const rule = await prisma.payoutRule.create({
      data: {
        betType: String(betType),
        multiplier: parseFloat(multiplier),
        active: Boolean(active)
      }
    });
    res.status(201).json({ success: true, message: "Payout rule created successfully", data: rule });
  } catch (error) {
    if (error.code === "P2002") {
      return res.status(409).json({ success: false, message: "Rule for this betType already exists" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid rule ID" });
    }
    const { betType, multiplier, active } = req.body;
    const rule = await prisma.payoutRule.update({
      where: { id },
      data: {
        betType: betType !== void 0 ? String(betType) : void 0,
        multiplier: multiplier !== void 0 ? parseFloat(multiplier) : void 0,
        active: active !== void 0 ? Boolean(active) : void 0
      }
    });
    res.json({ success: true, message: "Payout rule updated successfully", data: rule });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout rule not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid rule ID" });
    }
    const data = { ...req.body };
    if (data.multiplier !== void 0) data.multiplier = parseFloat(data.multiplier);
    if (data.active !== void 0) data.active = Boolean(data.active);
    const rule = await prisma.payoutRule.update({
      where: { id },
      data
    });
    res.json({ success: true, message: "Payout rule patched successfully", data: rule });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout rule not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
router8.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid rule ID" });
    }
    await prisma.payoutRule.delete({
      where: { id }
    });
    res.json({ success: true, message: "Payout rule deleted successfully" });
  } catch (error) {
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Payout rule not found" });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});
var payoutRules_default = router8;

// src/server/routes/terminalConfig.ts
import { Router as Router9 } from "express";
var router9 = Router9();
router9.get("/", async (_req, res) => {
  try {
    let config = await prisma.terminalConfig.findFirst();
    if (!config) {
      config = await prisma.terminalConfig.create({
        data: {
          stationName: "Station #04 - Counter 1",
          terminalNodeId: "NODE-4092-NYC-01",
          maxBetPerLine: 5e4,
          maxTicketLimit: 25e4,
          autoPrintReceipt: true,
          paperRollPct: 88,
          cutoffBufferSeconds: 60,
          soundEffectsEnabled: true
        }
      });
    }
    res.json({ success: true, data: config });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router9.put("/", async (req, res) => {
  try {
    const config = await prisma.terminalConfig.findFirst();
    const id = config ? config.id : 1;
    const {
      stationName,
      terminalNodeId,
      maxBetPerLine,
      maxTicketLimit,
      autoPrintReceipt,
      paperRollPct,
      cutoffBufferSeconds,
      soundEffectsEnabled
    } = req.body;
    const updated = await prisma.terminalConfig.upsert({
      where: { id },
      update: {
        stationName,
        terminalNodeId,
        maxBetPerLine: maxBetPerLine !== void 0 ? parseFloat(maxBetPerLine) : void 0,
        maxTicketLimit: maxTicketLimit !== void 0 ? parseFloat(maxTicketLimit) : void 0,
        autoPrintReceipt: autoPrintReceipt !== void 0 ? Boolean(autoPrintReceipt) : void 0,
        paperRollPct: paperRollPct !== void 0 ? parseInt(paperRollPct) : void 0,
        cutoffBufferSeconds: cutoffBufferSeconds !== void 0 ? parseInt(cutoffBufferSeconds) : void 0,
        soundEffectsEnabled: soundEffectsEnabled !== void 0 ? Boolean(soundEffectsEnabled) : void 0
      },
      create: {
        stationName: stationName || "Station #04 - Counter 1",
        terminalNodeId: terminalNodeId || "NODE-4092-NYC-01",
        maxBetPerLine: maxBetPerLine !== void 0 ? parseFloat(maxBetPerLine) : 5e4,
        maxTicketLimit: maxTicketLimit !== void 0 ? parseFloat(maxTicketLimit) : 25e4,
        autoPrintReceipt: autoPrintReceipt !== void 0 ? Boolean(autoPrintReceipt) : true,
        paperRollPct: paperRollPct !== void 0 ? parseInt(paperRollPct) : 88,
        cutoffBufferSeconds: cutoffBufferSeconds !== void 0 ? parseInt(cutoffBufferSeconds) : 60,
        soundEffectsEnabled: soundEffectsEnabled !== void 0 ? Boolean(soundEffectsEnabled) : true
      }
    });
    res.json({ success: true, message: "Terminal configuration updated successfully", data: updated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router9.patch("/", async (req, res) => {
  try {
    const config = await prisma.terminalConfig.findFirst();
    const id = config ? config.id : 1;
    const data = { ...req.body };
    if (data.maxBetPerLine !== void 0) data.maxBetPerLine = parseFloat(data.maxBetPerLine);
    if (data.maxTicketLimit !== void 0) data.maxTicketLimit = parseFloat(data.maxTicketLimit);
    if (data.autoPrintReceipt !== void 0) data.autoPrintReceipt = Boolean(data.autoPrintReceipt);
    if (data.paperRollPct !== void 0) data.paperRollPct = parseInt(data.paperRollPct);
    if (data.cutoffBufferSeconds !== void 0) data.cutoffBufferSeconds = parseInt(data.cutoffBufferSeconds);
    if (data.soundEffectsEnabled !== void 0) data.soundEffectsEnabled = Boolean(data.soundEffectsEnabled);
    const updated = await prisma.terminalConfig.upsert({
      where: { id },
      update: data,
      create: {
        stationName: "Station #04 - Counter 1",
        ...data
      }
    });
    res.json({ success: true, message: "Terminal configuration patched successfully", data: updated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var terminalConfig_default = router9;

// src/server/routes/shiftAudits.ts
import { Router as Router10 } from "express";
import { TransactionType as TransactionType4, PaymentMode as PaymentMode4 } from "@prisma/client";
var router10 = Router10();
router10.get("/", async (req, res) => {
  try {
    const { employeeId, status, limit = "20", offset = "0" } = req.query;
    const where = {};
    if (employeeId) where.employeeId = parseInt(employeeId);
    if (status) where.status = String(status);
    const take = parseInt(limit) || 20;
    const skip = parseInt(offset) || 0;
    const [total, shifts] = await Promise.all([
      prisma.shiftAudit.count({ where }),
      prisma.shiftAudit.findMany({
        where,
        take,
        skip,
        orderBy: { openedAt: "desc" },
        include: {
          employee: {
            select: { id: true, name: true, badgeId: true, role: true }
          }
        }
      })
    ]);
    res.json({ success: true, total, count: shifts.length, data: shifts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.get("/current", async (req, res) => {
  try {
    const { employeeId } = req.query;
    if (!employeeId) {
      return res.status(400).json({ success: false, message: "employeeId is required" });
    }
    const currentShift = await prisma.shiftAudit.findFirst({
      where: {
        employeeId: parseInt(employeeId),
        status: "OPEN"
      },
      include: {
        employee: { select: { id: true, name: true, badgeId: true } }
      }
    });
    if (!currentShift) {
      return res.json({ success: true, data: null, message: "No open shift found" });
    }
    const transactions = await prisma.transaction.findMany({
      where: {
        employeeId: currentShift.employeeId,
        paymentMode: PaymentMode4.CASH,
        createdAt: { gte: currentShift.openedAt }
      }
    });
    let liveSales = 0;
    let livePayouts = 0;
    for (const t of transactions) {
      if (t.type === TransactionType4.SALE) liveSales += t.amount;
      if (t.type === TransactionType4.PAYOUT) livePayouts += t.amount;
      if (t.type === TransactionType4.REFUND) liveSales -= t.amount;
    }
    const liveExpected = currentShift.openingFloat + liveSales - livePayouts;
    res.json({
      success: true,
      data: {
        ...currentShift,
        liveSales,
        livePayouts,
        liveExpectedCash: liveExpected
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid shift audit ID" });
    }
    const shift = await prisma.shiftAudit.findUnique({
      where: { id },
      include: {
        employee: true
      }
    });
    if (!shift) {
      return res.status(404).json({ success: false, message: "Shift audit not found" });
    }
    res.json({ success: true, data: shift });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.post("/open", async (req, res) => {
  try {
    const { employeeId, openingFloat, terminalId = "TERM-04" } = req.body;
    if (!employeeId || openingFloat === void 0) {
      return res.status(400).json({ success: false, message: "employeeId and openingFloat are required" });
    }
    const empId = parseInt(employeeId);
    const existing = await prisma.shiftAudit.findFirst({
      where: { employeeId: empId, status: "OPEN" }
    });
    if (existing) {
      return res.status(400).json({
        success: false,
        message: "An open shift already exists for this employee. Please close it first.",
        data: existing
      });
    }
    const shift = await prisma.$transaction(async (tx) => {
      const createdShift = await tx.shiftAudit.create({
        data: {
          employeeId: empId,
          terminalId,
          openingFloat: parseFloat(openingFloat),
          status: "OPEN",
          expectedCash: parseFloat(openingFloat)
        }
      });
      await tx.transaction.create({
        data: {
          employeeId: empId,
          type: TransactionType4.FLOAT_IN,
          amount: parseFloat(openingFloat),
          paymentMode: PaymentMode4.CASH,
          referenceNote: `Opening cash float for shift #${createdShift.id}`
        }
      });
      return createdShift;
    });
    res.status(201).json({ success: true, message: "Shift opened successfully", data: shift });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.post("/:id/close", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { actualCash, notes } = req.body;
    if (actualCash === void 0) {
      return res.status(400).json({ success: false, message: "actualCash counted is required to close shift" });
    }
    const shift = await prisma.shiftAudit.findUnique({
      where: { id }
    });
    if (!shift) {
      return res.status(404).json({ success: false, message: "Shift audit not found" });
    }
    if (shift.status === "CLOSED") {
      return res.status(400).json({ success: false, message: "Shift is already closed" });
    }
    const closedAt = /* @__PURE__ */ new Date();
    const transactions = await prisma.transaction.findMany({
      where: {
        employeeId: shift.employeeId,
        paymentMode: PaymentMode4.CASH,
        createdAt: {
          gte: shift.openedAt,
          lte: closedAt
        }
      }
    });
    let cashSales = 0;
    let cashPayouts = 0;
    for (const t of transactions) {
      if (t.type === TransactionType4.SALE) cashSales += t.amount;
      if (t.type === TransactionType4.PAYOUT) cashPayouts += t.amount;
      if (t.type === TransactionType4.REFUND) cashSales -= t.amount;
    }
    const expectedCash = shift.openingFloat + cashSales - cashPayouts;
    const countedCash = parseFloat(actualCash);
    const difference = countedCash - expectedCash;
    const closedShift = await prisma.$transaction(async (tx) => {
      const updated = await tx.shiftAudit.update({
        where: { id },
        data: {
          status: "CLOSED",
          cashSales,
          cashPayouts,
          expectedCash,
          actualCash: countedCash,
          closingFloat: countedCash,
          difference,
          closedAt
        }
      });
      await tx.transaction.create({
        data: {
          employeeId: shift.employeeId,
          type: TransactionType4.FLOAT_OUT,
          amount: countedCash,
          paymentMode: PaymentMode4.CASH,
          referenceNote: `End-of-shift cash drawer balance. Diff: ${difference.toFixed(2)}. ${notes || ""}`
        }
      });
      return updated;
    });
    res.json({
      success: true,
      message: `Shift #${id} closed successfully. Difference: INR ${difference.toFixed(2)}`,
      data: closedShift
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.put("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const shift = await prisma.shiftAudit.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Shift audit updated successfully", data: shift });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const shift = await prisma.shiftAudit.update({
      where: { id },
      data: req.body
    });
    res.json({ success: true, message: "Shift audit patched successfully", data: shift });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router10.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await prisma.shiftAudit.delete({ where: { id } });
    res.json({ success: true, message: "Shift audit deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var shiftAudits_default = router10;

// src/server/routes/loginActivities.ts
import { Router as Router11 } from "express";
var router11 = Router11();
router11.get("/", async (req, res) => {
  try {
    const { employeeId, limit = "50", offset = "0" } = req.query;
    const where = {};
    if (employeeId) where.employeeId = parseInt(employeeId);
    const take = parseInt(limit) || 50;
    const skip = parseInt(offset) || 0;
    const [total, logs] = await Promise.all([
      prisma.loginActivity.count({ where }),
      prisma.loginActivity.findMany({
        where,
        take,
        skip,
        orderBy: { loginTime: "desc" },
        include: {
          employee: {
            select: { id: true, name: true, badgeId: true, role: true }
          }
        }
      })
    ]);
    res.json({ success: true, total, count: logs.length, data: logs });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router11.post("/", async (req, res) => {
  try {
    const { employeeId, deviceInfo, ipAddress } = req.body;
    if (!employeeId) {
      return res.status(400).json({ success: false, message: "employeeId is required" });
    }
    const log = await prisma.loginActivity.create({
      data: {
        employeeId: parseInt(employeeId),
        deviceInfo: deviceInfo || "Web Terminal Client",
        ipAddress: ipAddress || req.ip
      },
      include: { employee: true }
    });
    res.status(201).json({ success: true, message: "Login recorded", data: log });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router11.patch("/:id/logout", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const log = await prisma.loginActivity.update({
      where: { id },
      data: { logoutTime: /* @__PURE__ */ new Date() }
    });
    res.json({ success: true, message: "Logout recorded", data: log });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router11.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await prisma.loginActivity.delete({ where: { id } });
    res.json({ success: true, message: "Record deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var loginActivities_default = router11;

// src/server/routes/cage.ts
import { Router as Router12 } from "express";
import { TicketStatus as TicketStatus3, PayoutStatus as PayoutStatus4, TransactionType as TransactionType5, PaymentMode as PaymentMode5 } from "@prisma/client";
var router12 = Router12();
async function getOrCreateCage(operatorId, tx = prisma) {
  let cage = null;
  if (operatorId) {
    cage = await tx.cage.findFirst({
      where: { operatorId, status: "OPEN" },
      orderBy: { id: "desc" }
    });
  }
  if (!cage) {
    cage = await tx.cage.findFirst({
      where: { status: "OPEN" },
      orderBy: { id: "desc" }
    });
  }
  if (!cage) {
    cage = await tx.cage.create({
      data: {
        cageCode: "CAGE-01",
        stationName: "Cage Desk #01",
        operatorId: operatorId || 3,
        openingFloat: 1e5,
        currentBalance: 1e5,
        totalPayout: 0,
        todayPaidCount: 0,
        status: "OPEN"
      }
    });
  }
  return cage;
}
router12.get("/verify-ticket/:query", async (req, res) => {
  try {
    const query = req.params.query.trim();
    const ticket = await prisma.ticket.findFirst({
      where: {
        OR: [{ ticketNumber: query }, { barcode: query }, { securityCode: query }]
      },
      include: {
        employee: {
          select: { id: true, name: true, badgeId: true }
        },
        bets: {
          include: {
            game: {
              include: {
                results: {
                  take: 1,
                  orderBy: { declaredAt: "desc" }
                }
              }
            },
            payout: {
              include: {
                processedBy: { select: { id: true, name: true } }
              }
            }
          }
        },
        transactions: true
      }
    });
    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: `No ticket found matching identifier "${query}"`
      });
    }
    let totalClaimableAmount = 0;
    let totalPaidAmount = 0;
    let winningBetsCount = 0;
    let pendingDrawsCount = 0;
    const betEvaluations = ticket.bets.map((bet) => {
      const latestResult = bet.game.results[0] || null;
      const payout = bet.payout;
      const isDrawn = Boolean(latestResult);
      const isMatched = latestResult && latestResult.winningNumber ? evaluateBetWinFromString(bet.selectedNumber, bet.betType, latestResult.winningNumber) : false;
      const hasRedeemed = Boolean(bet.hasRedeemed || payout?.status === PayoutStatus4.PAID);
      let status = "PENDING_DRAW";
      let claimable = 0;
      if (!isDrawn) {
        pendingDrawsCount++;
        status = "AWAITING_DRAW";
      } else if (isMatched) {
        winningBetsCount++;
        if (hasRedeemed) {
          status = "ALREADY_PAID";
          totalPaidAmount += payout ? payout.winningAmount : bet.potentialPayout;
        } else {
          status = "WINNER_UNCLAIMED";
          claimable = payout ? payout.winningAmount : bet.potentialPayout;
          totalClaimableAmount += claimable;
        }
      } else {
        status = "NON_WINNING";
      }
      return {
        betId: bet.id,
        gameName: bet.game.name,
        gameCode: bet.game.code,
        gameStatus: bet.game.status,
        resultWinningNumber: latestResult ? latestResult.winningNumber : null,
        resultDeclaredAt: latestResult ? latestResult.declaredAt : null,
        selectedNumber: bet.selectedNumber,
        betType: bet.betType,
        stakeAmount: bet.amount,
        multiplier: bet.multiplier,
        potentialPayout: bet.potentialPayout,
        isWinner: isMatched,
        isMatched,
        hasRedeemed,
        status,
        claimableAmount: claimable,
        payoutRecord: payout,
        // Detailed Mathematical Calculation Breakdown
        calculation: {
          formula: `INR ${bet.amount.toFixed(2)} \xD7 ${bet.multiplier.toFixed(1)}x = INR ${bet.potentialPayout.toFixed(2)}`,
          stakeAmount: bet.amount,
          multiplier: bet.multiplier,
          grossPayout: isMatched ? payout ? payout.winningAmount : bet.potentialPayout : 0,
          selectedNumber: bet.selectedNumber,
          winningNumber: latestResult ? latestResult.winningNumber : null,
          isMatched,
          hasRedeemed,
          betType: bet.betType,
          ruleDescription: `${bet.betType} pays ${bet.multiplier.toFixed(1)}x multiplier on number match`
        }
      };
    });
    let overallVerdict;
    if (ticket.status === TicketStatus3.CANCELLED || ticket.status === TicketStatus3.VOID) {
      overallVerdict = "CANCELLED_VOID";
    } else if (ticket.status === TicketStatus3.PAID || totalPaidAmount > 0 && totalClaimableAmount === 0) {
      overallVerdict = "ALREADY_REDEEMED";
    } else if (totalClaimableAmount > 0) {
      overallVerdict = "READY_FOR_PAYOUT";
    } else if (pendingDrawsCount > 0) {
      overallVerdict = "AWAITING_RESULTS";
    } else {
      overallVerdict = "NOT_A_WINNER";
    }
    res.json({
      success: true,
      data: {
        ticket: {
          id: ticket.id,
          ticketNumber: ticket.ticketNumber,
          barcode: ticket.barcode,
          securityCode: ticket.securityCode,
          status: ticket.status,
          totalAmount: ticket.totalAmount,
          createdAt: ticket.createdAt,
          settledAt: ticket.settledAt,
          issuedBy: ticket.employee.name,
          issuedBadgeId: ticket.employee.badgeId
        },
        summary: {
          overallVerdict,
          totalBets: ticket.bets.length,
          winningBetsCount,
          isWinner: winningBetsCount > 0,
          hasRedeemed: ticket.status === TicketStatus3.PAID || totalPaidAmount > 0 && totalClaimableAmount === 0,
          pendingDrawsCount,
          totalClaimableAmount,
          totalPaidAmount,
          canRedeem: overallVerdict === "READY_FOR_PAYOUT"
        },
        bets: betEvaluations
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router12.post("/redeem-ticket", async (req, res) => {
  try {
    const { ticketId, operatorId, claimedBy, paymentMode = "CASH" } = req.body;
    if (!ticketId || !operatorId) {
      return res.status(400).json({
        success: false,
        message: "ticketId and operatorId are required"
      });
    }
    const tId = parseInt(ticketId);
    const opId = parseInt(operatorId);
    const redemptionResult = await prisma.$transaction(async (tx) => {
      const ticket = await tx.ticket.findUnique({
        where: { id: tId },
        include: {
          bets: {
            include: {
              payout: true,
              game: {
                include: {
                  results: {
                    take: 1,
                    orderBy: { declaredAt: "desc" }
                  }
                }
              }
            }
          }
        }
      });
      if (!ticket) {
        throw new Error("Ticket not found");
      }
      if (ticket.status === TicketStatus3.CANCELLED || ticket.status === TicketStatus3.VOID) {
        throw new Error(`Ticket is ${ticket.status} and cannot be redeemed`);
      }
      if (ticket.status === TicketStatus3.PAID) {
        throw new Error("This ticket has already been settled and paid out");
      }
      const payableBets = [];
      let totalPayable = 0;
      for (const bet of ticket.bets) {
        if (bet.hasRedeemed || bet.payout?.status === PayoutStatus4.PAID) {
          continue;
        }
        const latestResult = bet.game.results[0];
        if (!latestResult || !latestResult.winningNumber) {
          continue;
        }
        const isMatched = evaluateBetWinFromString(bet.selectedNumber, bet.betType, latestResult.winningNumber);
        if (!isMatched) {
          continue;
        }
        let payout = bet.payout;
        if (!payout) {
          payout = await tx.payout.create({
            data: {
              betId: bet.id,
              winningAmount: bet.potentialPayout,
              status: PayoutStatus4.PENDING
            }
          });
        }
        totalPayable += payout.winningAmount;
        payableBets.push({ bet, payout });
      }
      if (payableBets.length === 0) {
        throw new Error("This ticket has no verified unclaimed winning lines");
      }
      const cage = await getOrCreateCage(opId, tx);
      const prevBalance = cage.currentBalance;
      const validPayment = Object.values(PaymentMode5).includes(paymentMode) ? paymentMode : PaymentMode5.CASH;
      const now = /* @__PURE__ */ new Date();
      for (const item of payableBets) {
        await tx.bet.update({
          where: { id: item.bet.id },
          data: { hasRedeemed: true }
        });
        await tx.payout.update({
          where: { id: item.payout.id },
          data: {
            status: PayoutStatus4.PAID,
            claimedBy: claimedBy || "Walk-in Customer",
            processedById: opId,
            paidAt: now
          }
        });
      }
      const payoutTx = await tx.transaction.create({
        data: {
          ticketId: ticket.id,
          employeeId: opId,
          type: TransactionType5.PAYOUT,
          amount: totalPayable,
          paymentMode: validPayment,
          referenceNote: `Cage Redemption Voucher: Paid INR ${totalPayable.toFixed(2)} (${validPayment}) for ${ticket.ticketNumber}`
        }
      });
      const updatedTicket = await tx.ticket.update({
        where: { id: ticket.id },
        data: {
          status: TicketStatus3.PAID,
          settledAt: now
        }
      });
      const updatedCage = await tx.cage.update({
        where: { id: cage.id },
        data: {
          currentBalance: { decrement: totalPayable },
          totalPayout: { increment: totalPayable },
          todayPaidCount: { increment: 1 }
        }
      });
      let activeShift = await tx.shiftAudit.findFirst({
        where: { employeeId: opId, status: "OPEN" },
        orderBy: { openedAt: "desc" }
      });
      if (activeShift) {
        await tx.shiftAudit.update({
          where: { id: activeShift.id },
          data: {
            cashPayouts: { increment: totalPayable },
            expectedCash: { decrement: totalPayable }
          }
        });
      }
      const voucherCode = `VCH-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}-${String(ticket.id).padStart(4, "0")}`;
      return {
        ticketNumber: ticket.ticketNumber,
        barcode: ticket.barcode,
        redeemedAmount: totalPayable,
        paymentMode: validPayment,
        paidAt: now,
        processedById: opId,
        transactionId: payoutTx.id,
        voucherCode,
        redeemedLinesCount: payableBets.length,
        ticketStatus: updatedTicket.status,
        claimedBy: claimedBy || "Walk-in Customer",
        cageBalance: {
          previousBalance: prevBalance,
          debitedAmount: totalPayable,
          newBalance: updatedCage.currentBalance,
          openingFloat: updatedCage.openingFloat,
          totalPayoutsToday: updatedCage.totalPayout
        }
      };
    });
    res.json({
      success: true,
      message: `Redemption complete! Paid INR ${redemptionResult.redeemedAmount.toFixed(2)} (${redemptionResult.paymentMode}). Cage balance debited.`,
      data: redemptionResult
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});
router12.post("/float-adjustment", async (req, res) => {
  try {
    const { operatorId, amount, type = "FLOAT_IN", note } = req.body;
    const opId = parseInt(operatorId);
    const adjAmount = parseFloat(amount);
    if (!opId || isNaN(adjAmount) || adjAmount <= 0) {
      return res.status(400).json({ success: false, message: "Valid operatorId and positive amount required" });
    }
    const result = await prisma.$transaction(async (tx) => {
      const cage = await getOrCreateCage(opId, tx);
      const txType = type === "FLOAT_OUT" ? TransactionType5.FLOAT_OUT : TransactionType5.FLOAT_IN;
      const delta = txType === TransactionType5.FLOAT_IN ? adjAmount : -adjAmount;
      if (txType === TransactionType5.FLOAT_OUT && cage.currentBalance < adjAmount) {
        throw new Error(`Insufficient Cage balance for Float Out (Available: INR ${cage.currentBalance.toFixed(2)})`);
      }
      await tx.transaction.create({
        data: {
          employeeId: opId,
          type: txType,
          amount: adjAmount,
          paymentMode: PaymentMode5.CASH,
          referenceNote: note || (txType === TransactionType5.FLOAT_IN ? "Vault Float In" : "Vault Cash Drop Float Out")
        }
      });
      const updatedCage = await tx.cage.update({
        where: { id: cage.id },
        data: {
          currentBalance: { increment: delta },
          ...txType === TransactionType5.FLOAT_IN ? { openingFloat: { increment: adjAmount } } : {}
        }
      });
      let activeShift = await tx.shiftAudit.findFirst({
        where: { employeeId: opId, status: "OPEN" },
        orderBy: { openedAt: "desc" }
      });
      if (activeShift) {
        await tx.shiftAudit.update({
          where: { id: activeShift.id },
          data: { expectedCash: { increment: delta } }
        });
      }
      return {
        previousBalance: cage.currentBalance,
        adjustment: delta,
        newBalance: updatedCage.currentBalance,
        openingFloat: updatedCage.openingFloat,
        type: txType
      };
    });
    res.json({ success: true, message: `Cage float adjusted by INR ${adjAmount.toFixed(2)}`, data: result });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router12.get("/", async (req, res) => {
  try {
    const { operatorId } = req.query;
    const opId = operatorId ? parseInt(operatorId) : void 0;
    const cage = await getOrCreateCage(opId);
    res.json({ success: true, data: cage });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router12.get("/summary", async (req, res) => {
  try {
    const { operatorId, date, startDate, endDate, gameId } = req.query;
    const opId = operatorId ? parseInt(operatorId) : void 0;
    const cage = await getOrCreateCage(opId);
    let todayStart;
    let todayEnd;
    let localDateStr;
    const sParam = startDate || date;
    const eParam = endDate || date;
    if (sParam && typeof sParam === "string" && /^\d{4}-\d{2}-\d{2}$/.test(sParam)) {
      const [sy, sm, sd] = sParam.split("-").map(Number);
      todayStart = new Date(Date.UTC(sy, sm - 1, sd, 0, 0, 0, 0));
      if (eParam && typeof eParam === "string" && /^\d{4}-\d{2}-\d{2}$/.test(eParam)) {
        const [ey, em, ed] = eParam.split("-").map(Number);
        todayEnd = new Date(Date.UTC(ey, em - 1, ed, 23, 59, 59, 999));
      } else {
        todayEnd = new Date(Date.UTC(sy, sm - 1, sd, 23, 59, 59, 999));
      }
      localDateStr = sParam;
    } else {
      const istRange = getISTDayRange();
      todayStart = istRange.start;
      todayEnd = istRange.end;
      localDateStr = istRange.dateStr;
    }
    const [
      todayPaidAgg,
      todayPendingPayouts,
      todayRedemptions,
      todayFloatInAgg,
      todayFloatOutAgg,
      todayTicketsSoldAgg
    ] = await Promise.all([
      // Today's Settled Payouts strictly between start of day and end of day
      prisma.payout.aggregate({
        where: {
          status: PayoutStatus4.PAID,
          paidAt: {
            gte: todayStart,
            lte: todayEnd
          }
        },
        _sum: { winningAmount: true },
        _count: true
      }),
      // Unclaimed winning liability declared today
      prisma.payout.aggregate({
        where: {
          status: PayoutStatus4.PENDING,
          createdAt: {
            gte: todayStart,
            lte: todayEnd
          }
        },
        _sum: { winningAmount: true },
        _count: true
      }),
      // Today's settled payouts for the Settlement Audit Ledger
      prisma.payout.findMany({
        where: {
          status: PayoutStatus4.PAID,
          paidAt: {
            gte: todayStart,
            lte: todayEnd
          },
          ...gameId ? { bet: { gameId: parseInt(gameId) } } : {}
        },
        orderBy: { paidAt: "desc" },
        include: {
          bet: {
            include: {
              game: { select: { id: true, name: true, code: true } },
              ticket: { select: { ticketNumber: true, barcode: true, totalAmount: true } }
            }
          },
          processedBy: { select: { id: true, name: true, badgeId: true } }
        }
      }),
      // Today's Float-In transactions
      prisma.transaction.aggregate({
        where: {
          type: TransactionType5.FLOAT_IN,
          createdAt: { gte: todayStart, lte: todayEnd }
        },
        _sum: { amount: true }
      }),
      // Today's Float-Out transactions
      prisma.transaction.aggregate({
        where: {
          type: TransactionType5.FLOAT_OUT,
          createdAt: { gte: todayStart, lte: todayEnd }
        },
        _sum: { amount: true }
      }),
      // Total tickets sold today (excluding cancelled / voided)
      prisma.ticket.aggregate({
        where: {
          createdAt: {
            gte: todayStart,
            lte: todayEnd
          },
          status: { notIn: [TicketStatus3.CANCELLED, TicketStatus3.VOID] }
        },
        _count: true,
        _sum: { totalAmount: true }
      })
    ]);
    const todayPaidAmount = todayPaidAgg._sum.winningAmount || 0;
    const todayPaidCount = todayPaidAgg._count || 0;
    const todayFloatIn = todayFloatInAgg._sum.amount || 0;
    const todayFloatOut = todayFloatOutAgg._sum.amount || 0;
    const todayTicketsSoldCount = todayTicketsSoldAgg._count || 0;
    const todayTicketsSoldAmount = todayTicketsSoldAgg._sum.totalAmount || 0;
    const netDailyPosition = todayTicketsSoldAmount - todayPaidAmount;
    const isShiftOpenedToday = cage.openedAt ? new Date(cage.openedAt) >= todayStart : false;
    const todayOpeningFloat = isShiftOpenedToday ? cage.openingFloat : cage.currentBalance + todayPaidAmount - todayFloatIn + todayFloatOut;
    const cageBalance = {
      openingFloat: todayOpeningFloat,
      currentBalance: cage.currentBalance,
      cashPayouts: todayPaidAmount,
      totalPayout: todayPaidAmount,
      todayPaidCount,
      todayPaidAmount,
      todayFloatIn,
      todayFloatOut,
      todayTicketsSoldCount,
      todayTicketsSoldAmount,
      netDailyPosition,
      status: cage.status,
      shiftOpenedAt: cage.openedAt,
      date: localDateStr
    };
    res.json({
      success: true,
      data: {
        date: localDateStr,
        cage: {
          ...cage,
          openingFloat: todayOpeningFloat,
          totalPayout: todayPaidAmount,
          todayPaidCount
        },
        cageBalance,
        todayPaidCount,
        todayPaidAmount,
        todayFloatIn,
        todayFloatOut,
        todayTicketsSoldCount,
        todayTicketsSoldAmount,
        netDailyPosition,
        todayTicketsSold: {
          count: todayTicketsSoldCount,
          totalAmount: todayTicketsSoldAmount
        },
        unclaimedPendingCount: todayPendingPayouts._count || 0,
        unclaimedPendingAmount: todayPendingPayouts._sum.winningAmount || 0,
        recentRedemptions: todayRedemptions
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var cage_default = router12;

// src/server/routes/admin.ts
import { Router as Router13 } from "express";
import { TransactionType as TransactionType6, TicketStatus as TicketStatus4 } from "@prisma/client";
var router13 = Router13();
router13.get("/metrics", async (_req, res) => {
  try {
    const todayStart = /* @__PURE__ */ new Date();
    todayStart.setHours(0, 0, 0, 0);
    const [
      totalTickets,
      activeTickets,
      todayTickets,
      totalSalesAgg,
      todaySalesAgg,
      totalPayoutsAgg,
      todayPayoutsAgg,
      totalEmployees,
      activeGames,
      recentTransactions
    ] = await Promise.all([
      prisma.ticket.count(),
      prisma.ticket.count({ where: { status: TicketStatus4.ACTIVE } }),
      prisma.ticket.count({ where: { createdAt: { gte: todayStart } } }),
      prisma.transaction.aggregate({
        where: { type: TransactionType6.SALE },
        _sum: { amount: true }
      }),
      prisma.transaction.aggregate({
        where: { type: TransactionType6.SALE, createdAt: { gte: todayStart } },
        _sum: { amount: true }
      }),
      prisma.transaction.aggregate({
        where: { type: TransactionType6.PAYOUT },
        _sum: { amount: true }
      }),
      prisma.transaction.aggregate({
        where: { type: TransactionType6.PAYOUT, createdAt: { gte: todayStart } },
        _sum: { amount: true }
      }),
      prisma.employee.count(),
      prisma.game.count({ where: { status: true } }),
      prisma.transaction.findMany({
        take: 8,
        orderBy: { createdAt: "desc" },
        include: {
          employee: { select: { id: true, name: true, badgeId: true } },
          ticket: { select: { ticketNumber: true } }
        }
      })
    ]);
    const totalSales = totalSalesAgg._sum.amount || 0;
    const todaySales = todaySalesAgg._sum.amount || 0;
    const totalPayouts = totalPayoutsAgg._sum.amount || 0;
    const todayPayouts = todayPayoutsAgg._sum.amount || 0;
    const netGrossGamingRevenue = totalSales - totalPayouts;
    const todayNetRevenue = todaySales - todayPayouts;
    const payoutRatio = totalSales > 0 ? totalPayouts / totalSales * 100 : 0;
    res.json({
      success: true,
      data: {
        kpis: {
          totalSales,
          todaySales,
          totalPayouts,
          todayPayouts,
          netGrossGamingRevenue,
          todayNetRevenue,
          payoutRatio: parseFloat(payoutRatio.toFixed(1)),
          totalTickets,
          activeTickets,
          todayTickets,
          totalEmployees,
          activeGames
        },
        recentTransactions
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
router13.get("/game-analytics", async (req, res) => {
  try {
    const { startDate, endDate, limit, activeOnly } = req.query;
    const where = {};
    if (startDate || endDate) {
      const sDigits = startDate ? startDate.replace(/[^0-9]/g, "").slice(0, 8) : null;
      const eDigits = endDate ? endDate.replace(/[^0-9]/g, "").slice(0, 8) : null;
      if (sDigits?.length === 8 || eDigits?.length === 8) {
        const idFilter = {};
        if (sDigits?.length === 8) idFilter.gte = parseInt(sDigits + "00", 10);
        if (eDigits?.length === 8) idFilter.lte = parseInt(eDigits + "23", 10);
        where.id = idFilter;
      } else {
        where.openTime = {};
        if (startDate) where.openTime.gte = new Date(startDate);
        if (endDate) where.openTime.lte = new Date(endDate);
      }
    }
    if (activeOnly === "true") {
      where.status = true;
    }
    const games = await prisma.game.findMany({
      where,
      orderBy: { id: "desc" },
      take: limit ? parseInt(limit, 10) : void 0,
      include: {
        _count: {
          select: { bets: true, results: true }
        },
        results: {
          take: 1,
          orderBy: { declaredAt: "desc" }
        },
        bets: {
          select: {
            amount: true,
            selectedNumber: true,
            betType: true,
            potentialPayout: true,
            hasRedeemed: true,
            payout: {
              select: {
                winningAmount: true,
                status: true
              }
            }
          }
        }
      }
    });
    const analytics = games.map((game) => {
      let gameSales = 0;
      let gamePayoutLiability = 0;
      let winningBetsCount = 0;
      let redeemedBetsCount = 0;
      const latestResult = game.results[0]?.winningNumber;
      for (const bet of game.bets) {
        gameSales += bet.amount;
        if (bet.payout) {
          gamePayoutLiability += bet.payout.winningAmount;
          winningBetsCount++;
        } else {
          const isMatched = latestResult ? evaluateBetWinFromString(bet.selectedNumber, bet.betType, latestResult) : false;
          if (isMatched) {
            gamePayoutLiability += bet.potentialPayout;
            winningBetsCount++;
          }
        }
        if (bet.hasRedeemed) {
          redeemedBetsCount++;
        }
      }
      return {
        id: game.id,
        name: game.name,
        code: game.code,
        status: game.status,
        isLocked: game.isLocked,
        openTime: game.openTime,
        closeTime: game.closeTime,
        resultTime: game.resultTime,
        latestResult: game.results[0] ? game.results[0].winningNumber : null,
        betsCount: game.bets.length,
        totalDbBetsCount: game._count.bets,
        winningBetsCount,
        redeemedBetsCount,
        totalSales: gameSales,
        totalPayouts: gamePayoutLiability,
        netRevenue: gameSales - gamePayoutLiability
      };
    });
    analytics.sort((a, b) => {
      if (a.totalSales > 0 && b.totalSales === 0) return -1;
      if (b.totalSales > 0 && a.totalSales === 0) return 1;
      if (a.totalSales !== b.totalSales) return b.totalSales - a.totalSales;
      return b.id - a.id;
    });
    res.json({ success: true, count: analytics.length, data: analytics });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});
var admin_default = router13;

// src/server/index.ts
import path from "path";
import fs from "fs";
dotenv.config();
var app = express();
var PORT = process.env.PORT || 5001;
app.use(cors({
  origin: "*",
  // Allow connections from frontend dev server, mobile app, and external clients
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "Bypass-Tunnel-Reminder"]
}));
app.use(express.json());
var healthHandler = (_req, res) => {
  res.json({
    status: "ok",
    service: "GameXpro Lottery Management API Server",
    database: "MySQL (Prisma ORM)",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
};
app.get("/api/health", healthHandler);
app.get("/health", healthHandler);
app.get(["/download/apk", "/api/download/apk"], (_req, res) => {
  const possiblePaths = [
    path.resolve(process.cwd(), "android/app/build/outputs/apk/debug/GameXpro-Lottery.apk"),
    path.resolve(process.cwd(), "android/app/build/outputs/apk/debug/GameXpro-Lottery-debug.apk"),
    path.resolve(process.cwd(), "android/app/build/outputs/apk/debug/app-debug.apk")
  ];
  const apkPath = possiblePaths.find((p) => fs.existsSync(p));
  if (apkPath) {
    const stat = fs.statSync(apkPath);
    res.setHeader("Content-Type", "application/vnd.android.package-archive");
    res.setHeader("Content-Disposition", 'attachment; filename="GameXpro-Lottery.apk"');
    res.setHeader("Content-Length", stat.size);
    return res.sendFile(apkPath);
  }
  return res.status(404).json({
    success: false,
    message: "APK build not found. Please run npm run android:build first to compile the APK."
  });
});
app.get(["/download/info", "/api/download/info"], (_req, res) => {
  const possiblePaths = [
    path.resolve(process.cwd(), "android/app/build/outputs/apk/debug/GameXpro-Lottery.apk"),
    path.resolve(process.cwd(), "android/app/build/outputs/apk/debug/GameXpro-Lottery-debug.apk"),
    path.resolve(process.cwd(), "android/app/build/outputs/apk/debug/app-debug.apk")
  ];
  const apkPath = possiblePaths.find((p) => fs.existsSync(p));
  if (apkPath) {
    const stat = fs.statSync(apkPath);
    return res.json({
      success: true,
      filename: path.basename(apkPath),
      sizeBytes: stat.size,
      sizeFormatted: `${(stat.size / (1024 * 1024)).toFixed(2)} MB`,
      lastModified: stat.mtime.toISOString(),
      downloadUrl: "/download/apk"
    });
  }
  return res.status(404).json({ success: false, message: "No APK built yet." });
});
app.use("/api/employees", employees_default);
app.use("/api/games", games_default);
app.use("/api/tickets", tickets_default);
app.use("/api/bets", bets_default);
app.use("/api/results", results_default);
app.use("/api/payouts", payouts_default);
app.use("/api/transactions", transactions_default);
app.use("/api/payout-rules", payoutRules_default);
app.use("/api/terminal-config", terminalConfig_default);
app.use("/api/shift-audits", shiftAudits_default);
app.use("/api/login-activities", loginActivities_default);
app.use("/api/cage", cage_default);
app.use("/api/admin", admin_default);
var distPath = path.resolve(process.cwd(), "dist");
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api") || req.path.startsWith("/download") || req.path.startsWith("/health")) {
      return next();
    }
    const indexPath = path.join(distPath, "index.html");
    if (fs.existsSync(indexPath)) {
      return res.sendFile(indexPath);
    }
    next();
  });
}
app.use((err, _req, res, _next) => {
  console.error("Unhandled Server Error:", err);
  res.status(500).json({
    success: false,
    message: err.message || "Internal Server Error"
  });
});
app.listen(PORT, () => {
  console.log(`\u{1F680} GameXpro Lottery API Server is running on http://localhost:${PORT}`);
  console.log(`\u{1F4E1} Endpoints available under http://localhost:${PORT}/api/`);
});
var index_default = app;
export {
  index_default as default
};
