# GameXpro Lottery Management - Deployment Guide

## Prerequisites
- Node.js (v18.x or v20.x+)
- MySQL 8.x with database `LotteryManagement`

## Deployment Steps
1. Unzip the archive:
   ```bash
   unzip lottery-management.zip -d lottery-management
   cd lottery-management
   ```
2. Verify database credentials in `.env`:
   ```bash
   nano .env
   ```
3. Run the deployment script:
   ```bash
   ./deploy.sh
   ```

The script will automatically install dependencies, sync the database and launch both services via PM2:
- **Frontend Web UI:** `http://<SERVER_IP>:3005/`
- **Backend API Server:** `http://<SERVER_IP>:5001/`
- **API Health Check:** `http://<SERVER_IP>:5001/api/health`
