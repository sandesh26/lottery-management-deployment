# GameXpro Lottery Management - Deployment Guide

## Prerequisites
- Node.js (v18.x or v20.x+)
- MySQL 8.x with database `LotteryManagement`

## Deployment Steps
1. Unzip the archive:
   ```bash
   unzip lottery-management.zip -d lottery-management
   cd lottery-management
   ```
2. Edit database credentials in `.env`:
   ```bash
   nano .env
   ```
3. Run the deployment script:
   ```bash
   ./deploy.sh
   ```

The script will automatically install production dependencies, sync the database schema, and start the server.
