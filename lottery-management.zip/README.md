<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# GameXpro Lottery Terminal (Web & Android)

Industrial-grade point-of-sale and lottery ticketing terminal built with React 19, TypeScript, Tailwind CSS v4, and Capacitor for cross-platform **Web** and **Android** deployment.

---

## 🌐 1. Running as a Web Application

### Development Server
```bash
npm install
npm run dev
```
Open [http://localhost:3005](http://localhost:3005) in your browser.

### Progressive Web App (PWA)
- The app includes a Web App Manifest (`/manifest.json`), icons, and an offline-resilient Service Worker (`/sw.js`).
- In Chrome or Edge (Desktop or Android), click the **"Install"** icon in the address bar or select **"Add to Home Screen"** to run GameXpro Lottery as a standalone desktop or mobile web app.

---

## 📱 2. Running as an Android Application

The project is configured with **Capacitor** and a complete native Android Gradle project under `android/`.

### Available Android Scripts
- **Build Web & Sync to Android**:
  ```bash
  npm run android:sync
  ```
- **Open in Android Studio**:
  ```bash
  npm run android:open
  ```
- **Directly Build Native Android APK (`.apk`)**:
  ```bash
  npm run android:build
  ```
  The compiled debug APK will be generated at:
  ```text
  android/app/build/outputs/apk/debug/app-debug.apk
  ```
- **Run on Connected Android Device or Emulator**:
  ```bash
  npm run android:run
  ```

---

## ⚡ Native Platform Features & Integrations

- **Android Hardware Back Button**: Navigates between views (Receipt / Verifier / Shift / Reports $\to$ POS $\to$ Lock screen) and closes open modals before exiting.
- **Haptic Tactile Feedback**: Procedural keypresses, card taps, and ticket print vibrations via native Capacitor Haptics with Web Vibration fallback.
- **Screen Wake Lock**: Prevents POS tablet kiosk screens from dimming during terminal shifts.
- **Dark Theme Status Bar**: Configured via `@capacitor/status-bar` to match the POS terminal palette (`#0a122a`).
- **Safe Area Insets**: Full edge-to-edge support with `viewport-fit=cover` and CSS safe area padding for display cutouts and navigation bars.
- **Adaptive Tablet Mode**: Real Android devices automatically run full-screen without artificial borders; desktop web browsers retain an optional tablet enclosure preview.
