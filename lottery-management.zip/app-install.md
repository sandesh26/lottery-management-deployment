### Option A: Send via WhatsApp Web or Telegram (Fastest — 10 seconds)
1. Open **WhatsApp Web** or **Telegram** on your Mac.
2. Drag and drop the `app-debug.apk` file from the open Finder window into:
   - A chat with yourself (or "Saved Messages" in Telegram).
3. On your **Android tablet**, open WhatsApp/Telegram, tap `app-debug.apk` and tap **Install**.

---

### Option B: Google Drive (Reliable & Works on any connection)
1. Go to [drive.google.com](https://drive.google.com) on your Mac.
2. Drag `app-debug.apk` from the open Finder window into Google Drive.
3. Open the **Google Drive app** on your Android tablet and tap `app-debug.apk` to install.

---

### Option C: Public Download Link (Bypasses Wi-Fi restrictions)
I generated a secure public link for your machine so you don't need to be on the same local network:

1. On your tablet browser, open:
   ```text
   https://four-schools-hear.loca.lt/app-debug.apk
   ```
2. If it displays a blue "Tunnel Password" security prompt, enter your public IP:
   ```text
   122.167.112.108
   ```
3. Tap **Click to Submit** and the `.apk` will download directly.

---

### Option D: USB Cable (Instant Install)
If your tablet is plugged into your Mac via USB:
```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

---

> **Reminder for Android**: When you tap to install, if Android says *"For your security, your tablet is not allowed to install unknown apps from this source"*, tap **Settings** $\to$ toggle **"Allow from this source"** to **ON** $\to$ tap **Install**.