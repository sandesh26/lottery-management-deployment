// src/server/frontend.ts
import express from "express";
import path from "path";
import fs from "fs";
var app = express();
var PORT = Number(process.env.FRONTEND_PORT) || 3005;
var distPath = path.resolve(process.cwd(), "dist");
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get("*", (_req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });
} else {
  app.get("*", (_req, res) => {
    res.status(503).send("Frontend build (dist/) not found. Please build the client before running.");
  });
}
app.listen(PORT, "0.0.0.0", () => {
  console.log(`\u{1F310} GameXpro Lottery Frontend Web App is running on http://0.0.0.0:${PORT}`);
});
var frontend_default = app;
export {
  frontend_default as default
};
